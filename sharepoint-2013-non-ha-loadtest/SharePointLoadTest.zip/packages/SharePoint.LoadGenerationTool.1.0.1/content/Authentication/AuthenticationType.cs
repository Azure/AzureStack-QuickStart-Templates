﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AuthenticationType.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The enum AuthenticationType.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The ENUM AuthenticationType.
    /// </summary>
    public enum AuthenticationType
    {
        /// <summary>
        /// Form Based Authentication.
        /// </summary>
        FormBasedAuthentication,

        /// <summary>
        /// Windows Authentication.
        /// </summary>
        WindowsAuthentication
    }
}
