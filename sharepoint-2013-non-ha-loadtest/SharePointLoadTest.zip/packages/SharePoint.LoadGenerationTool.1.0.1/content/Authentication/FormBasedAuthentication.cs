﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FormBasedAuthentication.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The form-based authentication.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using Microsoft.VisualStudio.TestTools.WebTesting;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The form-based authentication.
    /// </summary>
    public class FormBasedAuthentication : WebTestAuthentication
    {
        /// <summary>
        /// Implement the Form Based Authenticate method.
        /// </summary>
        /// <param name="webTest">Current Web Test.</param>
        /// <returns>Web Test Request.</returns>
        public override WebTestRequest Authenticate(WebTest webTest)
        {
            WebTestContext context = webTest.Context;
            if (context == null)
            {
                throw new ArgumentNullException("context is null.");
            }

            bool isAuthenticated = false;
            if (context.ContainsKey(Constants.IsAuthenticated) &&
                bool.TryParse(context[Constants.IsAuthenticated].ToString(), out isAuthenticated)
                && isAuthenticated)
            {
                return null;
            }

            return this.BuildFormBasedAuthenticationRequest(context);
        }

        private WebTestRequest BuildFormBasedAuthenticationRequest(WebTestContext context)
        {
            WebTestRequest request = new WebTestRequest(context["SiteUrl"].ToString() + "/_vti_bin/authentication.asmx");
            request.Timeout = 60;
            request.Method = "POST";
            request.Headers.Add(
                new WebTestRequestHeader(
                    "VsDebuggerCausalityData",
                    "uIDPo1R5DidMN91HtcSTixJ0diYAAAAA9F8WgmzOikGgXugu1gdVCj2sbbBS2NBPnNyFahRlxv4ACQAA"));
            request.Headers.Add(new WebTestRequestHeader("Content-Type", "text/xml; charset=utf-8"));
            request.Headers.Add(
                new WebTestRequestHeader("SOAPAction", "\"http://schemas.microsoft.com/sharepoint/soap/Login\""));
            StringHttpBody request1Body = new StringHttpBody();
            request1Body.ContentType = "text/xml; charset=utf-8";
            request1Body.InsertByteOrderMark = false;
            request1Body.BodyString = @"<?xml version=""1.0"" encoding=""utf-8""?>
                <soap:Envelope xmlns:xsi=""http://www.w3.org/2001/XMLSchema-instance"" xmlns:xsd=""http://www.w3.org/2001/XMLSchema"" xmlns:soap=""http://schemas.xmlsoap.org/soap/envelope/"">
              <soap:Body>
                <Login xmlns=""http://schemas.microsoft.com/sharepoint/soap/"">
                  <username>"
                                                   + (context["UserName"].ToString()
                                                      + ("</username>\r\n      <password>"
                                                         + (context["Password"].ToString()
                                                            + "</password>\r\n    </Login>\r\n  </soap:Body>\r\n</soap:Envelope>")));
            request.Body = request1Body;
            return request;
        }
    }
}
