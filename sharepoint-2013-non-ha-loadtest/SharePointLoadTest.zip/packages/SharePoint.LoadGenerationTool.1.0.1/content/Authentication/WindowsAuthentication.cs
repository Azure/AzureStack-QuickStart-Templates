﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="WindowsAuthentication.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The class is the implementation of WindowsAuthentication.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using Microsoft.VisualStudio.TestTools.WebTesting;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    ///  The class is the implementation of WindowsAuthentication.
    /// </summary>
    public class WindowsAuthentication : WebTestAuthentication
    {
        /// <summary>
        /// Set UserName and Password for web test and put them in the context of web test.
        /// </summary>
        /// <param name="webTest">Current web test.</param>
        /// <returns>Returns null.</returns>
        public override WebTestRequest Authenticate(WebTest webTest)
        {
            webTest.UserName = webTest.Context["users.users#csv.AccountName"].ToString();
            webTest.Password = webTest.Context["users.users#csv.Password"].ToString();
            webTest.Context["UserName"] = webTest.Context["users.users#csv.UserName"];
            webTest.Context["Password"] = webTest.Context["users.users#csv.Password"];
            return null;
        }
    }
}
