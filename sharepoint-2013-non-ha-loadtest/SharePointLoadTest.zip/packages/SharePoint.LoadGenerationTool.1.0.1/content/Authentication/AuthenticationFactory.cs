﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AuthenticationFactory.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The class is the factory to create authentications.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The class is the factory to create authentications.
    /// </summary>
    public class AuthenticationFactory
    {
        /// <summary>
        /// Get Authentication Instance.
        /// </summary>
        /// <param name="authenticationType">Authentication Type.</param>
        /// <returns>The Authentication Instance.</returns>
        public static WebTestAuthentication GetAuthentication(AuthenticationType authenticationType)
        {
            WebTestAuthentication authentication;
            switch (authenticationType)
            {
                case AuthenticationType.WindowsAuthentication:
                    authentication = new WindowsAuthentication();
                    break;
                case AuthenticationType.FormBasedAuthentication:
                    authentication = new FormBasedAuthentication();
                    break;
                default:
                    throw new ArgumentException("Unsupported Authentication Type.");
            }

            return authentication;
        }
    }
}
