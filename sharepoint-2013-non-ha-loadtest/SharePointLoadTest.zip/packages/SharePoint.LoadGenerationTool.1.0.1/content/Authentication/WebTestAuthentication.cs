﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="WebTestAuthentication.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The base authentication class.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using Microsoft.VisualStudio.TestTools.WebTesting;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The base authentication class.
    /// </summary>
    public abstract class WebTestAuthentication
    {
        /// <summary>
        /// Base Authenticate method.
        /// </summary>
        /// <param name="webTest">Current Web Test.</param>
        /// <returns>Returns Web Test Request.</returns>
        public abstract WebTestRequest Authenticate(WebTest webTest);
    }
}
