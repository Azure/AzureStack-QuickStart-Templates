param(
[string]$AuthenticationType = "FormBasedAuthentication",   #AuthenticationType: Authentication Type
[string]$LoadBalancer = "", #LoadBalancer
[Parameter(Mandatory=$true, HelpMessage="Frontend Server names, separate by comma")][string]$FrontendServers , #FrontendServers: Frontend Server Names, separate with ',', for example "servernamea,servernameb"
[string]$FrontendServerPort = "11207",   #FrontendServerPort server port
[Parameter(Mandatory=$true, HelpMessage="SQL Server names")][string]$SQLServers, #SQLServers: SQL server names, separate with ',', for example "servernamea,servernameb"
[string]$Controller = $env:ComputerName,   #Controller: Controller Name
[string]$TotalUserCount = "1000",   #TotalUserCount: total test user count
[string]$Password = "P@ssword!",   #Password: password for sythetic user
[string]$EnableCachedCookie = "True"   #EnableCachedCookie: Enable Cached Cookie
)
 #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#
 # If you created this project by Load Generation Wizard, you don't need to run this init.ps1 again.
 # Here is an example to run this command:
 # .\Init.ps1 -AuthenticationType "FormBasedAuthentication"    -LoadBalancer loadbalancerServer    -FrontendServers "Frontend1,Frontend2,Frontend3"
 #        -FrontendServerPort 11207 -SQLServers    "SQLserver1,SQLserver2"    -Controller controllerServer    -TotalUserCount testUserCount 
 #        -Password password    -EnableCachedCookie "True"
 #
 #-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------#

cd $PSScriptRoot

# copy Remote.testsettings to the same directory as solution file
pushd .
cd ..\packages\sharepoint.loadgenerationtool*\
copy *.testsettings ..\..\
popd

# replace the controller placeholder with the parameter "$Controller"
(Get-Content "..\Remote.testsettings") | 
Foreach-Object {$_ -replace "<!--%Controller%-->", "$Controller"}  | 
Out-File -Encoding "UTF8" "..\Remote.testsettings"

# replace the placeholders in WebTestConfig.xml with the real parameters
(Get-Content "app.config") | 
Foreach-Object {$_ -replace "%LoadBalancer%", "$LoadBalancer"} | 
Foreach-Object {$_ -replace "%FrontendServerNames%", "$FrontendServers"} | 
Foreach-Object {$_ -replace "%SQLServerNames%", "$SQLServers"} | 
Foreach-Object {$_ -replace "%ControllerName%", "$Controller"} | 
Foreach-Object {$_ -replace "%TotalUserCount%", "$TotalUserCount"} | 
Foreach-Object {$_ -replace "%Password%", "$Password"} | 
Foreach-Object {$_ -replace "%FrontendServerPort%", "$FrontendServerPort"} |
Foreach-Object {$_ -replace "%AuthenticationType%", "$AuthenticationType"} |
Foreach-Object {$_ -replace "%EnableCachedCookie%", "$EnableCachedCookie"} |
Out-File -Encoding "UTF8" "app.config"

# replace the placeholder in load test files with real computer counters
# get Frontend servers from parameter
$FrontendServerNameList=$FrontendServers.Split(",")
# concatenate string for all Frontend counter set blocks
foreach($serverName in $FrontendServerNameList)
{
    $CountersBlocks += "<CounterSetMapping ComputerName=`""+ $serverName+"`">
        <CounterSetReferences>
            <CounterSetReference CounterSetName=`"Application`" />
            <CounterSetReference CounterSetName=`"ASP.NET`" />
            <CounterSetReference CounterSetName=`".NET Application`" />
            <CounterSetReference CounterSetName=`"IIS`" />
            <CounterSetReference CounterSetName=`"SharePoint 2010 Frontend`" />
        </CounterSetReferences>
        <ComputerTags>
            <ComputerTag Tag=`"Frontend Server`" />
        </ComputerTags>
    </CounterSetMapping>";
}

# get SQL servers from parameter
$SQLServerNameList=$SQLServers.Split(",")
# concatenate string for SQL server counter block
foreach($serverName in $SQLServerNameList)
{
$CountersBlocks += "`n<CounterSetMapping ComputerName=`""+$serverName+"`">
          <CounterSetReferences>
            <CounterSetReference CounterSetName=`"SQL`" />
          </CounterSetReferences>
          <ComputerTags>
            <ComputerTag Tag=`"SQL Server`" />
          </ComputerTags>
        </CounterSetMapping>"
}

# replace the custom counter blocks placeholder with real ones.
$loadtestFiles=get-childitem . -include *.loadtest -rec
foreach ($file in $loadtestFiles)
{
    (Get-Content $file.PSPath) | 
    Foreach-Object {$_ -replace '<!--%CustomCountersBlocks%-->',$CountersBlocks}  |
    Set-Content $file.PSPath
}  

# add Local.testsettings and Remote.testsettings to solution items
if($dte -and !(Get-Content "..\*.sln"| Where-Object{$_.Contains("testsettings")}))
{
    $vsSolution = Get-Interface $dte.Solution ([EnvDTE80.Solution2])
    $vsProject = $vsSolution.AddSolutionFolder("Solution Items")
    $projectItems = Get-Interface $vsProject.ProjectItems ([EnvDTE.ProjectItems])
    $localTestSettings = "$(get-location)\..\Local.testsettings"
    $projectItems.AddFromFile($localTestSettings) > $null
    $remoteTestSettings = "$(get-location)\..\Remote.testsettings"
    $projectItems.AddFromFile($remoteTestSettings) > $null
}