﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LoadGenerationWebTest.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The base web test class.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.WebTesting;
using Microsoft.VisualStudio.TestTools.WebTesting.Rules;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The base web test class.
    /// </summary>
    public abstract class LoadGenerationWebTest : WebTest
    {
        private CustomDataSource customDataSource = new CustomDataSource();
        private AuthenticationType? authenticationType;

        /// <summary>
        /// Constructor of Load Generation WebTest.
        /// </summary>
        public LoadGenerationWebTest()
        {
            this.PreAuthenticate = true;
            this.Proxy = "default";
            this.Initialize();
        }

        /// <summary>
        /// Gets the value of Authentication Type.
        /// </summary>
        /// <value>The value of Authentication Type.</value>
        public AuthenticationType AuthenticationType
        {
            get
            {
                if (!this.authenticationType.HasValue)
                {
                    AuthenticationType temp;
                    if (Enum.TryParse<AuthenticationType>(this.Context[Constants.AuthenticationType].ToString(), out temp))
                    {
                        this.authenticationType = temp;
                        return this.authenticationType.Value;
                    }
                    else
                    {
                        throw new ArgumentException("Unknown authentication type.");
                    }
                }

                return this.authenticationType.Value;
            }
        }

        /// <summary>
        /// Issue the common request firstly and then issue different requests in concrete sub class.
        /// </summary>
        /// <returns>List of WebTestRequest.</returns>
        public override IEnumerator<WebTestRequest> GetRequestEnumerator()
        {
            WebTestRequest request = this.Authenticate();
            if (request != null)
            {
                if (this.Context.ValidationLevel >= Microsoft.VisualStudio.TestTools.WebTesting.ValidationLevel.High)
                {
                    ValidationRuleFindText validationRule = new ValidationRuleFindText();
                    validationRule.FindText = "NoError";
                    validationRule.IgnoreCase = true;
                    validationRule.UseRegularExpression = false;
                    validationRule.PassIfTextFound = true;
                    request.ValidateResponse += new EventHandler<ValidationEventArgs>(validationRule.Validate);
                }

                yield return request;
            }

            var requests = this.BuildRequests();
            foreach (var req in requests)
            {
                yield return req;
            }
        }

        /// <summary>
        /// Build all requests other than Authentication request.
        /// </summary>
        /// <returns>Return a list of WebTestRequest.</returns>
        public abstract IEnumerable<WebTestRequest> BuildRequests();

        private WebTestRequest Authenticate()
        {
            WebTestAuthentication authentication = AuthenticationFactory.GetAuthentication(AuthenticationType);
            return authentication.Authenticate(this);
        }

        private void Initialize()
        {
            Dictionary<string, string> dictionary = this.customDataSource.NextRow;
            foreach (string key in dictionary.Keys)
            {
                // if the key exists, then update it. Otherwise add the key
                if (this.Context.ContainsKey(key))
                {
                    this.Context[key] = dictionary[key];
                }
                else
                {
                    this.Context.Add(key, dictionary[key]);
                }
            }
        }
    }
}
