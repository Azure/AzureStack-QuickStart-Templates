﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CommonUrls.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The common URLs.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using Microsoft.VisualStudio.TestTools.WebTesting;
using System;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The common URLs.
    /// </summary>
    public static class CommonUrls
    {
        /// <summary>
        /// Gets the root URL of personal site.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the root URL of personal site.</returns>
        public static string GetPersonalSiteRoot(WebTestContext context)
        {
            return context["SiteUrl"].ToString() + Constants.Slash + context["PersonalSitePath"].ToString() + Constants.Slash + context["UserName"].ToString();
        }

        /// <summary>
        /// Gets the process query URL.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the process query URL.</returns>
        public static string GetProcessQueryUrl(WebTestContext context)
        {
            return GetPersonalSiteRoot(context) + "/_vti_bin/client.svc/ProcessQuery";
        }

        /// <summary>
        /// Gets the site URL.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the site URL.</returns>
        public static string GetSiteUrl(WebTestContext context)
        {
            return GetPersonalSiteRoot(context) + "/_vti_bin/sites.asmx";
        }

        /// <summary>
        /// Gets the upload URL.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the upload URL.</returns>
        public static string GetUploadUrl(WebTestContext context)
        {
            return GetPersonalSiteRoot(context) + "/_layouts/15/upload.aspx";
        }

        /// <summary>
        /// Gets the all documents URL.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the all documents URL.</returns>
        public static string GetAllDocumentsUrl(WebTestContext context)
        {
            return GetPersonalSiteRoot(context) + "/Documents/Forms/All.aspx";
        }

        /// <summary>
        /// Gets the Edit Profile URL.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the Edit Profile URL.</returns>
        public static string GetEditProfileUrl(WebTestContext context)
        {
            return context["SiteUrl"] + "/my/_layouts/15/EditProfile.aspx";
        }

        /// <summary>
        /// Gets the activity feed URL.
        /// </summary>
        /// <param name="context">The context of web test.</param>
        /// <returns>Returns the activity feed URL.</returns>
        public static string GetActivityFeedUrl(WebTestContext context)
        {
            return GetPersonalSiteRoot(context) + "/_layouts/15/activityfeed.aspx";
        }
    }
}
