﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Constants.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The constants class is to store all of those constants in the project.
// </summary>
// --------------------------------------------------------------------------------------------------------------------
namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The constants.
    /// </summary>
    public static class Constants
    {
        /// <summary>
        /// The user name string.
        /// </summary>
        public const string UserName = "UserName";

        /// <summary>
        /// The password string.
        /// </summary>
        public const string Password = "Password";

        /// <summary>
        /// The site url string.
        /// </summary>
        public const string SiteUrl = "SiteUrl";

        /// <summary>
        /// The personal path string.
        /// </summary>
        public const string PersonalSitePath = "PersonalSitePath";

        /// <summary>
        /// The LoadBalancer string.
        /// </summary>
        public const string LoadBalancer = "LoadBalancer";

        /// <summary>
        /// The AuthenticationType string.
        /// </summary>
        public const string AuthenticationType = "AuthenticationType";

        /// <summary>
        /// The IsAuthenticated string.
        /// </summary>
        public const string IsAuthenticated = "IsAuthenticated";

        /// <summary>
        /// The TotalUserCount string.
        /// </summary>
        public const string TotalUserCount = "TotalUserCount";

        /// <summary>
        /// The DataSourcePlugin string.
        /// </summary>
        public const string AppSettings = "AppSettings";

        /// <summary>
        /// The prefix of UserName.
        /// </summary>
        public const string UserNamePrefix = "loadtestuser";

        /// <summary>
        /// The EnableCachedCookie string.
        /// </summary>
        public const string EnableCachedCookie = "EnableCachedCookie";

        /// <summary>
        /// The FrontendServerNames string.
        /// </summary>
        public const string FrontendServerNames = "FrontendServerNames";

        /// <summary>
        /// The FrontendServerPort string.
        /// </summary>
        public const string FrontendServerPort = "FrontendServerPort";

        /// <summary>
        /// The Http Prefix string.
        /// </summary>
        public const string HttpPrefix = "http://";

        /// <summary>
        /// The Colon string.
        /// </summary>
        public const string Colon = ":";

        /// <summary>
        /// The Slash string.
        /// </summary>
        public const string Slash = "/";

        /// <summary>
        /// The Test Content for uploading.
        /// </summary>
        public const string TestContent = "Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type a keyword to search online for the video that best fits your document. To make your document look professionally produced, Word provides header, footer, cover page, and text box designs that complement each other. For example, you can add a matching cover page, header, and sidebar. Click Insert and then choose the elements you want from the different galleries. Themes and styles also help keep your document coordinated. When you click Design and choose a new Theme, the pictures, charts, and SmartArt graphics change to match your new theme. When you apply styles, your headings change to match the new theme. Save time in Word with new buttons that show up where you need them. To change the way a picture fits in your document, click it and a button for layout options appears next to it. When you work on a table, click where you want to add a row or a column, and then click the plus sign. Reading is easier, too, in the new Reading view. You can collapse parts of the document and focus on the text you want. If you need to stop reading before you reach the end, Word remembers where you left off - even on another device. Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type a keyword to search online for the video that best fits your document. To make your document look professionally produced, Word provides header, footer, cover page, and text box designs that complement each other. For example, you can add a matching cover page, header, and sidebar. Click Insert and then choose the elements you want from the different galleries. Themes and styles also help keep your document coordinated. When you click Design and choose a new Theme, the pictures, charts, and SmartArt graphics change to match your new theme. When you apply styles, your headings change to match the new theme. Save time in Word with new buttons that show up where you need them. To change the way a picture fits in your document, click it and a button for layout options appears next to it. When you work on a table, click where you want to add a row or a column, and then click the plus sign. Reading is easier, too, in the new Reading view. You can collapse parts of the document and focus on the text you want. If you need to stop reading before you reach the end, Word remembers where you left off - even on another device. Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type a keyword to search online for the video that best fits your document. To make your document look professionally produced, Word provides header, footer, cover page, and text box designs that complement each other. For example, you can add a matching cover page, header, and sidebar. Click Insert and then choose the elements you want from the different galleries. Themes and styles also help keep your document coordinated. When you click Design and choose a new Theme, the pictures, charts, and SmartArt graphics change to match your new theme. When you apply styles, your headings change to match the new theme. Save time in Word with new buttons that show up where you need them. To change the way a picture fits in your document, click it and a button for layout options appears next to it. When you work on a table, click where you want to add a row or a column, and then click the plus sign. Reading is easier, too, in the new Reading view. You can collapse parts of the document and focus on the text you want. If you need to stop reading before you reach the end, Word remembers where you left off - even on another device. Video provides a powerful way to help you prove your point. When you click Online Video, you can paste in the embed code for the video you want to add. You can also type a keyword to search online for the video that best fits your document. To make your document look professionally produced, Word provides header, footer, cover page, and text box designs that complement each other. For example, you can add a matching cover page, header, and sidebar. Click Insert and then choose the elements you ";

        /// <summary>
        /// The list prefix adding by CSOM.
        /// </summary>
        public const string CSOMPrefix = "CSOM_";
    }
}