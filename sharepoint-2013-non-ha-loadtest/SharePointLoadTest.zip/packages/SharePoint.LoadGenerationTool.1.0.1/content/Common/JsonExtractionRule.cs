﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="JsonExtractionRule.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The Json Extraction Rule to extract json objects from json string.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.ComponentModel;
using System.Globalization;
using Microsoft.VisualStudio.TestTools.WebTesting;
using Newtonsoft.Json.Linq;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The JSON Extraction Rule to extract JSON objects from JSOn string.
    /// </summary>
    [DisplayName("JSON Extraction Rule")]
    [Description("Extracts the specified JSON value from an object.")]
    public class JsonExtractionRule : ExtractionRule
    {
        /// <summary>
        /// Gets or sets Name of the rule.
        /// </summary>
        /// <value>
        /// The Name of the rule.
        /// </value>
        public string Name { get; set; }

        /// <summary>
        /// Extract the body string to JArray.
        /// </summary>
        /// <param name="sender">The sender.</param>
        /// <param name="e">The extraction event args e.</param>
        public override void Extract(object sender, ExtractionEventArgs e)
        {
            if (e.Response.BodyString != null)
            {
                var json = e.Response.BodyString;
                var data = JArray.Parse(json);

                if (data != null)
                {
                    e.WebTest.Context.Add(this.ContextParameterName, data);
                    e.Success = true;
                    return;
                }
            }

            e.Success = false;
            e.Message = string.Format(CultureInfo.CurrentCulture, "Not Found: {0}", this.Name);
        }
    }
}
