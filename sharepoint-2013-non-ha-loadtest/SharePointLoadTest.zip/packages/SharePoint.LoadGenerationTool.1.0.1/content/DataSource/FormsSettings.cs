﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FormsSettings.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   The form based authentiation settings.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Globalization;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The settings related to forms-based authentication.
    /// </summary>
    public class FormsSettings
    {
        /// <summary>
        /// Read forms settings from APP.CONFIG.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public FormsSettings(Configuration configuration)
        {
            AppSettingsSection formsSettings = configuration.GetSection("testSettings/formsSettings") as AppSettingsSection;
            if (formsSettings != null)
            {
                this.TotalUserCount = Convert.ToInt32(formsSettings.Settings[Constants.TotalUserCount].Value, CultureInfo.InvariantCulture);
                this.Password = formsSettings.Settings[Constants.Password].Value;
                bool enableCachedCookie;
                if (!bool.TryParse(formsSettings.Settings[Constants.EnableCachedCookie].Value, out enableCachedCookie))
                {
                    enableCachedCookie = false;
                }

                this.EnableCachedCookie = enableCachedCookie;
            }
        }

        /// <summary>
        /// Gets the total user count.
        /// </summary>
        /// <value>
        /// The total user count.
        /// </value>
        public int TotalUserCount { get; private set; }

        /// <summary>
        /// Gets the password.
        /// </summary>
        /// <value>
        /// The password.
        /// </value>
        public string Password { get; private set; }

        /// <summary>
        /// Gets a value indicating whether EnableCachedCookie is enabled or not.
        /// </summary>
        /// <value>
        /// The EnableCachedCookie.
        /// </value>
        public bool EnableCachedCookie { get; private set; }
    }
}
