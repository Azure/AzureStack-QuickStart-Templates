﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CommonSettings.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   This class is to read the common settings from App.Config.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// The Common Setting for all authentications.
    /// </summary>
    public class CommonSettings
    {
        /// <summary>
        /// Read common settings from APP.CONFIG.
        /// </summary>
        /// <param name="configuration">The configuration.</param>
        public CommonSettings(Configuration configuration)
        {
            AppSettingsSection commonSettings = configuration.GetSection("testSettings/commonSettings") as AppSettingsSection;
            if (commonSettings != null)
            {
                this.PersonalSitePath = commonSettings.Settings[Constants.PersonalSitePath].Value;
                this.LoadBalancer = commonSettings.Settings[Constants.LoadBalancer].Value;
                string temp = commonSettings.Settings[Constants.AuthenticationType].Value;
                AuthenticationType authenticationType;
                if (Enum.TryParse<AuthenticationType>(temp, out authenticationType))
                {
                    this.AuthenticationType = authenticationType;
                }

                int port;
                this.FrontendServerPort = int.TryParse(commonSettings.Settings[Constants.FrontendServerPort].Value, out port) ? port : 11207;

                string frontendServerNames = commonSettings.Settings[Constants.FrontendServerNames].Value;
                this.FrontendServerNames = new List<string>();
                if (!string.IsNullOrWhiteSpace(frontendServerNames))
                {
                    foreach (var frontend in frontendServerNames.Split(','))
                    {
                        this.FrontendServerNames.Add(frontend.Trim());
                    }
                }
            }
        }

        /// <summary>
        /// Gets the Personal Site path.
        /// </summary>
        /// <value>
        /// The Personal Site Path.
        /// </value>
        public string PersonalSitePath { get; private set; }

        /// <summary>
        /// Gets the Frontend Server names.
        /// </summary>
        /// <value>
        /// The Frontend Server Names.
        /// </value>
        public IList<string> FrontendServerNames { get; private set; }

        /// <summary>
        /// Gets the Frontend Server Port.
        /// </summary>
        /// <value>
        /// The Frontend Server Port.
        /// </value>
        public int FrontendServerPort { get; private set; }

        /// <summary>
        /// Gets the load balancer name.
        /// </summary>
        /// <value>
        /// The Load Balancer.
        /// </value>
        public string LoadBalancer { get; private set; }

        /// <summary>
        /// Gets the Authentication type.
        /// <value>
        /// The Authentication Type
        /// </value>
        /// </summary>
        /// <value>The value of Authentication Type.</value>
        public AuthenticationType AuthenticationType { get; private set; }
    }
}
