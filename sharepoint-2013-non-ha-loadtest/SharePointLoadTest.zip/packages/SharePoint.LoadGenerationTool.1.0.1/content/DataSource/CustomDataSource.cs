﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CustomDataSource.cs" company="Microsoft">
//   Copyright @2015 Microsoft Corporation.  All rights reserved.
// </copyright>
// <summary>
//   This class is to provide a customized data source which includes
//     UserName/Password/SiteUrl/PersonalSitePath/LoadBalancer, etc.
// </summary>
// --------------------------------------------------------------------------------------------------------------------

using System;
using System.Collections.Generic;
using System.Configuration;
using System.Globalization;

namespace Microsoft.SharePoint.LoadGenerationTool
{
    /// <summary>
    /// This class is to provide a customized data source which includes
    ///     UserName/Password/SiteUrl/PersonalSitePath/LoadBalancer, etc.
    /// </summary>
    public class CustomDataSource
    {
        private static HashSet<string> agentFrontendServerUserKeys = new HashSet<string>();

        private static int userCounter = 0;

        private static object locker = new object();

        private int? currentId;

        private Configuration configuration;

        private CommonSettings commonSettings;

        private FormsSettings formsSettings;

        /// <summary>
        /// Initializes a new instance of the <see cref="CustomDataSource"/> class.
        /// </summary>
        public CustomDataSource()
        {
            ExeConfigurationFileMap fileMap = new ExeConfigurationFileMap();
            fileMap.ExeConfigFilename = "App.Config";
            this.configuration = ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
            this.commonSettings = new CommonSettings(this.configuration);
            this.formsSettings = new FormsSettings(this.configuration);
        }

        /// <summary>
        /// Gets next user name and password and related configurations.
        /// </summary>
        /// <returns>
        /// The <see cref="Dictionary"/>.
        /// </returns>
        /// <value>The context information for next user.</value>
        public Dictionary<string, string> NextRow
        {
            get
            {
                // create an object to hold the name value pairs
                var dictionary = new Dictionary<string, string>();

                // add each column to the dictionary
                dictionary.Add(Constants.IsAuthenticated, this.IsAuthenticated.ToString());
                dictionary.Add(Constants.UserName, this.UserName);
                dictionary.Add(Constants.Password, this.Password);
                dictionary.Add(Constants.SiteUrl, this.SiteUrl);
                dictionary.Add(Constants.PersonalSitePath, this.commonSettings.PersonalSitePath);
                dictionary.Add(Constants.LoadBalancer, this.commonSettings.LoadBalancer);
                dictionary.Add(Constants.AuthenticationType, this.commonSettings.AuthenticationType.ToString());
                return dictionary;
            }
        }

        /// <summary>
        /// Gets current frontend server.
        /// </summary>
        /// <value>
        /// The current frontend Server.
        /// </value>
        private string CurrentFrontendServer
        {
            get
            {
                if (string.IsNullOrWhiteSpace(this.commonSettings.LoadBalancer))
                {
                    int frontendServerCount = this.commonSettings.FrontendServerNames.Count;
                    return this.commonSettings.FrontendServerNames[this.CurrentId % frontendServerCount];
                }
                else
                {
                    return this.commonSettings.LoadBalancer;
                }
            }
        }

        /// <summary>
        /// Gets a value indicating whether current user authenticated or not.
        /// </summary>
        private bool IsAuthenticated
        {
            get
            {
                if (this.formsSettings.EnableCachedCookie)
                {
                    string compositeKey = Environment.MachineName + "_" + this.CurrentId + "_" + this.CurrentFrontendServer;
                    if (!agentFrontendServerUserKeys.Contains(compositeKey))
                    {
                        agentFrontendServerUserKeys.Add(Environment.MachineName + this.CurrentId);
                    }
                    else
                    {
                        return true;
                    }
                }

                return false;
            }
        }

        /// <summary>
        /// Gets the current user sequence Id. 
        /// It starts from 1.
        /// </summary>
        private int CurrentId
        {
            get
            {
                if (this.currentId.HasValue)
                {
                    return this.currentId.Value;
                }
                else
                {
                    lock (locker)
                    {
                        // if you have reached the end of the cursor, loop back around to the beginning
                        if (userCounter >= this.formsSettings.TotalUserCount)
                        {
                            userCounter = 1;
                        }

                        this.currentId = userCounter;
                        userCounter++;
                        return this.currentId.Value;
                    }
                }
            }
        }

        /// <summary>
        /// Gets the password.
        /// </summary>
        private string Password
        {
            get
            {
                return this.formsSettings.Password;
            }
        }

        /// <summary>
        /// Gets the user name.
        /// </summary>
        private string UserName
        {
            get
            {
                return string.Concat(Constants.UserNamePrefix, this.CurrentId.ToString(CultureInfo.InvariantCulture));
            }
        }

        /// <summary>
        /// Gets the Site Url.
        /// </summary>
        private string SiteUrl
        {
            get
            {
                return Constants.HttpPrefix + this.CurrentFrontendServer + Constants.Colon + this.commonSettings.FrontendServerPort;
            }
        }
    }
}