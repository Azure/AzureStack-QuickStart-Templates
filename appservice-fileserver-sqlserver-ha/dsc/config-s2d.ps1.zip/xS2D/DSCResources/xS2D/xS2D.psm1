﻿#
# xS2D: DSC resource to configure a Storace Space Direct and create a volume.
#

function Get-TargetResource
{
    param
    (
        [parameter(Mandatory)]
        [string] $StoragePoolName,

        [parameter(Mandatory)]
        [string] $VolumeName
    )

    @{
        StoragePoolName = $StoragePoolName
        VolumeName = $VolumeName
        VolumeState = (Get-ClusterSharedVolume -Name "Cluster Virtual Disk ($VolumeName)" -ErrorAction SilentlyContinue).State
        VolumeOwnerNode = (Get-ClusterSharedVolume -Name "Cluster Virtual Disk ($VolumeName)" -ErrorAction SilentlyContinue).OwnerNode
    }
}

function Set-TargetResource
{
    param
    (
        [parameter(Mandatory)]
        [string] $StoragePoolName,

        [parameter(Mandatory)]
        [string] $VolumeName
    )

    $retryCounter = 0

    While ($true) {
        try {
            Write-Verbose -Message "Enabled Storage Space Direct with storage pool '$($StoragePoolName)' ..."
            Enable-ClusterStorageSpacesDirect -Confirm:0 -PoolFriendlyName $StoragePoolName -ErrorAction Stop
            Write-Verbose -Message "Successfully enabled Storage Space Direct with storage pool '$($StoragePoolName)'."
            Write-Verbose -Message "Creating new volume '$($VolumeName)' on storage pool '$($StoragePoolName)' ..."
            New-Volume -StoragePoolFriendlyName $StoragePoolName -FriendlyName $VolumeName -FileSystem CSVFS_REFS -UseMaximumSize -ErrorAction Stop
            Write-Verbose -Message "Successfully created new volume '$($VolumeName)' on storage pool '$($StoragePoolName)' ..."
            return $true
        }
        catch [System.Exception] 
        {
            $retryCounter = $retryCounter + 1
            $ErrorMSG = "Error occurred : '$($_.Exception.Message)', failed after '$($retryCounter)' times"
            if ($retryCounter -eq 10) 
            {
                Write-Verbose "Error occurred : $ErrorMSG, reach the maximum retry: '$($retryCounter)' times, exiting...."
                Throw $ErrorMSG
            }
            Write-Verbose "Error occurred : $ErrorMSG, retry for '$($retryCounter)' times"
            start-sleep -seconds 30
        }
    }
}

#
# The Test-TargetResource function will check if the cluster shared volume exists and is online
#
function Test-TargetResource
{
    param
    (
        [parameter(Mandatory)]
        [string] $StoragePoolName,

        [parameter(Mandatory)]
        [string] $VolumeName
    )

    return (Get-ClusterSharedVolume -Name "Cluster Virtual Disk ($VolumeName)" -ErrorAction SilentlyContinue).State -eq 'Online'
}

Export-ModuleMember -Function *-TargetResource
