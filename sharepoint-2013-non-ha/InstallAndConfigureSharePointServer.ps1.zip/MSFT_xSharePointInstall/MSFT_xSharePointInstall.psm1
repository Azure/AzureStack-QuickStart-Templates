Import-LocalizedData LocalizedData -filename MSFT_xSharePointInstall.strings.psd1
Import-Module $PSScriptRoot\..\..\xPDT.psm1

#region GET
function Get-TargetResource 
{
    [CmdletBinding()]
     param
    (
        [Parameter(Mandatory=$true)]
        [String]
        $SourcePath,

        [String]
        $SourceFolder,
        
        [Parameter(Mandatory=$true)]
        [ValidateSet("Setup","SetupFarm", "SetupFarmSilent", "SetupFarmUpgrade", "SetupSilent", "SetupSilentUpgrade")]
        [System.String]
        $Config,
        
        [Parameter(Mandatory=$true)]
        [PSCredential]
        $Credential
    )
        
    $Path = Join-Path -Path (Join-Path -Path $SourcePath -ChildPath $SourceFolder) -ChildPath "setup.exe"
    $Path = ResolvePath $Path
    $Version = (Get-Item -Path $Path).VersionInfo.ProductVersion

    switch($Version)
    {
        "15.0.4454.1000"
        {
            $IdentifyingNumber = '{90150000-110D-0000-1000-0000000FF1CE}'
        }
        Default
        {
            throw $LocalizedData.UnknownVersion
        }
    }
        
    $Product = Get-WmiObject -Class Win32_Product | Where-Object {$_.IdentifyingNumber -eq $IdentifyingNumber}

	return @{
		SourcePath = $SourcePath
        SourceFolder = $SourceFolder
		Config = $Config
		Credential = $Credential
		Result = $Product
		}
}
# Get-TargetResource -SourcePath 'F:\Setup.exe' -Config 'SetupFarmSilent' -Credential (get-credential)
# Expectation is the function will return a hashtable with a boolean for Result to indicate whether the application is install and information about how the application was installed
#endregion

#region SET
function Set-TargetResource
{
    [CmdletBinding()]
     param
    (
        [Parameter(Mandatory=$true)]
        [String]
        $SourcePath,

        [String]
        $SourceFolder,
        
        [Parameter(Mandatory=$true)]
        [ValidateSet("Setup","SetupFarm", "SetupFarmSilent", "SetupFarmUpgrade", "SetupSilent", "SetupSilentUpgrade")]
        [System.String]
        $Config,
        
        [Parameter(Mandatory=$true)]
        [PSCredential]
        $Credential
    )

    $Path = Join-Path -Path (Join-Path -Path $SourcePath -ChildPath $SourceFolder) -ChildPath "setup.exe"
    $Path = ResolvePath $Path
    Write-Verbose "Path: $Path"

    $ConfigPath = Join-Path -Path (Join-Path -Path $SourcePath -ChildPath $SourceFolder) -ChildPath "files\$Config\config.xml"
    $ConfigPath = ResolvePath $ConfigPath
    Write-Verbose "ConfigPath: $ConfigPath"

    $Arguments = "/config $ConfigPath"
	
	$Process = StartWin32Process -Path $Path -Arguments $Arguments -Credential $Credential
	Write-Verbose $Process
	WaitForWin32ProcessEnd -Path $Path -Arguments $Arguments -Credential $Credential

    $Test = Test-TargetResource @PSBoundParameters

    if ($Test -eq $true) 
    {
        Write-Verbose 'Installation successful.  Reboot pending'
        $Global:DSCMachineStatus = 1
    }
    else
    {
        Throw 'The SharePoint installation failed.  Verify the path and folder, then check the SharePoint log files for details.'
    }

}
# Set-TargetResource -Path 'F:\Setup.exe' -Config 'SetupFarmSilent' -Credential (get-credential)
# Expectation is the application would be installed silently
#endregion

#region TEST
function Test-TargetResource 
{
    [CmdletBinding()]
     param
    (
        [Parameter(Mandatory=$true)]
        [String]
        $SourcePath,

        [String]
        $SourceFolder,
        
        [Parameter(Mandatory=$true)]
        [ValidateSet("Setup","SetupFarm", "SetupFarmSilent", "SetupFarmUpgrade", "SetupSilent", "SetupSilentUpgrade")]
        [System.String]
        $Config,
        
        [Parameter(Mandatory=$true)]
        [PSCredential]
        $Credential
    )

    $Path = Join-Path -Path (Join-Path -Path $SourcePath -ChildPath $SourceFolder) -ChildPath 'setup.exe'
    $Path = ResolvePath $Path
    $Version = (Get-Item -Path $Path).VersionInfo.ProductVersion

    switch($Version)
    {
        "15.0.4454.1000"
        {
            $IdentifyingNumber = '{90150000-110D-0000-1000-0000000FF1CE}'
        }
        Default
        {
            throw $LocalizedData.UnknownVersion
        }
    }
        
    If (Get-WmiObject -Class Win32_Product | Where-Object {$_.IdentifyingNumber -eq $IdentifyingNumber})
    {
        $Result = $true
    }
    Else
    {
        $Result = $false
    }

    return $Result
}
# Test-TargetResource -Path 'F:\Setup.exe' -Config 'SetupFarmSilent' -Credential (get-credential)
# Expectation is a boolean response based on whether the application is installed
#endregion

Export-ModuleMember -Function *-TargetResource