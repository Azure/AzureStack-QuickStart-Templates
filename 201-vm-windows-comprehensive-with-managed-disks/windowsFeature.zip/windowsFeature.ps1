﻿configuration EnalbeWindowsFeature 
{ 
   param 
   ( 
        [Parameter(Mandatory)]
        [String]$featureName
        
    ) 

    Node localhost
    {
        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = $featureName
        }
        
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }
   }
} 