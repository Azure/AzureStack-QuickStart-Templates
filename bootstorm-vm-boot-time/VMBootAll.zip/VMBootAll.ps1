#
# Copyright="?Microsoft Corporation. All rights reserved."
#
Configuration ConfigureVMBootAll
{
	param (
        [Parameter(Mandatory)]
        [string]$AzureAccountUsername,
        [Parameter(Mandatory)]
        [string]$AzureAccountPassword,
        [Parameter(Mandatory)]
        [string]$TenantId,
        [Parameter(Mandatory)]
        [string]$Location,
        [Parameter(Mandatory)]
        [string]$VMName,
        [Parameter(Mandatory)]
        [int32]$VMCount,
        [Parameter(Mandatory)]
        [string]$VMAdminUserName,
        [Parameter(Mandatory)]
        [string]$VMAdminPassword,
        [Parameter(Mandatory)]
        [string]$AzureStorageAccount,
        [Parameter(Mandatory)]
        [string]$AzureStorageAccessKey,
        [Parameter(Mandatory)]
        [string]$AzureStorageEndpoint
    )

    # Turn off private firewall
    netsh advfirewall set privateprofile state off
    # Get full path and name of the script being run
    $PSPath = $PSCommandPath

	######################
    ### AZURE RM SETUP ###
    ######################
    # AzureStack
    if($location.Contains("local"))
    {
        # Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
        add-type @"
        using System.Net;
        using System.Security.Cryptography.X509Certificates;
        public class TrustAllCertsPolicy : ICertificatePolicy {
            public bool CheckValidationResult(
                ServicePoint srvPoint, X509Certificate certificate,
                WebRequest request, int certificateProblem) {
                return true;
            }
        }
"@
        [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
        Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

        # Download AzureStack Powershell SDK - https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi 
        $azureStackPSMsi = "https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi"
        $dest = Join-Path $env:SystemDrive "AzureStack"
        $path = Join-Path $dest "azure-powershell.1.2.0.msi"
        if(Test-Path $dest){
            Write-Verbose "Skipped downloading file $azureStackPSMsi"
        }
        else {
            try {
                New-Item $dest -ItemType Directory -Force -Confirm:0
                $wc = New-Object System.Net.WebClient
                $wc.DownloadFile($azureStackPSMsi, $path)
            } catch {
                Write-Error "Exception in downloading Azure Stack Powershell SDK."
            }
        }

        # Install AzureStack Powershell SDK
        $azureStackSdkPath = Join-Path ${env:ProgramFiles(x86)} "Microsoft SDKs\Azure"
        if((Test-Path $azureStackSdkPath) -eq $false){
            $arguments = "/qn /passive"
            $process = Start-Process -FilePath $path -ArgumentList $arguments -Wait -PassThru -NoNewWindow
            # EXIT CODES: 3010/1641 - Application installed and requested a reboot
            if ($process.ExitCode -gt 0 -and $process.ExitCode -ne 3010 -and $process.ExitCode -ne 1641) {
                Write-Error "Installer operation $path $arguments failed with exit code $($process.ExitCode)!"
            } elseif ($process.ExitCode -eq -2145124329){
                Write-Warning "Installer operation is not applicable/needed."
            } else {
                Write-Verbose "Installer operation $path $arguments completed successfully."
            }
        }
                
        # Import Azure Resource Manager PS module if already present
        try {
            Write-Verbose "Importing Azure module"
            Import-Module Azure -ErrorAction Stop | Out-Null
        } catch [Exception] {
            Write-Error "Cannot import Azure module. Cannot proceed further without Azure module. Exception: $_"
            return
        }
    }
    # Azure Cloud
    else {
        # Import Azure Resource Manager PS module if already present
        try {
            Write-Verbose "Importing Azure module"
            Import-Module Azure -ErrorAction Stop | Out-Null
            Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
        }
        # Install Azure Resource Manager PS module
        catch {
            # Suppress prompts
            $ConfirmPreference = 'None'
            Write-Warning "Cannot import Azure module, proceeding with installation"

            # Install AzureRM
            try {
                Get-PackageProvider -Name nuget -ForceBootstrap -Force | Out-Null
                Install-Module Azure �repository PSGallery �Force -Confirm:0 | Out-Null
                Install-Module AzureRM.Compute �repository PSGallery �Force -Confirm:0 | Out-Null
            }
            catch {
                Write-Error "Installation of Azure module failed."
            }

            # Import AzureRM
            try {
                Import-Module Azure -ErrorAction Stop | Out-Null
                Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
                Import-Module AzureRM.Profile -ErrorAction Stop | Out-Null
            } catch {
                Write-Error "Cannot import Azure module. Cannot proceed further without Azure module."
                return
            }
        }
    }

    # DSC Script Resource - VM Bootstorm
    Script VMBAll
    {
        TestScript = { (Get-ScheduledTask -TaskName "VMBootAll" -ErrorAction SilentlyContinue) -ne $null }

        GetScript = { return @{"TaskName" = "VMBootAll"} }

        SetScript = {
            # Azure uses AzureAdApplicationId and AzureAdApplicationPassword values as AzureUserName and AzurePassword parameters respectively
            # AzureStack uses tenant UserName and Password values as AzureUserName and AzurePassword parameters respectively
            $azureUsername = $using:AzureAccountUsername
            $azurePassword = $using:AzureAccountPassword
            $tenant = $using:TenantId
            $location = $using:Location
            $vmName = $using:VMName
            $vmCount = $using:VMCount
            # Scheduled task execution credentials without any logged-in user
            $vmAdminUserName = $using:VMAdminUserName
            $vmAdminPassword = $using:VMAdminPassword
            $storageAccount = $using:AzureStorageAccount
            $storageKey = $using:AzureStorageAccessKey
			$storageEndpoint = $using:AzureStorageEndpoint
            if($storageEndpoint.Contains("Blob")){
                $storageEndpoint = $storageEndpoint.Substring($storageEndpoint.LastIndexOf("blob") + "blob".Length + 1).replace("/", "").ToLower()
            }
            if($storageEndpoint.Contains(":")) {
                $storageEndpoint = $storageEndpoint.Substring(0, $storageEndpoint.LastIndexOf(":"))
            }
            $psPath = $using:PSPath
            $psScriptDir = Split-Path -Parent -Path $psPath
            $psScriptName = "VMBootAllScript.ps1"
            $psScriptPath = "$psScriptDir\$psScriptName"
            $action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "& $psScriptPath -azureUserName $azureUsername -azurePassword $azurePassword -tenant $tenant -location $location -vmName $vmName -vmCount $vmCount -azureStorageAccount $storageAccount -azureStorageAccessKey $storageKey -azureStorageEndpoint $storageEndpoint -Verbose" -ErrorAction Ignore
            $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Minutes 10) -RepetitionDuration (New-TimeSpan -Minutes 30) -ErrorAction Ignore
            $settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 2) -ErrorAction Ignore
            Unregister-ScheduledTask -TaskName "VMBootAll" -Confirm:0 -ErrorAction Ignore
            Register-ScheduledTask -Action $action -Trigger $trigger -Settings $settings -TaskName "VMBootAll" -Description "VMBootstorm" -User $vmAdminUserName -Password $vmAdminPassword -RunLevel Highest -ErrorAction Ignore
        }
    }	
}
