#
# Copyright="� Microsoft Corporation. All rights reserved."
#

configuration deploySqlStandalone
{
    param
    (
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [String]$PrimaryADIP,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$SQLServicecreds,

        [UInt32]$DatabaseEnginePort = 1433,

        [String]$DomainNetbiosName=(Get-NetBIOSName -DomainName $DomainName),

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )

    Import-DscResource -ModuleName xComputerManagement,CDisk,xActiveDirectory,XDisk,xSql, xSQLServer, xSQLps,xNetworking, xDeploy
    [System.Management.Automation.PSCredential]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential]$SQLCreds = New-Object System.Management.Automation.PSCredential ("${DomainNetbiosName}\$($SQLServicecreds.UserName)", $SQLServicecreds.Password)

    Install-WindowsFeature -Name RSAT-DNS-Server
    $currentDNS = (Get-DnsClientServerAddress -InterfaceAlias Ethernet -Family IPv4).ServerAddresses
    $newdns = @($PrimaryADIP) + $currentDNS
    Set-DnsClientServerAddress -InterfaceAlias Ethernet -ServerAddresses $newdns
    ipconfig /flushdns


    Node localhost
    {
        xWaitforDisk Disk2
        {
             DiskNumber = 1
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
        }

        cDiskNoRestart DataDisk
        {
            DiskNumber = 1
            DriveLetter = "F"
            DependsOn = '[xWaitforDisk]Disk2'
        }

        xWaitforDisk Disk3
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
             DependsOn = '[cDiskNoRestart]DataDisk'
        }

        cDiskNoRestart LogDisk
        {
            DiskNumber = 2
            DriveLetter = "G"
            DependsOn = '[xWaitforDisk]Disk3'
        }

        WindowsFeature FC
        {
            Name = "Failover-Clustering"
            Ensure = "Present"
            DependsOn = '[cDiskNoRestart]LogDisk'
        }

        WindowsFeature FCPS
        {
            Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
            DependsOn = '[WindowsFeature]FC'
        }

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            DependsOn = '[WindowsFeature]FCPS'
        }


        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec 
            DependsOn = '[WindowsFeature]ADPS'
        }
        xComputer DomainJoin
        {
            Name = $env:COMPUTERNAME
            DomainName = $DomainName
            Credential = $DomainCreds
            DependsOn = '[xWaitForADDomain]DscForestWait'
        }

        File SQLUpdatesFolder
        {
            Ensure = "Present"
            Type = "Directory"
            DestinationPath = "C:\SQL2014\Updates"
            DependsOn = '[xComputer]DomainJoin'
        }

        xSqlServerSetup InstallSqlServer
        {
            InstanceName =  "MSSQLSERVER"
            SourcePath = "C:"
            SourceFolder = "\SQL2014"
            UpdateSource = ".\Updates"
            UpdateEnabled = "False"
            SQLSysAdminAccounts = $DomainCreds.username
            Credential = $DomainCreds
            Features= "SQLENGINE,SSMS"
            SecurityMode="SQL"
            SAPwd=$SQLCreds
            SQLUserDBDir = "F:\SQL\Data"
            SQLUserDBLogDir = "G:\SQL\Log"
            DependsOn = '[File]SQLUpdatesFolder'
        }

        xFirewall DatabaseEngineFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Engine-TCP-In"
            DisplayName = "SQL Server Database Engine (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Engine."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = $DatabaseEnginePort -as [String]
            Ensure = "Present"
            DependsOn = '[xSqlServerSetup]InstallSqlServer'
        }

        xFirewall DatabaseMirroringFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Database-Mirroring-TCP-In"
            DisplayName = "SQL Server Database Mirroring (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Database Mirroring."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "5022"
            Ensure = "Present"
            DependsOn = '[xFirewall]DatabaseEngineFirewallRule'
        }

        xFirewall ListenerFirewallRule
        {
            Direction = "Inbound"
            Name = "SQL-Server-Availability-Group-Listener-TCP-In"
            DisplayName = "SQL Server Availability Group Listener (TCP-In)"
            Description = "Inbound rule for SQL Server to allow TCP traffic for the Availability Group listener."
            DisplayGroup = "SQL Server"
            State = "Enabled"
            Access = "Allow"
            Protocol = "TCP"
            LocalPort = "59999"
            Ensure = "Present"
            DependsOn = '[xFirewall]DatabaseMirroringFirewallRule'
        }
        
        xADUser CreateSqlServerServiceAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName = $DomainName
            UserName = $SQLServicecreds.UserName
            Password = $SQLServicecreds
            Ensure = "Present"
            DependsOn = '[xFirewall]ListenerFirewallRule'
        }

        xSqlLogin AddSqlServerServiceAccountToSysadminServerRole
        {
            Name = $SQLCreds.UserName
            LoginType = "WindowsUser"
            ServerRoles = "sysadmin"
            Enabled = $true
            Credential = $DomainCreds
            DependsOn = "[xADUser]CreateSqlServerServiceAccount"
        }
        

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $True
        }

    }
}

function Get-NetBIOSName
{ 
    [OutputType([string])]
    param(
        [string]$DomainName
    )

    if ($DomainName.Contains('.')) {
        $length=$DomainName.IndexOf('.')
        if ( $length -ge 16) {
            $length=15
        }
        return $DomainName.Substring(0,$length)
    }
    else {
        if ($DomainName.Length -gt 15) {
            return $DomainName.Substring(0,15)
        }
        else {
            return $DomainName
        }
    }
}

function WaitForSqlSetup
{
    # Wait for SQL Server Setup to finish before proceeding.
    while ($true)
    {
        try
        {
            Get-ScheduledTaskInfo "\ConfigureSqlImageTasks\RunConfigureImage" -ErrorAction Stop
            Start-Sleep -Seconds 5
        }
        catch
        {
            break
        }
    }
}
