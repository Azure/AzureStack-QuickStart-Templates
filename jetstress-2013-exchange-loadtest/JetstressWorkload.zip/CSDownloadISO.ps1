param (
	[Parameter(Mandatory)]
    [string]$uri,
	[Parameter(Mandatory)]
    [string]$destination
)

function DownloadISO {
	
	
	if(Test-Path $destination) {
		Write-Verbose "Destination path exists. Skipping ISO download"
		return
	}
	
	$destination = Join-Path $env:SystemDrive $destination
	New-Item -Path $destination -ItemType Directory

	$destinationFile = $null
	$stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $result = $false
	# Download ISO
    try
    {
        Write-Verbose "Downloading URI: $uri ($sizeInBytes bytes) to path: $destination"
		$isoFileName = [System.IO.Path]::GetFileName($uri)
        $webClient = New-Object System.Net.WebClient
        $_date = Get-Date -Format hh:mmtt
		$destinationFile = "$destination\$isoFileName"
        $webClient.DownloadFile($uri, $destinationFile)
        $_date = Get-Date -Format hh:mmtt
        if((Test-Path $destinationFile) -eq $true) {
            Write-Verbose "Downloading ISO file succeeded at $_date"
			$result = $true
        }
        else {
            Write-Error "Downloading ISO file failed at $_date"
            $result = $false
        }
    } catch [Exception] {
		Write-Verbose "Failed to download ISO. Exception: $_"
		Remove-Item $destination -Force -Confirm:0 -ErrorAction SilentlyContinue
	}
	
	# Extract ISO
	if($result)
    {
        Write-Verbose "Mount the image from $destinationFile"
        $image = Mount-DiskImage -ImagePath $destinationFile -PassThru
        $driveLetter = ($image | Get-Volume).DriveLetter

        Write-Verbose "Copy files to destination directory: $destination"
        Robocopy.exe ("{0}:" -f $driveLetter) $destination /E | Out-Null
    
        Write-Verbose "Dismount the image from $destinationFile"
        Dismount-DiskImage -ImagePath $destinationFile
    
        #Write-Verbose "Delete the temp file: $destinationFile"
        #Remove-Item -Path $destinationFile -Force
    }
    else
    {
		Remove-Item $destination -Force -Confirm:0 -ErrorAction SilentlyContinue
        Throw "Failed to download the file after exhaust retry limit"
    }
}

DownloadISO