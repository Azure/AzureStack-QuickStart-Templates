#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureJetstress
{
	param
    (
		[Parameter(Mandatory=$true)]
		[String]$ExecutionTime,
		
		[Parameter(Mandatory=$true)]
		[String]$AutoSeek,

		[Parameter(Mandatory=$true)]
		[String]$ThreadCount,

		[Parameter(Mandatory=$true)]
		[String]$TestType,
		
		[Parameter(Mandatory=$true)]
		[String]$StorageCapacityPercentage,
		
		[Parameter(Mandatory=$true)]
		[String]$IopsCapacityPercentage,
		
		[Parameter(Mandatory=$true)]
		[String]$MailboxCount,
		
		[Parameter(Mandatory=$true)]
		[String]$IopsPerMailbox,
		
		[Parameter(Mandatory=$true)]
		[String]$MailboxSizeinMB,

		[Parameter(Mandatory=$true)]
		[PSCredential]$VMAdminCreds,

		[Parameter(Mandatory=$true)]
		[String]$StorageAccountName,

		[Parameter(Mandatory=$true)]
		[String]$StorageAccountKey,
		
		[Parameter(Mandatory=$true)]
		[String]$StorageEndpoint
		
	)

	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($VMAdminCreds.UserName)", $VMAdminCreds.Password)

	#Get-PackageProvider -Name nuget -ForceBootstrap -Force;
	Import-DscResource -ModuleName 'PSDesiredStateConfiguration';
	Import-DscResource -ModuleName xDisk;
	Import-DscResource -ModuleName xDownloadFile;
	Import-DscResource -ModuleName xDownloadISO;
	Import-DscResource -ModuleName xInstaller;
	Import-DscResource -ModuleName xJetstress;
	Import-DscResource -ModuleName xPendingReboot;
	Import-DscResource -ModuleName xPSDesiredStateConfiguration;
	Import-DscResource -ModuleName xAzureStorageCopy;

	# Downloaded file storage location
	$downloadPath = "$env:SystemDrive\DownloadsForDSC";
	$exchangeBinariesPath = "$env:SystemDrive\DownloadsForDSC\Exchange2016Binaries"

	Node localhost
    {
		xWaitforDisk Disk3
        {
            DiskNumber = 1
            RetryIntervalSec = 60
            RetryCount = 60
        }
        xDisk FVolume
        {
			DiskNumber = 1
            DriveLetter = 'F'
			DependsOn = '[xWaitforDisk]Disk3'
        }
		# Download AzCopy
		xDownloadFile DownloadAzCopy
		{
			SourcePath = "http://aka.ms/downloadazcopy"
			FileName = "MicrosoftAzureStorageTools.msi"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xDisk]FVolume"
		}
		# Install AzCopy
		xInstaller InstallAzCopy
		{
			Path = "$downloadPath\MicrosoftAzureStorageTools.msi"
			Arguments = "/quiet /passive /qn"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadAzCopy"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Download Jetstress 2013 
		xDownloadFile DownloadJetstress
		{
			SourcePath = "https://download.microsoft.com/download/C/2/4/C2484C53-5251-4278-A7C2-95739BFDD7CE/Jetstress.msi"
			FileName = "Jetstress.msi"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xInstaller]InstallAzCopy"
		}
		# Install Jetstress
		xInstaller InstallJetstress
		{
			Path = "$downloadPath\Jetstress.msi"
			Arguments = "/quiet /passive /qn"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Download and Extract Exchange 2016 Cumulative Update 1 to get required binaries for Jetstress
		xDownloadISO DownloadExchangeCU1 
		{
			SourcePath = "https://download.microsoft.com/download/6/4/8/648EB83C-00F9-49B2-806D-E46033DA4AE6/ExchangeServer2016-CU1.iso"
            DestinationDirectoryPath = $exchangeBinariesPath
            DependsOn = '[xInstaller]InstallJetstress'
		}
		# Prepare Jetstress
		xJetstressSetup SetupJetstress
		{
			ExchangeInstallerLocation = $exchangeBinariesPath
			DependsOn = "[xDownloadISO]DownloadExchangeCU1"
			PsDscRunAsCredential = $VMAdminCreds
		}
		xJetstressTest RunJetstress
		{
			DatabasePath = "F:\Database"
			LogPath = "F:\Logs"
			OutputPath = "$env:SystemDrive\JetstressOutput"
			ExecutionTime = $ExecutionTime
			AutoSeek = $AutoSeek
			ThreadCount = $ThreadCount
			TestType = $TestType
			StorageCapacityPercentage = $StorageCapacityPercentage
			IopsCapacityPercentage = $IopsCapacityPercentage
			MailboxCount = $MailboxCount
			IopsPerMailbox= $IopsPerMailbox
			MailboxSizeinMB = $MailboxSizeinMB
			DependsOn = "[xJetstressSetup]SetupJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Upload Jetstress result to blob
		xAzureStorageCopyUpload AzureStorageCopyUploadJetstressResult
		{
			SourcePath = "$env:SystemDrive\JetstressOutput"
			StorageAccountName = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			DependsOn = "[xJetstressTest]RunJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Reboot node if needed
		LocalConfigurationManager 
        {
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $True
        }
	}
}