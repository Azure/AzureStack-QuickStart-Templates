#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureJetstress
{
	param
    (
		[Parameter(Mandatory=$true)]
		[String]$ExecutionTime,
		
		[Parameter(Mandatory=$true)]
		[String]$AutoSeek,

		[Parameter(Mandatory=$true)]
		[String]$ThreadCount,

		[Parameter(Mandatory=$true)]
		[String]$TestType,
		
		[Parameter(Mandatory=$true)]
		[String]$StorageCapacityPercentage,
		
		[Parameter(Mandatory=$true)]
		[String]$IopsCapacityPercentage,
		
		[Parameter(Mandatory=$true)]
		[String]$MailboxCount,
		
		[Parameter(Mandatory=$true)]
		[String]$IopsPerMailbox,
		
		[Parameter(Mandatory=$true)]
		[String]$MailboxSizeinMB,
		
		[Parameter(Mandatory=$true)]
		[String]$Location,
		
		[Parameter(Mandatory=$true)]
		[String]$VMName,

		[Parameter(Mandatory=$true)]
		[PSCredential]$VMAdminCreds,

		[Parameter(Mandatory=$true)]
		[String]$StorageAccountName,

		[Parameter(Mandatory=$true)]
		[String]$StorageAccountKey,
		
		[Parameter(Mandatory=$true)]
		[String]$StorageEndpoint,
		
		[Parameter(Mandatory=$true)]
		[String]$ExchangeInstallerDriveLetter
	)

	# Local file storage location
	$localPath = "$env:SystemDrive"

    $summaryContainer = "summary"

	# Log file
	$logFileName = "JetstressWorkloadDSC.log"
	$logFilePath = "$localPath\$logFileName"
	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($VMAdminCreds.UserName)", $VMAdminCreds.Password)

	#Get-PackageProvider -Name nuget -ForceBootstrap -Force
    
    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
	Import-DscResource -ModuleName 'xDisk' -ModuleVersion "1.0"
	Import-DscResource -ModuleName 'xDownloadFile' -ModuleVersion "1.0"
	Import-DscResource -ModuleName 'xDownloadISO' -ModuleVersion "1.0"
	Import-DscResource -ModuleName 'xInstaller' -ModuleVersion "1.0"
	Import-DscResource -ModuleName 'xJetstress' -ModuleVersion "1.0"
	Import-DscResource -ModuleName 'xPendingReboot' -ModuleVersion "1.0"
	Import-DscResource -ModuleName 'xPSDesiredStateConfiguration' -ModuleVersion "3.7.0.0"
	Import-DscResource -ModuleName 'xAzureStorageCopy' -ModuleVersion "1.0" 

	$StorageEndpoint = $StorageEndpoint.ToLower()
	# Prepare storage context to upload results to Azure storage table
	if($StorageEndpoint.Contains("blob")) {
		$StorageEndpoint = $StorageEndpoint.Substring($StorageEndpoint.LastIndexOf("blob") + "blob".Length + 1)
		$StorageEndpoint = $StorageEndpoint.replace("/", "")
		# Remove port number from storage endpoint e.g. http://saiostorm.blob.azurestack.local:3456/
		if($StorageEndpoint.Contains(":")) {
			$StorageEndpoint = $StorageEndpoint.Substring(0, $StorageEndpoint.LastIndexOf(":"))
		}
	}
	"Azure storage endpoint $StorageEndpoint" | Tee-Object -FilePath $logFilePath -Append
	
	# Convert execution time from minutes to 1H00M0S format
	$executionTimeInMinutes = 0
	try {
		$_date = Get-Date -Format hh:mmtt
		"Converting Jetstress execution time from $ExecutionTime minutes to xxHxxMxxS format at $_date" | Tee-Object -FilePath $logFilePath -Append
		[int32]::TryParse($ExecutionTime, [ref]$executionTimeInMinutes) 
	} catch [Exception] {
		"Exception: $_" | Tee-Object -FilePath $logFilePath -Append
	}
	
	# Convert execution time in minutes to HHMMSS format
	[int32]$h = [int32]($executionTimeInMinutes / 60)
	[int32]$m = [int32]($executionTimeInMinutes % 60)
	try {
		$h = "{0:D2}" -f $h
		$m = "{0:D2}" -f $m
	} catch [Exception] {
		"Failed to convert execution time from $executionTimeInMinutes minutes to xxHxxMxxS format. Exception: $_" | Tee-Object -FilePath $logFilePath -Append
	}
	$ExecutionTime = $h.ToString() + "H" + $m.ToString() + "M00S"
	"Converted Jetstress execution time from $executionTimeInMinutes minutes to $ExecutionTime in xxHxxMxxS format." | Tee-Object -FilePath $logFilePath -Append
		
	######################
	### AZURE RM SETUP ###
	######################
	# AzureStack
	if($Location.Contains("local"))
	{
		# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
		add-type @"
		using System.Net;
		using System.Security.Cryptography.X509Certificates;
		public class TrustAllCertsPolicy : ICertificatePolicy {
			public bool CheckValidationResult(
				ServicePoint srvPoint, X509Certificate certificate,
				WebRequest request, int certificateProblem) {
				return true;
			}
		}
"@
		[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
		Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

		# Download AzureStack Powershell SDK - https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi 
		$azureStackPSMsi = "https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi"
		$dest = Join-Path $env:SystemDrive "AzureStack"
		$path = Join-Path $dest "azure-powershell.1.2.0.msi"
		if(Test-Path $dest) {
			"Skipped downloading file $azureStackPSMsi" | Tee-Object -FilePath $logFilePath -Append
		}
		else {
			try {
				"Downloading file $azureStackPSMsi at destination $dest" | Tee-Object -FilePath $logFilePath -Append
				New-Item $dest -ItemType Directory -Force -Confirm:0
				$wc = New-Object System.Net.WebClient
				$wc.DownloadFile($azureStackPSMsi, $path)
				"Downloading file $azureStackPSMsi at destination $dest completed" | Tee-Object $logFilePath -Append
			} catch {
				"Exception in downloading Azure Stack Powershell SDK." | Tee-Object $logFilePath -Append
			}
		}

		# Install AzureStack Powershell SDK
		$azureStackSdkPath = Join-Path ${env:ProgramFiles(x86)} "Microsoft SDKs\Azure"
		if((Test-Path $azureStackSdkPath) -eq $false) {
			$arguments = "/passive /norestart"
            "Installing Azure PS SDK with command Start-Process -FilePath $path -ArgumentList $arguments -Wait -PassThru" | Tee-Object -FilePath $logFilePath -Append
			$process = Start-Process -FilePath $path -ArgumentList $arguments -Wait -PassThru #-NoNewWindow
            "Installing Azure PS SDK finished" | Tee-Object -FilePath $logFilePath -Append
			# EXIT CODES: 3010/1641 - Application installed and requested a reboot
			if ($process.ExitCode -gt 0 -and $process.ExitCode -ne 3010 -and $process.ExitCode -ne 1641) {
				"Installer operation $path $arguments failed with exit code $($process.ExitCode)!" | Tee-Object $logFilePath -Append
			} elseif ($process.ExitCode -eq -2145124329){
				"Installer operation is not applicable/needed." | Tee-Object $logFilePath -Append
			} else {
				"Installer operation $path $arguments completed successfully." | Tee-Object $logFilePath -Append
			}
		}
				
		# Import Azure Resource Manager PS module if already present
		try {
			"Importing Azure module" | Tee-Object $logFilePath -Append
			Import-Module Azure -ErrorAction Stop | Out-Null
		} catch [Exception] {
			"Cannot import Azure module. Exception: $_" | Tee-Object $logFilePath -Append
		}
	}
	# Azure Cloud
	else {
		# Import Azure Resource Manager PS module if already present
		try {
			"Importing Azure module" | Tee-Object $logFilePath -Append
			Import-Module Azure -ErrorAction Stop | Out-Null
			Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
		} catch {
			# Suppress prompts
			$ConfirmPreference = 'None'
			"Cannot import Azure module, proceeding with installation" | Tee-Object $logFilePath -Append

			# Install AzureRM
			try {
				Get-PackageProvider -Name nuget -ForceBootstrap -Force
				Install-Module Azure –repository PSGallery –Force -Confirm:0
				Install-Module AzureRM.Compute –repository PSGallery –Force -Confirm:0
			} catch [Exception] {
				"Installation of Azure module failed." | Tee-Object $logFilePath -Append
			}

			# Import AzureRM
			try {
				Import-Module Azure -ErrorAction Stop | Out-Null
				Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
				Import-Module AzureRM.Profile -ErrorAction Stop | Out-Null
			} catch [Exception] {
				"Cannot import Azure module." | Tee-Object $logFilePath -Append
			}
		}
	}

	# Downloaded file storage location
	$downloadPath = "$env:SystemDrive\DownloadsForDSC"
	$exchangeBinariesPath = $ExchangeInstallerDriveLetter + "\InstallerExchange"
	$diskNumber = 1
	if($Location.ToLower() -eq "local") {
		$diskNumber = 1
	} else {
		$diskNumber = 2
	}

	Node localhost
    {
		xWaitforDisk Disk3
        {
            DiskNumber = $diskNumber
            RetryIntervalSec = 60
            RetryCount = 60
        }
        xDisk FVolume
        {
			DiskNumber = $diskNumber
            DriveLetter = 'F'
			DependsOn = '[xWaitforDisk]Disk3'
        }
		# Download AzCopy
		xDownloadFile DownloadAzCopy
		{
			SourcePath = "http://aka.ms/downloadazcopy"
			FileName = "MicrosoftAzureStorageTools.msi"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xDisk]FVolume"
		}
		# Install AzCopy
		xInstaller InstallAzCopy
		{
			Path = "$downloadPath\MicrosoftAzureStorageTools.msi"
			Arguments = "/quiet /passive /qn"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadAzCopy"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Download Jetstress 2013 
		xDownloadFile DownloadJetstress
		{
			SourcePath = "https://download.microsoft.com/download/C/2/4/C2484C53-5251-4278-A7C2-95739BFDD7CE/Jetstress.msi"
			FileName = "Jetstress.msi"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xInstaller]InstallAzCopy"
		}
		# Install Jetstress
		xInstaller InstallJetstress
		{
			Path = "$downloadPath\Jetstress.msi"
			Arguments = "/quiet /passive /qn"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Download and Extract Exchange 2016 Cumulative Update 1 to get required binaries for Jetstress
		#xDownloadISO DownloadExchangeCU1 
		#{
		#	SourcePath = "https://download.microsoft.com/download/6/4/8/648EB83C-00F9-49B2-806D-E46033DA4AE6/ExchangeServer2016-CU1.iso"
        #    DestinationDirectoryPath = $exchangeBinariesPath
        #    DependsOn = '[xInstaller]InstallJetstress'
		#}
		# Prepare Jetstress
		xJetstressSetup SetupJetstress
		{
			ExchangeInstallerLocation = $exchangeBinariesPath
			DependsOn = "[xInstaller]InstallJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		xJetstressTest RunJetstress
		{
			DatabasePath = "F:\Database"
			LogPath = "F:\Logs"
			OutputPath = "$env:SystemDrive\JetstressOutput"
			ExecutionTime = $ExecutionTime
			AutoSeek = $AutoSeek
			ThreadCount = $ThreadCount
			TestType = $TestType
			StorageCapacityPercentage = $StorageCapacityPercentage
			IopsCapacityPercentage = $IopsCapacityPercentage
			MailboxCount = $MailboxCount
			IopsPerMailbox= $IopsPerMailbox
			MailboxSizeinMB = $MailboxSizeinMB
			VMName = $VMName
			StorageAccount = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			DependsOn = "[xJetstressSetup]SetupJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		xJetstressUploadResult UploadJetstressResultInAzureStorageTable
		{
			ResultPath = "$env:SystemDrive\JetstressOutput"
			VMName = $VMName
			StorageAccount = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			DependsOn = "[xJetstressTest]RunJetstress"
		}
		# Upload Jetstress result to blob
		xAzureStorageCopyUpload UploadJetstressResultInAzureStorageBlob
		{
			SourcePath = "$env:SystemDrive\JetstressOutput"
			StorageAccountName = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			ContainerName = $VMName
			DependsOn = "[xJetstressUploadResult]UploadJetstressResultInAzureStorageTable"
			PsDscRunAsCredential = $VMAdminCreds
		}

		# Upload Jetstress summary to blob
		xAzureStorageCopyUpload UploadJetstressResultSummaryInAzureStorageBlob
		{
			SourcePath = "$env:SystemDrive\JetStressResults.html"
			StorageAccountName = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			ContainerName = $summaryContainer
			DependsOn = "[xAzureStorageCopyUpload]UploadJetstressResultInAzureStorageBlob"
			PsDscRunAsCredential = $VMAdminCreds
		}

		# Reboot node if needed
		LocalConfigurationManager 
        {
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $True
        }
	}
}