#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureJetstress
{
	param
    (
		[Parameter(Mandatory=$true)]
		[String]$ExecutionTime,
		
		[Parameter(Mandatory=$true)]
		[String]$AutoSeek,

		[Parameter(Mandatory=$true)]
		[String]$ThreadCount,

		[Parameter(Mandatory=$true)]
		[String]$TestType,
		
		[Parameter(Mandatory=$true)]
		[String]$StorageCapacityPercentage,
		
		[Parameter(Mandatory=$true)]
		[String]$IopsCapacityPercentage,
		
		[Parameter(Mandatory=$true)]
		[String]$MailboxCount,
		
		[Parameter(Mandatory=$true)]
		[String]$IopsPerMailbox,
		
		[Parameter(Mandatory=$true)]
		[String]$MailboxSizeinMB,
		
		[Parameter(Mandatory=$true)]
		[String]$Location,
		
		[Parameter(Mandatory=$true)]
		[String]$VMName,

		[Parameter(Mandatory=$true)]
		[PSCredential]$VMAdminCreds,

		[Parameter(Mandatory=$true)]
		[String]$StorageAccountName,

		[Parameter(Mandatory=$true)]
		[String]$StorageAccountKey,
		
		[Parameter(Mandatory=$true)]
		[String]$StorageEndpoint
		
	)

	# Local file storage location
	$localPath = "$env:SystemDrive"

	# Log file
	$logFileName = "JetstressWorkloadDSC.log"
	$logFilePath = "$localPath\$logFileName"
	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($VMAdminCreds.UserName)", $VMAdminCreds.Password)

	#Get-PackageProvider -Name nuget -ForceBootstrap -Force
	Import-DscResource -ModuleName 'PSDesiredStateConfiguration'
	Import-DscResource -ModuleName xDisk
	Import-DscResource -ModuleName xDownloadFile
	Import-DscResource -ModuleName xDownloadISO
	Import-DscResource -ModuleName xInstaller
	Import-DscResource -ModuleName xJetstress
	Import-DscResource -ModuleName xPendingReboot
	Import-DscResource -ModuleName xPSDesiredStateConfiguration
	Import-DscResource -ModuleName xAzureStorageCopy

	$StorageEndpoint = $StorageEndpoint.Substring($StorageEndpoint.LastIndexOf("blob") + "blob".Length + 1).replace("/", "").ToLower()
	if($StorageEndpoint.Contains(":")) {
		$StorageEndpoint = $StorageEndpoint.Substring(0, $StorageEndpoint.LastIndexOf(":"))
	}
	Write-Verbose "Azure storage endpoint $StorageEndpoint"
	
	######################
	### AZURE RM SETUP ###
	######################
	# AzureStack
	if($Location.Contains("local"))
	{
		# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
		add-type @"
		using System.Net;
		using System.Security.Cryptography.X509Certificates;
		public class TrustAllCertsPolicy : ICertificatePolicy {
			public bool CheckValidationResult(
				ServicePoint srvPoint, X509Certificate certificate,
				WebRequest request, int certificateProblem) {
				return true;
			}
		}
"@
		[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
		Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

		# Download AzureStack Powershell SDK - https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi 
		$azureStackPSMsi = "https://github.com/Azure/azure-powershell/releases/download/v1.2.0-February2016/azure-powershell.1.2.0.msi"
		$dest = Join-Path $env:SystemDrive "AzureStack"
		$path = Join-Path $dest "azure-powershell.1.2.0.msi"
		if(Test-Path $dest) {
			Write-Verbose "Skipped downloading file $azureStackPSMsi"
			"Skipped downloading file $azureStackPSMsi" | Out-File $logFilePath -Encoding ASCII -Append
		}
		else {
			try {
				Write-Verbose "Downloading file $azureStackPSMsi at destination $dest"
				"Downloading file $azureStackPSMsi at destination $dest" | Out-File $logFilePath -Encoding ASCII -Append
				New-Item $dest -ItemType Directory -Force -Confirm:0
				$wc = New-Object System.Net.WebClient
				$wc.DownloadFile($azureStackPSMsi, $path)
				Write-Verbose "Downloading file $azureStackPSMsi at destination $dest completed"
				"Downloading file $azureStackPSMsi at destination $dest completed" | Out-File $logFilePath -Encoding ASCII -Append
			} catch {
				Write-Warning "Exception in downloading Azure Stack Powershell SDK."
				"Exception in downloading Azure Stack Powershell SDK." | Out-File $logFilePath -Encoding ASCII -Append
			}
		}

		# Install AzureStack Powershell SDK
		$azureStackSdkPath = Join-Path ${env:ProgramFiles(x86)} "Microsoft SDKs\Azure"
		if((Test-Path $azureStackSdkPath) -eq $false) {
			$arguments = "/qn /passive /norestart /l* $dest\install.log" # "/quiet" # /qn /passive"
			$process = Start-Process -FilePath $path -ArgumentList $arguments -Wait -PassThru #-NoNewWindow
			# EXIT CODES: 3010/1641 - Application installed and requested a reboot
			if ($process.ExitCode -gt 0 -and $process.ExitCode -ne 3010 -and $process.ExitCode -ne 1641) {
				Write-Warning "Installer operation $path $arguments failed with exit code $($process.ExitCode)!"
				"Installer operation $path $arguments failed with exit code $($process.ExitCode)!" | Out-File $logFilePath -Encoding ASCII -Append
			} elseif ($process.ExitCode -eq -2145124329){
				Write-Warning "Installer operation is not applicable/needed."
				"Installer operation is not applicable/needed." | Out-File $logFilePath -Encoding ASCII -Append
			} else {
				Write-Verbose "Installer operation $path $arguments completed successfully."
				"Installer operation $path $arguments completed successfully." | Out-File $logFilePath -Encoding ASCII -Append
			}
		}
				
		# Import Azure Resource Manager PS module if already present
		try {
			Write-Host "Importing Azure module"
			"Importing Azure module" | Out-File $logFilePath -Encoding ASCII -Append
			Import-Module Azure -ErrorAction Stop | Out-Null
		} catch [Exception] {
			Write-Warning "Cannot import Azure module. Exception: $_"
			"Cannot import Azure module. Exception: $_" | Out-File $logFilePath -Encoding ASCII -Append
		}
	}
	# Azure Cloud
	else {
		# Import Azure Resource Manager PS module if already present
		try {
			Write-Host "Importing Azure module"
			"Importing Azure module" | Out-File $logFilePath -Encoding ASCII -Append
			Import-Module Azure -ErrorAction Stop | Out-Null
			Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
		} catch {
			# Suppress prompts
			$ConfirmPreference = 'None'
			Write-Warning "Cannot import Azure module, proceeding with installation"
			"Cannot import Azure module, proceeding with installation" | Out-File $logFilePath -Encoding ASCII -Append

			# Install AzureRM
			try {
				Get-PackageProvider -Name nuget -ForceBootstrap -Force
				Install-Module Azure –repository PSGallery –Force -Confirm:0
				Install-Module AzureRM.Compute –repository PSGallery –Force -Confirm:0
			} catch [Exception] {
				Write-Warning "Installation of Azure module failed."
				"Installation of Azure module failed." | Out-File $logFilePath -Encoding ASCII -Append
			}

			# Import AzureRM
			try {
				Import-Module Azure -ErrorAction Stop | Out-Null
				Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
				Import-Module AzureRM.Profile -ErrorAction Stop | Out-Null
			} catch [Exception] {
				Write-Warning "Cannot import Azure module."
				"Cannot import Azure module." | Out-File $logFilePath -Encoding ASCII -Append
			}
		}
	}

	# Downloaded file storage location
	$downloadPath = "$env:SystemDrive\DownloadsForDSC"
	$exchangeBinariesPath = "$env:SystemDrive\InstallerExchange"
	$diskNumber = 1
	if($Location.ToLower() -eq "local") {
		$diskNumber = 1
	} else {
		$diskNumber = 2
	}

	Node localhost
    {
		xWaitforDisk Disk3
        {
            DiskNumber = $diskNumber
            RetryIntervalSec = 60
            RetryCount = 60
        }
        xDisk FVolume
        {
			DiskNumber = $diskNumber
            DriveLetter = 'F'
			DependsOn = '[xWaitforDisk]Disk3'
        }
		# Download AzCopy
		xDownloadFile DownloadAzCopy
		{
			SourcePath = "http://aka.ms/downloadazcopy"
			FileName = "MicrosoftAzureStorageTools.msi"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xDisk]FVolume"
		}
		# Install AzCopy
		xInstaller InstallAzCopy
		{
			Path = "$downloadPath\MicrosoftAzureStorageTools.msi"
			Arguments = "/quiet /passive /qn"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadAzCopy"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Download Jetstress 2013 
		xDownloadFile DownloadJetstress
		{
			SourcePath = "https://download.microsoft.com/download/C/2/4/C2484C53-5251-4278-A7C2-95739BFDD7CE/Jetstress.msi"
			FileName = "Jetstress.msi"
			DestinationDirectoryPath = $downloadPath
			DependsOn = "[xInstaller]InstallAzCopy"
		}
		# Install Jetstress
		xInstaller InstallJetstress
		{
			Path = "$downloadPath\Jetstress.msi"
			Arguments = "/quiet /passive /qn"
			RegistryKey = "NA"
			DependsOn = "[xDownloadFile]DownloadJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Download and Extract Exchange 2016 Cumulative Update 1 to get required binaries for Jetstress
		#xDownloadISO DownloadExchangeCU1 
		#{
		#	SourcePath = "https://download.microsoft.com/download/6/4/8/648EB83C-00F9-49B2-806D-E46033DA4AE6/ExchangeServer2016-CU1.iso"
        #    DestinationDirectoryPath = $exchangeBinariesPath
        #    DependsOn = '[xInstaller]InstallJetstress'
		#}
		# Prepare Jetstress
		xJetstressSetup SetupJetstress
		{
			ExchangeInstallerLocation = $exchangeBinariesPath
			DependsOn = "[xInstaller]InstallJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		xJetstressTest RunJetstress
		{
			DatabasePath = "F:\Database"
			LogPath = "F:\Logs"
			OutputPath = "$env:SystemDrive\JetstressOutput"
			ExecutionTime = $ExecutionTime
			AutoSeek = $AutoSeek
			ThreadCount = $ThreadCount
			TestType = $TestType
			StorageCapacityPercentage = $StorageCapacityPercentage
			IopsCapacityPercentage = $IopsCapacityPercentage
			MailboxCount = $MailboxCount
			IopsPerMailbox= $IopsPerMailbox
			MailboxSizeinMB = $MailboxSizeinMB
			VMName = $VMName
			StorageAccount = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			DependsOn = "[xJetstressSetup]SetupJetstress"
			PsDscRunAsCredential = $VMAdminCreds
		}
		xJetstressUploadResult UploadJetstressResultInAzureStorageTable
		{
			ResultPath = "$env:SystemDrive\JetstressOutput"
			VMName = $VMName
			StorageAccount = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			DependsOn = "[xJetstressTest]RunJetstress"
		}
		# Upload Jetstress result to blob
		xAzureStorageCopyUpload UploadJetstressResultInAzureStorageBlob
		{
			SourcePath = "$env:SystemDrive\JetstressOutput"
			StorageAccountName = $StorageAccountName
			StorageAccountKey = $StorageAccountKey
			StorageEndpoint = $StorageEndpoint
			ContainerName = $VMName
			DependsOn = "[xJetstressUploadResult]UploadJetstressResultInAzureStorageTable"
			PsDscRunAsCredential = $VMAdminCreds
		}
		# Reboot node if needed
		LocalConfigurationManager 
        {
			ConfigurationMode = 'ApplyOnly'
            RebootNodeIfNeeded = $True
        }
	}
}