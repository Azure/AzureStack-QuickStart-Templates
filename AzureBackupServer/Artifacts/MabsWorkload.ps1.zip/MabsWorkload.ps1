﻿#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureMabs
{
	param
    (
		[Parameter(Mandatory=$true)]
		[String]$DomainName,

		[Parameter(Mandatory=$true)]
		[PSCredential]$AdminCreds,

		[Parameter(Mandatory=$true)]
		[uint32]$NoOfDisks,

		[Parameter(Mandatory=$true)]
		[String]$PassphraseSaveLocation,

		[Parameter(Mandatory=$true)]
		[String]$VaultCredentialFilePath,

		[Parameter(Mandatory=$true)]
		[PSCredential]$MABS_SecurityPassphrase		


	)

	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

	Import-DscResource -ModuleName xActiveDirectory;
	Import-DscResource -ModuleName xDisk;
	Import-DscResource -ModuleName xPendingReboot;
	Import-DscResource -ModuleName xPSDesiredStateConfiguration;
	Import-DscResource -ModuleName xDSCDomainjoin;
	Import-DscResource -ModuleName xMirroredVolume;
	Import-DscResource -ModuleName MABS_Installer_DSCModule;
	Import-DscResource -ModuleName xExeInstaller;

	$sqlsetupexe = 'c:\MABS\SQLSVR2017\setup.exe'
	$sqlsetupargs = "/Q","/ACTION=install","/IACCEPTSQLSERVERLICENSETERMS","/FEATURES=SQL","/INSTANCENAME=MABSV3DB",'/SQLSVCACCOUNT="{0}"','/SQLSVCPASSWORD="{1}"','/SQLSYSADMINACCOUNTS="{2}" "BUILTIN\Administrators"','/AGTSVCACCOUNT="NT AUTHORITY\Network Service"' -f $DomainCreds.UserName, $DomainCreds.GetNetworkCredential().Password ,$DomainCreds.UserName
	$ssmsexe = 'c:\mabs\SQLSVR2017\SSMS-Setup-ENU.exe'
	$ssmsargs = '/install', '/quiet', '/norestart'
	$reportingexe = 'c:\mabs\SQLSVR2017\SQLServerReportingServices.exe'
	$reportingargs = '/quiet', '/norestart', '/IAcceptLicenseTerms', '/Edition=Dev'


	Node localhost
    {

		xWaitForDisk WaitDisk
		{
			DiskNumber=($NoOfDisks+1)
			RetryIntervalSec=20
			RetryCount=20
		}

		MultiDiskInitialize DisksStart
		{
			PoolSize = "50"
			NoDisks	 = $NoOfDisks
			DependsOn = "[xWaitForDisk]WaitDisk"
		}

		xPendingReboot AfterWaitDisk
        {
			Name = 'AfterWaitDisk'
			SkipCcmClientSDK=$True
			DependsOn = "[MultiDiskInitialize]DisksStart"
		}

		WindowsFeature NET-Framework-Core 
		{
			Name = "NET-Framework-Core"
            Ensure = "Present"
			DependsOn = "[xPendingReboot]AfterWaitDisk"
		}
		
		xDSCDomainjoin JoinDomain
        {
         Domain = $DomainName
         Credential = $DomainCreds
		 DependsOn='[WindowsFeature]NET-Framework-Core'
		}

		xPendingReboot AfterDomainJoin
        {
			Name = 'AfterDomainJoin'
			SkipCcmClientSDK=$True
			DependsOn = "[xDSCDomainjoin]JoinDomain"
		}

		ExeInstaller InstallSql
		{
			Path = $sqlsetupexe
			ArgumentList = $sqlsetupargs
			PsDscRunAsCredential = $DomainCreds
			DependsOn = "[xPendingReboot]AfterDomainJoin"
		}

		xPendingReboot AfterInstallSql
        {
			Name = 'AfterInstallSql'
			SkipCcmClientSDK=$True
			DependsOn = "[ExeInstaller]InstallSql"
		}

		ExeInstaller ReportingInstall
		{
			Path = $reportingexe
			ArgumentList = $reportingargs
			PsDscRunAsCredential = $DomainCreds
			DependsOn = "[xPendingReboot]AfterInstallSql"
		}

		xPendingReboot AfterReportingInstall
        {
			Name = 'AfterReportingInstall'
			SkipCcmClientSDK=$True
			DependsOn = "[ExeInstaller]ReportingInstall"
		}

		ExeInstaller SSMSInstall
		{
			Path = $ssmsexe
			ArgumentList = $ssmsargs
			PsDscRunAsCredential = $DomainCreds
			DependsOn = "[xPendingReboot]AfterReportingInstall"
		}

		xPendingReboot AfterSSMSInstall
        {
			Name = 'AfterSSMSInstall'
			SkipCcmClientSDK=$True
			DependsOn = "[ExeInstaller]SSMSInstall"
		}

		MABS_Installer InstallMabs
		{
			Domain = $DomainName
			VaultCredentialFilePath = $VaultCredentialFilePath
			MABS_SecurityPassphrase = $MABS_SecurityPassphrase
			PassphraseSaveLocation = $PassphraseSaveLocation
			DomainCredential = $DomainCreds
			PsDscRunAsCredential = $DomainCreds
			DependsOn = "[xPendingReboot]AfterSSMSInstall"
		}

		xPendingReboot AfterMABSInstall
        {
			Name = 'AfterMABSInstall'
			SkipCcmClientSDK=$True
			DependsOn = "[MABS_Installer]InstallMabs"
		}

		MABS_DiskAdd MapDPMStorage
		{
			Domain = $DomainName 
            PsDscRunAsCredential = $DomainCreds
            DependsOn            = "[xPendingReboot]AfterMABSInstall"
			
		}
		
		LocalConfigurationManager 
        {
			RebootNodeIfNeeded = $True
            ConfigurationID = ([guid]::NewGuid()).Guid
        }
	}
}
