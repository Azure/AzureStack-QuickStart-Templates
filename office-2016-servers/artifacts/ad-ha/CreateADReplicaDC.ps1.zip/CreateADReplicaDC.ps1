﻿configuration CreateADReplicaDC 
{ 
   param 
    ( 
        [Parameter(Mandatory)]
        [String]$DomainName,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,
		
	    [Parameter(Mandatory)]
        [String]$primaryIpAddress,
		
		[Parameter(Mandatory)]
        [String]$DnsForwarder,
		
		[Parameter(Mandatory)]
        [String]$NtpServer,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    ) 
    
    Import-DscResource -ModuleName xActiveDirectory,xDNS,xDisk,cDisk,xNetworking, Move_FSMO 
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
	$dcName = $env:computername
	$Interface=Get-NetAdapter|Where Name -Like "Ethernet*"|Select-Object -First 1
    $InteraceAlias=$($Interface.Name)
   
    Node localhost
    {
		LocalConfigurationManager 
        {
		    RebootNodeIfNeeded = $True
            ConfigurationID = ([guid]::NewGuid()).Guid
        }

        WindowsFeature DNS 
        { 
            Ensure = "Present" 
            Name = "DNS"
        }
        xDnsServerAddress DnsServerAddress 
        { 
            Address        = $primaryIpAddress,'127.0.0.1'
            InterfaceAlias = $InteraceAlias
            AddressFamily  = 'IPv4'
            DependsOn = "[WindowsFeature]DNS"
        }

        xWaitforDisk Disk2
        {
             DiskNumber = 2
             RetryIntervalSec =$RetryIntervalSec
             RetryCount = $RetryCount
			 DependsOn = '[xDnsServerAddress]DnsServerAddress'
        }
        cDiskNoRestart ADDataDisk
        {
            DiskNumber = 2
            DriveLetter = "F"
			DependsOn = '[xWaitforDisk]Disk2'
        }  
			
        WindowsFeature ADDSInstall 
        { 
            Ensure = "Present" 
            Name = "AD-Domain-Services"
            DependsOn="[cDiskNoRestart]ADDataDisk"
        }
        
        WindowsFeature ADDSToolsInstall
        {
            Ensure = "Present"
            Name = "RSAT-ADDS-Tools"
            DependsOn = '[WindowsFeature]ADDSInstall'
        }
        		
        xWaitForADDomain DscForestWait 
        { 
            DomainName = $DomainName 
            DomainUserCredential= $DomainCreds
            RetryCount = $RetryCount 
            RetryIntervalSec = $RetryIntervalSec
	        DependsOn = "[WindowsFeature]ADDSToolsInstall"
        }

        xADDomainController Replica 
        { 
            DomainName = $DomainName
            DomainAdministratorCredential = $DomainCreds
            SafemodeAdministratorPassword = $DomainCreds
            DatabasePath = "F:\NTDS"
            LogPath = "F:\NTDS"
            SysvolPath = "F:\SYSVOL"
            DependsOn = "[xWaitForADDomain]DscForestWait"
        }

		xMoveFSMO moveRoles
		{
		    FSMORoles = "PDCEmulator,RIDMaster"
			TargetDCName = $dcName
            DomainName = $DomainName
            PsDscRunAsCredential = $DomainCreds
			DependsOn = "[xADDomainController]Replica"
		}
   }
} 
