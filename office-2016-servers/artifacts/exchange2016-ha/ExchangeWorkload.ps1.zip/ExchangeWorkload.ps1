﻿#
# Copyright="© Microsoft Corporation. All rights reserved."
#

configuration InstallAndConfigureExchange
{
	param
    (
		[Parameter(Mandatory=$true)]
		[String]$DomainName,

		[Parameter(Mandatory=$true)]
		[String]$StorageSize,

		[Parameter(Mandatory=$true)]
		[PSCredential]$VMAdminCreds,

		[Parameter(Mandatory=$true)]
		[String]$Location,

		[Parameter(Mandatory=$true)]
		[String]$WitnessName,

		[Parameter(Mandatory=$true)]
		[String]$DagName,

		[Parameter(Mandatory=$true)]
		[String]$InstallerFolder,

		[Parameter(Mandatory=$true)]
		[uint32]$NoOfDisks,

		[Parameter(Mandatory=$true)]
		[String]$License,

		[Parameter(Mandatory=$true)]
		[String]$primaryAD
	)

	$DomainCreds = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($VMAdminCreds.UserName)", $VMAdminCreds.Password)

	Import-DscResource -ModuleName xActiveDirectory;
	Import-DscResource -ModuleName xDisk;
	Import-DscResource -ModuleName xDownloadFile;
	Import-DscResource -ModuleName xDownloadISO;
    Import-DscResource -ModuleName xExchange;
	Import-DscResource -ModuleName xExchangeValidate;
	Import-DscResource -ModuleName xExtract;
	Import-DscResource -ModuleName xInstaller;
	Import-DscResource -ModuleName xPendingReboot;
	Import-DscResource -ModuleName xPSDesiredStateConfiguration;
	Import-DscResource -ModuleName xPSWindowsUpdate;
	Import-DscResource -ModuleName xDSCDomainjoin;
	Import-DscResource -ModuleName xExchangeDag;
	Import-DscResource -ModuleName xMirroredVolume;
	Import-DscResource -ModuleName xExchangeUrls;
	Import-DscResource -ModuleName xExchangeLic;


	# Downloaded file storage location
	$downloadPath = "$env:SystemDrive\DownloadsForDSC";
	$exchangeInstallerPath = "$env:SystemDrive\InstallerExchange";
	$diskNumber = 2;
	$mirrordiskNumber = 3;
	$UCMAUrl = "$InstallerFolder"+"UcmaRuntimeSetup.exe";
	$KBUrl = "$InstallerFolder"+"windows10.0-kb3206632-x64_b2e20b7e1aa65288007de21e88cd21c3ffb05110.msu";


	Node localhost
    {

		xWaitForDisk WaitDisk
		{
			DiskNumber=($NoOfDisks+1)
			RetryIntervalSec=20
			RetryCount=20
		}

        MultiDiskInitialize Volume
        {
			PoolSize = $StorageSize
			NoDisks = $NoOfDisks
			DependsOn = "[xWaitForDisk]WaitDisk"
		}

		xPendingReboot AfterDiskMap
        {
			Name = 'AfterDiskMap'
			SkipCcmClientSDK=$True
			DependsOn = "[MultiDiskInitialize]Volume"
		}
		
		#workaround for Exchange installation
		Script DisableFirewall 
        {
            GetScript = {
               @{
                  GetScript = $GetScript
                  SetScript = $SetScript
                  TestScript = $TestScript
                  Result = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
                }
            }

             SetScript = {
                  Set-NetFirewallProfile -All -Enabled False -Verbose
            }

             TestScript = {
                  $Status = -not('True' -in (Get-NetFirewallProfile -All).Enabled)
                  $Status -eq $True
			}
			DependsOn = "[xPendingReboot]AfterDiskMap"
        }
		# Install Exchange 2016 Pre-requisits | Reference: https://technet.microsoft.com/en-us/library/bb691354(v=exchg.160).aspx
		# Active Directory
		WindowsFeature RSATADDS {
			Name = "RSAT-ADDS"
            Ensure = "Present"
			DependsOn = "[Script]DisableFirewall"
		}
		WindowsFeature RPCOverHTTPProxy {
			Name = "RPC-over-HTTP-proxy"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]RSATADDS"
		}
		WindowsFeature RSATClustering {
			Name = "RSAT-Clustering"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]RPCOverHTTPProxy"
		}
		WindowsFeature RSATClusteringCmd {
			Name = "RSAT-Clustering-CmdInterface"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]RSATClustering"
		}
		WindowsFeature RSATClusteringMgmt {
			Name = "RSAT-Clustering-Mgmt"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]RSATClusteringCmd"
		}
		WindowsFeature RSATClusteringPS {
			Name = "RSAT-Clustering-PowerShell"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]RSATClusteringMgmt"
		}
		WindowsFeature WASProcessModel {
			Name = "WAS-Process-Model"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]RSATClusteringPS"
		}
		WindowsFeature WebAspNet45 {
			Name = "Web-Asp-Net45"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WASProcessModel"
		}
		WindowsFeature WebBasicAuth {
			Name = "Web-Basic-Auth"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebAspNet45"
		}
		WindowsFeature WebClientAuth {
			Name = "Web-Client-Auth"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebBasicAuth"
		}
		WindowsFeature WebDigestAuth {
			Name = "Web-Digest-Auth"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebClientAuth"
		}
		WindowsFeature WebDirBrowsing {
			Name = "Web-Dir-Browsing"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebDigestAuth"
		}
		WindowsFeature WebDynCompression {
			Name = "Web-Dyn-Compression"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebDirBrowsing"
		}
		WindowsFeature WebHttpErrors {
			Name = "Web-Http-Errors"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebDynCompression"
		}
		WindowsFeature WebHttpLogging {
			Name = "Web-Http-Logging"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebHttpErrors"
		}
		WindowsFeature WebHttpRedirect {
			Name = "Web-Http-Redirect"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebHttpLogging"
		}
		WindowsFeature WebHttpTracing {
			Name = "Web-Http-Tracing"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebHttpRedirect"
		}
		WindowsFeature WebISAPIExt {
			Name = "Web-ISAPI-Ext"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebHttpTracing"
		}
		WindowsFeature WebISAPIFilter {
			Name = "Web-ISAPI-Filter"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebISAPIExt"
		}
		WindowsFeature WebLgcyMgmtConsole {
			Name = "Web-Lgcy-Mgmt-Console"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebISAPIFilter"
		}
		WindowsFeature WebMetabase {
			Name = "Web-Metabase"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebLgcyMgmtConsole"
		}
		WindowsFeature WebMgmtConsole {
			Name = "Web-Mgmt-Console"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebMetabase"
		}
		WindowsFeature WebMgmtService {
			Name = "Web-Mgmt-Service"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebMgmtConsole"
		}
		WindowsFeature WebNetExt45 {
			Name = "Web-Net-Ext45"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebMgmtService"
		}
		#dependency not mentioned in https://technet.microsoft.com/en-us//library/bb691354(v=exchg.160).aspx#WS2016Edge
		WindowsFeature WcfHttpActivation {
			Name="NET-WCF-HTTP-Activation45"
			Ensure="Present"
			DependsOn="[WindowsFeature]WebNetExt45"
		}
		WindowsFeature WebRequestMonitor {
			Name = "Web-Request-Monitor"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WcfHttpActivation"
		}
		WindowsFeature WebServer {
			Name = "Web-Server"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebRequestMonitor"
		}
		WindowsFeature WebStatCompression {
			Name = "Web-Stat-Compression"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebServer"
		}
		WindowsFeature WebStaticContent {
			Name = "Web-Static-Content"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebStatCompression"
		}
		WindowsFeature WebWindowsAuth {
			Name = "Web-Windows-Auth"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebStaticContent"
		}
		WindowsFeature WebWMI {
			Name = "Web-WMI"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebWindowsAuth"
		}
		WindowsFeature WindowsIdentityFoundation {
			Name = "Windows-Identity-Foundation"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WebWMI"
		}
		# Edge Transport Server Role
		WindowsFeature ADLDS {
			Name = "ADLDS"
            Ensure = "Present"
			DependsOn = "[WindowsFeature]WindowsIdentityFoundation"
		}
		
		xDSCDomainjoin JoinDomain
        {
         Domain = $DomainName
         Credential = $DomainCreds
		 DependsOn='[WindowsFeature]ADLDS'
		}

		xPendingReboot AfterDomainJoin
        {
			Name = 'AfterDomainJoin'
			SkipCcmClientSDK=$True
			DependsOn = "[xDSCDomainjoin]JoinDomain"
		}
		
        xExchInstall InstallExchange
        {
            Path = "$exchangeInstallerPath\setup.exe"
            Arguments = "/Mode:Install /Role:Mailbox /OrganizationName:ExchOrg /TargetDir:H:\Exchange /MdbName:Edb01 /IAcceptExchangeServerLicenseTerms"
            Credential = $DomainCreds
            DependsOn = '[xPendingReboot]AfterDomainJoin'
			PsDscRunAsCredential = $DomainCreds
		}

		xPendingReboot AfterExInstall
        {
			Name = 'AfterExInstall'
			SkipCcmClientSDK=$True
			DependsOn = "[xExchInstall]InstallExchange"
		}

		ExchangeLic AddLicense
		{
			LicKey = $License
			Credential = $DomainCreds
			DependsOn = '[xPendingReboot]AfterExInstall'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db2 	
		{
			Credential = $DomainCreds
			Name= "Edb02"
            EdbFilePath = "I:\ExDb\Edb02.edb"
            LogFolderPath = "I:\ExDb\Edb02.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
			IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[ExchangeLic]AddLicense'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db3 	
		{
			Credential = $DomainCreds
			Name= "Edb03"
            EdbFilePath = "L:\ExDb\Edb03.edb"
            LogFolderPath = "L:\ExDb\Edb03.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
            IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db2'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db4 	
		{
			Credential = $DomainCreds
			Name= "Edb04"
            EdbFilePath = "M:\ExDb\Edb04.edb"
            LogFolderPath = "M:\ExDb\Edb04.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
            IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db3'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db5 	
		{
			Credential = $DomainCreds
			Name= "Edb05"
            EdbFilePath = "N:\ExDb\Edb05.edb"
            LogFolderPath = "N:\ExDb\Edb05.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
            IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db4'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db6 	
		{
			Credential = $DomainCreds
			Name= "Edb06"
            EdbFilePath = "O:\ExDb\Edb06.edb"
            LogFolderPath = "O:\ExDb\Edb06.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
            IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db5'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db7 	
		{
			Credential = $DomainCreds
			Name= "Edb07"
            EdbFilePath = "P:\ExDb\Edb07.edb"
            LogFolderPath = "P:\ExDb\Edb07.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
			IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db6'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db8 	
		{
			Credential = $DomainCreds
			Name= "Edb08"
            EdbFilePath = "Q:\ExDb\Edb08.edb"
            LogFolderPath = "Q:\ExDb\Edb08.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
            IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db7'
			PsDscRunAsCredential = $DomainCreds
		}

		xExchMailboxDatabase db9 	
		{
			Credential = $DomainCreds
			Name= "Edb09"
            EdbFilePath = "R:\ExDb\Edb09.edb"
            LogFolderPath = "R:\ExDb\Edb09.log"
			Server = $env:ComputerName
            CircularLoggingEnabled = $true
            DatabaseCopyCount = 1
            IssueWarningQuota        = '10176MB'
			ProhibitSendQuota        = '11200MB'
			ProhibitSendReceiveQuota = '12224MB'
			AllowServiceRestart = $true
			AdServerSettingsPreferredServer=$primaryAD
			DependsOn = '[xExchMailboxDatabase]db8'
			PsDscRunAsCredential = $DomainCreds
		}

		DagFwCreation CreateWitness
		{
			DomainName = $DomainName
			DagName = $DagName
			WitnessName = $WitnessName
			Credential = $DomainCreds
			MailboxServer = $env:ComputerName
			DependsOn = '[xExchMailboxDatabase]db9'
			PsDscRunAsCredential = $DomainCreds
		}

		DagCreation CreateDag
		{
			DomainName = $DomainName
			DagName = $DagName
			WitnessName = $WitnessName
			Credential = $DomainCreds
			MailboxServer = $env:ComputerName
			DependsOn = '[DagFwCreation]CreateWitness'
			PsDscRunAsCredential = $DomainCreds
		}

		DagConfiguration ConfigureDag
		{
			DomainName = $DomainName
			DagName = $DagName
			WitnessName = $WitnessName
			Credential = $DomainCreds
			MailboxServer = $env:ComputerName
			DependsOn = '[DagCreation]CreateDag'
			PsDscRunAsCredential = $DomainCreds
		}

		ExchangeUrls ConfigureUrl
		{
			BaseUrl = "mail"
			DomainName = $DomainName
			Credential = $DomainCreds
			DependsOn = '[DagConfiguration]ConfigureDag'
			PsDscRunAsCredential = $DomainCreds
		}

		Script EnableFirewall 
        {
            GetScript = {
               @{
                  GetScript = $GetScript
                  SetScript = $SetScript
                  TestScript = $TestScript
                  Result = -not('False' -in (Get-NetFirewallProfile -All).Enabled)
                }
            }

             SetScript = {
                  Set-NetFirewallProfile -All -Enabled True -Verbose
            }

             TestScript = {
                  $Status = -not('False' -in (Get-NetFirewallProfile -All).Enabled)
                  $Status -eq $True
			}
			DependsOn = '[ExchangeUrls]ConfigureUrl'
        }

		LocalConfigurationManager 
        {
			RebootNodeIfNeeded = $True
            ConfigurationID = ([guid]::NewGuid()).Guid
        }
	}
}
