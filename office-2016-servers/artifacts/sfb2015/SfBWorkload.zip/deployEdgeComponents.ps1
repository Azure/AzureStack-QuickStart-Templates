Param
(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$cmuURL
)


Configuration Deploy_SkypeForBusinessFrontEndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$cmuURL
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $DownloadsDir = "{0}\OfflineInstallers" -f $env:SystemDrive

    $SkypeForBusinessSetupFilesLocation = $env:SystemDrive + "\SkypeForBusinessISOContents"
    $SkypeForBusinessDeploymentPath = ("{0}\Setup\amd64" -f $SkypeForBusinessSetupFilesLocation)

    $cmuFileName = $cmuURL.Split('/')[-1]
    $cmuFilePath = Join-Path $DownloadsDir $cmuFileName

    $sfbConfigLocation = "{0}\SfbConfig.zip" -f $env:SystemDrive

    Node localhost {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        xCsConfigurationImport ImportToLocalstore
        {
            Name = 'ImportToLocalstore'
            LocalStore = $true
            Credential = $AdminCreds
            AuthenticationType = "Basic"
            FileName = $sfbConfigLocation
        }

        xCsReplica AssertReplicaEnabled
        {
            Name = "ReplicaEnabled"
            Credential = $AdminCreds
            AuthenticationType = "Basic"
            DependsOn = '[xCsConfigurationImport]ImportToLocalstore'
        }

        xCsWindowsService Replica
        {
            Name = 'Replica'
            Status = 'Running'
            Credential = $AdminCreds
            AuthenticationType = "Basic"
            DependsOn = '[xCsReplica]AssertReplicaEnabled'
        }
        
        xCsBootStrapper InstallRolesInTopology
        {
            Name = 'InstallRolesInTopology'
            Credential = $AdminCreds
            AuthenticationType = "Basic"
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[xCsWindowsService]Replica'
        }

        # xCsCertificate EdgeCertificates
        # {
        #     New = $true
        #     Type = "Internal","AccessEdgeExternal","DataEdgeExternal","AudioVideoAuthentication"
        #     ComputerFqdn = $env:COMPUTERNAME
        #     CA = $CA
        #     FriendlyName = 'Edge server certificate'
        #     PrivateKeyExportable = $true
        #     DomainName = ("{0},{2}.{1},{3}" -f @(
        #         "edge", $DomainName, "sipexternal",
        #         ($EdgeServers -Join ",")))
        #     Credential = $AdminCreds
        #     DomainCredential = $DomainCred
        #     UseLocalCredentials = $false
        #     AuthenticationType = "Basic"
        #     Ensure = 'Present'
        #     DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
        #     # DependsOn = '[Script]SkypeForBusinessCMUPostInstall'
        # }

        #"Internal","AccessEdgeExternal","DataEdgeExternal","AudioVideoAuthentication"

        # xDownloadFile DownloadCMU
        # {
        #     URL = "$cmuURL"
        #     Checksum = $sfbCMUSHA256
        #     DownloadPath = ("{0}\{1}" -f @($env:SystemDrive, $cmuURL.Split('/')[-1]))
        #     Ensure = 'Present'
        #     DependsOn = "[xCsBootStrapper]InstallRolesInTopology"
        # }
        
        # AzCopyDownload DownloadCMU
        # {
        #     Uri = $cmuURL
        #     FileName = $cmuFileName
        #     PsDscRunAsCredential = $Admincreds
        # }
        # Script SkypeForBusinessCMUPostInstall
        # {
        #     SetScript = {
        #         & $using:cmuFilePath /silentmode
        #     }
        #     GetScript = {
        #         @{
        #             Result = $null
        #         }
        #     }
        #     TestScript = { return $false }
        #     DependsOn = '[AzCopyDownload]DownloadCMU'
        # }
    }
}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="localhost"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

$Parameters = @{
    ConfigurationData = $ConfigData
    OutPutPath = "C:\DSC"
    AdminCreds = $AdminCreds
    cmuURL = $cmuURL
}

$env:PSModulePath += ";C:\Program Files\Common Files\Skype for Business Server 2015\Modules" 

Deploy_SkypeForBusinessFrontEndComponents @Parameters

Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force
