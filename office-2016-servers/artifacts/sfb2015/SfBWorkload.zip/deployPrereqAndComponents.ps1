Configuration Deploy_SkypeForBusinessPrereqAndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$isoURL,
        [Parameter(Mandatory=$true)]
        [string]$sfbISOSHA256,
        [Parameter(Mandatory=$true)]
        [string]$cmuURL,
        [Parameter(Mandatory=$true)]
        [string]$sfbCMUSHA256,
        [Parameter(Mandatory=$true)]
        [string]$CA,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteURL,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteSHA256
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $features = @(
        "NET-Framework-Core","Web-Server", "Windows-Identity-Foundation",
        "Web-Static-Content","Web-Default-Doc","Web-Http-Errors","Web-Dir-Browsing",
        "Web-Asp-Net","Web-Net-Ext","Web-ISAPI-Ext","Web-ISAPI-Filter","Web-Http-Logging",
        "Web-Log-Libraries","Web-Request-Monitor","Web-Http-Tracing","Web-Basic-Auth",
        "Web-Windows-Auth","Web-Client-Auth","Web-Filtering","Web-Stat-Compression",
        "Web-Dyn-Compression","NET-WCF-HTTP-Activation45","Web-Asp-Net45","Web-Mgmt-Tools",
        "Web-Scripting-Tools","Web-Mgmt-Compat","Server-Media-Foundation","BITS"
    )
    $SkypeForBusinessSetupFilesLocation = $env:SystemDrive + "\SkypeForBusinessISOContents"
    $isoPath = ("{0}\{1}" -f @($env:SystemDrive, $isoURL.Split('/')[-1]))
    $SkypeForBusinessDeploymentPath = ("{0}\Setup\amd64" -f $SkypeForBusinessSetupFilesLocation)
    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    $modRewritePath = ("{0}\{1}" -f @($env:SystemDrive, $modRewriteURL.Split('/')[-1]))
    $PoolFqdn = ("pool.{0}" -f $DomainName)

    Node localhost {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature RsatAdds
        {
            Name = 'RSAT-ADDS'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }
        
        WindowsFeature RsatDNS
        {
            Name = 'RSAT-DNS-Server'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        #Install required Windows features
        Foreach($feature in $features)
        {         
            WindowsFeature $feature
            {
                Ensure = 'Present'
                Name = $feature
            }
        }

        xWaitForADDomain DscForestWait
        { 
            DomainName = $DomainName 
            DomainUserCredential = $domainCred 
            RetryCount = 20 
            RetryIntervalSec = 5
        } 

        xComputer JoinDomain
        {
            Name = $env:COMPUTERNAME
            Credential = $DomainCred
            DomainName = $DomainName
            DependsOn = '[xWaitForADDomain]DscForestWait'            
        }

        xPendingReboot RebootAfterDomainJoin
        {
            Name = 'RebootAfterDomainJoin'
            DependsOn = '[xComputer]JoinDomain'
            PsDscRunAsCredential = $DomainCred
        }

        xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Administrators" 
        }       

        xDownloadFile DownloadISO
        {
            URL = "$isoURL"
            Checksum = $sfbISOSHA256
            DownloadPath = $isoPath
            Ensure = 'Present'
        }

        xDownloadFile DownloadCMU
        {
            URL = "$cmuURL"
            Checksum = $sfbCMUSHA256
            DownloadPath = ("{0}\{1}" -f @($env:SystemDrive, $cmuURL.Split('/')[-1]))
            Ensure = 'Present'
        }

        Script MountISOAndCopyFiles
        {
            DependsOn = "[xDownloadFile]DownloadISO"
            SetScript =
            {
                $mnt = Mount-DiskImage $using:isoPath -PassThru
                if(!(Test-Path $using:SkypeForBusinessSetupFilesLocation)){
                    mkdir $using:SkypeForBusinessSetupFilesLocation
                }
                $driveLetter = ($mnt | Get-Volume).DriveLetter
                New-PSDrive -Name $driveLetter -PSProvider FileSystem -Root "$($driveLetter):\"

                Write-Verbose ("{0}:\*" -f $driveLetter)
                Copy-Item -Recurse ("{0}:\*" -f ($mnt | Get-Volume).DriveLetter) $using:SkypeForBusinessSetupFilesLocation
            }
            TestScript = {
                Test-Path $using:SkypeForBusinessSetupFilesLocation
            }
            GetScript = { 
                $img = (Get-DiskImage $using:isoPath)
                $vol = $img | Get-Volume
                @{
                    Result = $vol.DriveLetter
                }
            }
        }
        Package VisualC
        {
            Name = 'Visual C++ Minimum Runtime package'
            Path = ("{0}\VCREDIST_X64.EXE" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/INSTALL /PASSIVE /NORESTART'
            ProductId = 'A749D8E6-B613-3BE3-8F5F-045C84EBA29B'
            DependsOn = "[Script]MountISOAndCopyFiles"
        }

        xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server" 
            DependsOn = '[Package]VisualC'           
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = ("{0}.{1}" -f ($env:COMPUTERNAME, $DomainName))
            DependsOn = '[xCredSSP]Server'
        }

        xWaitForCredSSP WaitForCredSSP {
            DependsOn = "[xCredSSP]Client"
            DomainName = $DomainName
            Credential = $DomainCred
        }

        Package SkypeForBusinessCoreComponents
        {
            Name = 'Skype for Business Server 2015, Core Components'
            Path =  ("{0}\SETUP\ocscore.msi" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/PASSIVE /NORESTART'
            ProductId = 'DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F'
            DependsOn = '[xWaitForCredSSP]WaitForCredSSP'
        }

        xCsBootStrapper BootstrapAdminTools
        {
            Name = 'BootstrapAdminTools'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[Package]SkypeForBusinessCoreComponents'
        }

        Script SkypeForBusinessCMU
        {
            SetScript = {
                $url = $using:cmuURL
                $cmuPath = ("{0}\{1}" -f @($env:SystemDrive, $url.split('/')[-1]))
                & $cmuPath /silentmode
            }
            GetScript = {
                @{
                    Result = $null
                }
            }
            TestScript = { return $false }
            DependsOn = '[xCsBootStrapper]BootstrapAdminTools'
        }

        Script Reboot
        {
            TestScript = {
                $stateExists = (Test-Path HKLM:\SOFTWARE\sfbState)
                if (!$stateExists) {
                    New-Item -Path HKLM:\SOFTWARE -Name sfbState -Force
                    return $false
                }
                $shouldReboot = Get-ItemProperty -Path HKLM:\SOFTWARE\sfbState -Name "ShouldReboot" -ErrorAction SilentlyContinue
                if (!$shouldReboot -or $shouldReboot -eq "1") {
                    return $false
                }
                return $true
            }
            SetScript = {
                Set-ItemProperty -Path HKLM:\SOFTWARE\sfbState -Name "ShouldReboot" -Value "0"
                $global:DSCMachineStatus = 1 
            }
            GetScript = { return @{result = 'result'}}
            DependsOn = '[Script]SkypeForBusinessCMU'
        }

        xCsReplica AssertReplicaEnabled
        {
            Name = "ReplicaEnabled"
            Credential = $DomainCred
            DependsOn = '[Script]Reboot'
        }

        xCsWindowsService Replica
        {
            Name = 'Replica'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsReplica]AssertReplicaEnabled'
        }   

        xCsConfigurationImport ImportToLocalstore
        {
            Name = 'ImportToLocalstore'
            LocalStore = $True
            Credential = $DomainCred
            DependsOn = "[xCsWindowsService]Replica"
            # DependsOn = '[xSetCsManagementConnection]SetmanagementConnection2'
        }

        xDownloadFile DownloadModRewrite
        {
            URL = $modRewriteURL
            Checksum = $modRewriteSHA256
            DownloadPath = $modRewritePath
            Ensure = 'Present'
            DependsOn = '[xCsConfigurationImport]ImportToLocalstore'

        }

        Package ModRewriteModule
        {
            # An updated package of Rewrite mod needs to be installed
            # on windows server 2016 before bootstrapping the components
            Name = 'Mod rewrite 2.1 install'
            Path =  $modRewritePath
            Arguments = '/PASSIVE /NORESTART'
            ProductId = '38D32370-3A31-40E9-91D0-D236F47E3C4A'
            DependsOn = '[xDownloadFile]DownloadModRewrite'
        }

        xCsBootStrapper InstallRolesInTopology
        {
            Name = 'InstallRolesInTopology'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[Package]ModRewriteModule'
        }

        xCsCertificate DefaultInternalExternal
        {
            New = $true
            Type = 'Default','WebServicesInternal','WebServicesExternal'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'Enterprise Edition Certificate'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1}" -f @("pool", $DomainName, "webint"))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
        }

        xCsCertificate OAuthCert
        {
            New = $true
            Type = 'OAuthTokenIssuer'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'OAuth Cert'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1}" -f @("pool", $DomainName, "webint"))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsCertificate]DefaultInternalExternal'

        }

        xCsWindowsService StartAll
        {
            Name = 'All'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsCertificate]OAuthCert'
        }

        xCsUser EnableAdmin
        {
            Identity = ("{0}\{1}" -f @($DomainName, $AdminCreds.UserName))
            RegistrarPool = $PoolFqdn
            SipAddress = ("sip:{0}@{1}" -f @($AdminCreds.UserName, $DomainName))
            Ensure = 'Present'
            Credential = $DomainCred
        }
    }
}