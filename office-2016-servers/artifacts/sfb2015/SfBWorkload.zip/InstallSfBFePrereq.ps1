Param(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$DomainName,
    [Parameter(Mandatory=$true)]
    [string]$isoURL,
    [Parameter(Mandatory=$true)]
    [string]$AzCopyUri,
    [Parameter(Mandatory=$true)]
    [string]$SqlServerPSUri,
    [Parameter(Mandatory=$true)]
    [string]$modRewriteURL,
    [Parameter(Mandatory=$true)]
    [string]$silverlightURL,
    [Parameter(Mandatory=$true)]
    [array]$Servers
)


Configuration Deploy_SkypeForBusinessPrereqAndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$isoURL,
        [Parameter(Mandatory=$true)]
        [string]$AzCopyUri,
        [Parameter(Mandatory=$true)]
        [string]$SqlServerPSUri,
        [Parameter(Mandatory=$true)]
        [string]$silverlightURL,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteURL
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $features = @(
        "NET-Framework-Core","Web-Server", "Windows-Identity-Foundation",
        "Web-Static-Content","Web-Default-Doc","Web-Http-Errors","Web-Dir-Browsing",
        "Web-Asp-Net","Web-Net-Ext","Web-ISAPI-Ext","Web-ISAPI-Filter","Web-Http-Logging",
        "Web-Log-Libraries","Web-Request-Monitor","Web-Http-Tracing","Web-Basic-Auth",
        "Web-Windows-Auth","Web-Client-Auth","Web-Filtering","Web-Stat-Compression",
        "Web-Dyn-Compression","NET-WCF-HTTP-Activation45","Web-Asp-Net45","Web-Mgmt-Tools",
        "Web-Scripting-Tools","Web-Mgmt-Compat","Server-Media-Foundation","BITS"
    )
    $DownloadsDir = "{0}\OfflineInstallers" -f $env:SystemDrive
    $SkypeForBusinessSetupFilesLocation = $env:SystemDrive + "\SkypeForBusinessISOContents"
    
    $SkypeForBusinessDeploymentPath = ("{0}\Setup\amd64" -f $SkypeForBusinessSetupFilesLocation)
    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

    $modRewriteFileName = $modRewriteURL.Split('/')[-1]
    $modRewritePath = Join-Path $DownloadsDir $modRewriteFileName

    $isoFileName = $isoURL.Split('/')[-1]
    $isoPath = Join-Path $DownloadsDir $isoFileName

    $isoFileName = $isoURL.Split('/')[-1]
    $isoPath = Join-Path $DownloadsDir $isoFileName

    $silverlightFileName = $silverlightURL.Split('/')[-1]
    $silverlightPath = Join-Path $DownloadsDir $silverlightFileName

    Node $AllNodes.Nodename {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        AzCopyProvisioning InstallTools
        {
            Uri = $AzCopyUri
            PsDscRunAsCredential = $Admincreds
        }

        AzCopyDownload DownloadModule
        {
            Uri = $SqlServerPSUri
            FileName = "SqlServer.zip"
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[AzCopyProvisioning]InstallTools"
        }

        ModulesInstaller SqlServerPSInstall
        {
            InstallFolder = "C:\OfflineInstallers"
            ModuleZipName = "SqlServer.zip"
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[AzCopyDownload]DownloadModule"
        }

        WindowsFeature RsatAdds
        {
            Name = 'RSAT-ADDS'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }
        
        WindowsFeature RsatDNS
        {
            Name = 'RSAT-DNS-Server'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        #Install required Windows features
        Foreach($feature in $features)
        {         
            WindowsFeature $feature
            {
                Ensure = 'Present'
                Name = $feature
            }
        }

        # xWaitForADDomain DscForestWait
        # { 
        #     DomainName = $DomainName 
        #     DomainUserCredential = $domainCred 
        #     RetryCount = 20 
        #     RetryIntervalSec = 5
        # } 

        # xComputer JoinDomain
        # {
        #     Name = $env:COMPUTERNAME
        #     Credential = $DomainCred
        #     DomainName = $DomainName
        #     DependsOn = '[xWaitForADDomain]DscForestWait'            
        # }

        # xPendingReboot RebootAfterDomainJoin
        # {
        #     Name = 'RebootAfterDomainJoin'
        #     DependsOn = '[xComputer]JoinDomain'
        #     PsDscRunAsCredential = $DomainCred
        # }

        xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Administrators" 
        }       

        AzCopyDownload DownloadISO
        {
            Uri = $isoURL
            FileName = $isoFileName
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[AzCopyProvisioning]InstallTools"
        }


        # xDownloadFile DownloadISO
        # {
        #     URL = "$isoURL"
        #     Checksum = $sfbISOSHA256
        #     DownloadPath = $isoPath
        #     Ensure = 'Present'
        # }

        Script MountISOAndCopyFiles
        {
            DependsOn = "[AzCopyDownload]DownloadISO"
            SetScript =
            {
                $mnt = Mount-DiskImage $using:isoPath -PassThru
                if(!(Test-Path $using:SkypeForBusinessSetupFilesLocation)){
                    mkdir $using:SkypeForBusinessSetupFilesLocation
                }
                $driveLetter = ($mnt | Get-Volume).DriveLetter
                New-PSDrive -Name $driveLetter -PSProvider FileSystem -Root "$($driveLetter):\"

                Write-Verbose ("{0}:\*" -f $driveLetter)
                Copy-Item -Recurse ("{0}:\*" -f ($mnt | Get-Volume).DriveLetter) $using:SkypeForBusinessSetupFilesLocation
            }
            TestScript = {
                Test-Path $using:SkypeForBusinessSetupFilesLocation
            }
            GetScript = { 
                $img = (Get-DiskImage $using:isoPath)
                $vol = $img | Get-Volume
                @{
                    Result = $vol.DriveLetter
                }
            }
        }
        Package VisualC
        {
            Name = 'Visual C++ Minimum Runtime package'
            Path = ("{0}\VCREDIST_X64.EXE" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/INSTALL /PASSIVE /NORESTART'
            ProductId = 'A749D8E6-B613-3BE3-8F5F-045C84EBA29B'
            DependsOn = "[Script]MountISOAndCopyFiles"
        }

        xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server" 
            DependsOn = '[Package]VisualC'           
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*"
            #DelegateComputers = ("{0}.{1}" -f ($env:COMPUTERNAME, $DomainName))
            DependsOn = '[xCredSSP]Server'
        }

        xWaitForCredSSP WaitForCredSSP {
            DependsOn = "[xCredSSP]Client"
            DomainName = $DomainName
            Credential = $DomainCred
        }

        AzCopyDownload DownloadModRewrite
        {
            Uri = $modRewriteURL
            FileName = $modRewriteFileName
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[AzCopyProvisioning]InstallTools"
        }

        # xDownloadFile DownloadModRewrite
        # {
        #     URL = $modRewriteURL
        #     Checksum = $modRewriteSHA256
        #     DownloadPath = $modRewritePath
        #     Ensure = 'Present'
        #     DependsOn = '[xWaitForCredSSP]WaitForCredSSP'

        # }

        Package ModRewriteModule
        {
            # An updated package of Rewrite mod needs to be installed
            # on windows server 2016 before bootstrapping the components
            Name = 'IIS URL Rewrite Module 2'
            Path =  $modRewritePath
            Arguments = '/PASSIVE /NORESTART'
            ProductId = '38D32370-3A31-40E9-91D0-D236F47E3C4A'
            DependsOn = '[AzCopyDownload]DownloadModRewrite'
        }

        AzCopyDownload DownloadSilverlight
        {
            Uri = $silverlightURL
            FileName = $silverlightFileName
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[Package]ModRewriteModule"
        }

        Script InstallSilverlight
        {
            DependsOn = "[AzCopyDownload]DownloadSilverlight"
            SetScript =
            {
                Write-Verbose (">>>>> {0}" -f $using:silverlightPath)
                & $using:silverlightPath /q
            }
            TestScript = {
                return $false
            }
            GetScript = { 
                @{
                    Result = ""
                }
            }
        }

        Package SkypeForBusinessCoreComponents
        {
            Name = 'Skype for Business Server 2015, Core Components'
            Path =  ("{0}\SETUP\ocscore.msi" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/PASSIVE /NORESTART'
            ProductId = 'DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F'
            DependsOn = '[Script]InstallSilverlight'
        }

        xCsBootStrapper BootstrapAdminTools
        {
            Name = 'BootstrapAdminTools'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[Package]SkypeForBusinessCoreComponents'
        }
        
        xCsBootStrapper InstallSqlExpress
        {
            Name = 'BootstrapSqlExpress'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[xCsBootStrapper]BootstrapAdminTools'
        }

        xCsBootStrapper BootStrapLocalMgmt
        {
            Name = 'BootStrapLocalMgmt'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[xCsBootStrapper]InstallSqlExpress'
        }
    }
}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="*"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

foreach ($srv in $Servers){
    $ConfigData["AllNodes"] += @{NodeName = $srv}
}

$OutPutPath = ("{0}\DSC" -f $env:SystemDrive)

$Parameters = @{
    ConfigurationData = $ConfigData
    AdminCreds = $AdminCreds
    DomainName = $DomainName
    isoURL = $isoURL
    AzCopyUri = $AzCopyUri
    SqlServerPSUri = $SqlServerPSUri
    modRewriteURL = $modRewriteURL
    silverlightURL = $silverlightURL
    OutPutPath = $OutPutPath
}


Deploy_SkypeForBusinessPrereqAndComponents @Parameters

Start-DscConfiguration -Path $OutPutPath -Verbose -Wait -Force
