Param
(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$DomainName,
    [Parameter(Mandatory=$true)]
    [string]$CA,
    [Parameter(Mandatory=$true)]
    [string]$cmuURL,
    [Parameter(Mandatory=$true)]
    [array]$Servers,
    [Parameter(Mandatory=$true)]
    [array]$EdgeServers
)


Configuration Deploy_SkypeForBusinessFrontEndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$CA,
        [Parameter(Mandatory=$true)]
        [string]$cmuURL,
        [Parameter(Mandatory=$true)]
        [array]$FrontEndServersFQDN,
        [Parameter(Mandatory=$true)]
        [array]$EdgeServers
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $DownloadsDir = "{0}\OfflineInstallers" -f $env:SystemDrive

    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    $SkypeForBusinessSetupFilesLocation = $env:SystemDrive + "\SkypeForBusinessISOContents"
    $SkypeForBusinessDeploymentPath = ("{0}\Setup\amd64" -f $SkypeForBusinessSetupFilesLocation)

    $credentialMap = @{
        "edge" = $AdminCreds
        "frontend" = $DomainCred
    }

    $cmuFileName = $cmuURL.Split('/')[-1]
    $cmuFilePath = Join-Path $DownloadsDir $cmuFileName

    $sfbConfigLocation = "{0}:\SfbConfig.zip" -f $env:SystemDrive

    Node $AllNodes.Nodename {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        xCsConfigurationImport ImportToLocalstore
        {
            Name = 'ImportToLocalstore'
            LocalStore = $true
            Credential = $DomainCred
        }

        xCsReplica AssertReplicaEnabled
        {
            Name = "ReplicaEnabled"
            Credential = $credentialMap[$Node.Roles[0]]
            DependsOn = '[xCsConfigurationImport]ImportToLocalstore'
        }

        xCsWindowsService Replica
        {
            Name = 'Replica'
            Status = 'Running'
            Credential = $credentialMap[$Node.Roles[0]]
            DependsOn = '[xCsReplica]AssertReplicaEnabled'
        }
        
        xCsBootStrapper InstallRolesInTopology
        {
            Name = 'InstallRolesInTopology'
            Credential = $credentialMap[$Node.Roles[0]]
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[xCsWindowsService]Replica'
        }

        # xDownloadFile DownloadCMU
        # {
        #     URL = "$cmuURL"
        #     Checksum = $sfbCMUSHA256
        #     DownloadPath = ("{0}\{1}" -f @($env:SystemDrive, $cmuURL.Split('/')[-1]))
        #     Ensure = 'Present'
        #     DependsOn = "[xCsBootStrapper]InstallRolesInTopology"
        # }
        
        # AzCopyDownload DownloadCMU
        # {
        #     Uri = $cmuURL
        #     FileName = $cmuFileName
        #     PsDscRunAsCredential = $Admincreds
        # }
        # Script SkypeForBusinessCMUPostInstall
        # {
        #     SetScript = {
        #         & $using:cmuFilePath /silentmode
        #     }
        #     GetScript = {
        #         @{
        #             Result = $null
        #         }
        #     }
        #     TestScript = { return $false }
        #     DependsOn = '[AzCopyDownload]DownloadCMU'
        # }

        xCsCertificate DefaultInternalExternal
        {
            New = $true
            Type = 'Default','WebServicesInternal','WebServicesExternal'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'Enterprise Edition Certificate'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1},{3},{4}.{1},{5}.{1},{6}.{1},{7},{8}.{1},{9}.{1}" -f @(
                "pool", $DomainName, "webint",
                ($FrontEndServersFQDN -Join ","),
                "admin", "dialin", "meet",
                ($EdgeServers -Join ","),
                "sipexternal", "edge"))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
            # DependsOn = '[Script]SkypeForBusinessCMUPostInstall'
        }

        # xCsCertificate EdgeCertificates
        # {
        #     New = $true
        #     Type = "AccessEdgeExternal","DataEdgeExternal","AudioVideoAuthentication"
        #     ComputerFqdn = $EdgeServers[0]
        #     CA = $CA
        #     FriendlyName = 'Edge server external certificate'
        #     PrivateKeyExportable = $true
        #     DomainName = ("{0}.{1},{2}.{1},{3}" -f @(
        #         "edge", $DomainName, "sipexternal",
        #         ($EdgeServers -Join ",")))
        #     Credential = $DomainCred
        #     Ensure = 'Present'
        #     DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
        #     # DependsOn = '[Script]SkypeForBusinessCMUPostInstall'
        # }

        # xCsCertificate EdgeCertificateInternal
        # {
        #     New = $true
        #     Type = "Internal"
        #     ComputerFqdn = $EdgeServers[0]
        #     CA = $CA
        #     FriendlyName = 'Edge server Internal certificate'
        #     PrivateKeyExportable = $true
        #     DomainName = ("{0}.{1},{2}.{1},{3}" -f @(
        #         "edge", $DomainName, "sipexternal",
        #         ($EdgeServers -Join ",")))
        #     Credential = $DomainCred
        #     Ensure = 'Present'
        #     DependsOn = '[xCsCertificate]EdgeCertificates'
        #     # DependsOn = '[Script]SkypeForBusinessCMUPostInstall'
        # }

        xCsCertificate OAuthCert
        {
            New = $true
            Type = 'OAuthTokenIssuer'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'OAuth Cert'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1},{3}" -f @("pool", $DomainName, "webint", ($FrontEndServersFQDN -Join ",")))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsCertificate]DefaultInternalExternal'

        }
    }
}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="*"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

foreach ($srv in $Servers){
    $ConfigData["AllNodes"] += @{
        NodeName = $srv
        Roles = @("frontend")
    }
}

$Parameters = @{
    ConfigurationData = $ConfigData
    OutPutPath = "C:\DSC"
    AdminCreds = $AdminCreds
    DomainName = $DomainName
    CA = $CA
    cmuURL = $cmuURL
    FrontEndServersFQDN = $Servers
    EdgeServers = $EdgeServers
}

$env:PSModulePath += ";C:\Program Files\Common Files\Skype for Business Server 2015\Modules" 

Deploy_SkypeForBusinessFrontEndComponents @Parameters

Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force
