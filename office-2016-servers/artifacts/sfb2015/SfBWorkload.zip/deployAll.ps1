Configuration Deploy_AllSkypeForBusinessComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$isoURL,
        [Parameter(Mandatory=$true)]
        [string]$sfbISOSHA256,
        [Parameter(Mandatory=$true)]
        [string]$cmuURL,
        [Parameter(Mandatory=$true)]
        [string]$sfbCMUSHA256,
        [Parameter(Mandatory=$true)]
        [string]$PrimarySqlServerFQDN,
        [Parameter(Mandatory=$true)]
        [string]$SecondarySqlServerFQDN,
        [Parameter(Mandatory=$true)]
        [string]$SqlAOListenerFQDN,
        [Parameter(Mandatory=$true)]
        [string]$SqlAG,
        [Parameter(Mandatory=$true)]
        [string]$LBIPAddress,
        [Parameter(Mandatory=$true)]
        [string]$DNSserver,
        [Parameter(Mandatory=$true)]
        [array]$FrontEndServersFQDN,
        [Parameter(Mandatory=$true)]
        [string]$ShareFqdn,
        [Parameter(Mandatory=$true)]
        [string]$ShareName,
        [Parameter(Mandatory=$true)]
        [string]$CA,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteURL,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteSHA256
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $features = @(
        "NET-Framework-Core","Web-Server", "Windows-Identity-Foundation",
        "Web-Static-Content","Web-Default-Doc","Web-Http-Errors","Web-Dir-Browsing",
        "Web-Asp-Net","Web-Net-Ext","Web-ISAPI-Ext","Web-ISAPI-Filter","Web-Http-Logging",
        "Web-Log-Libraries","Web-Request-Monitor","Web-Http-Tracing","Web-Basic-Auth",
        "Web-Windows-Auth","Web-Client-Auth","Web-Filtering","Web-Stat-Compression",
        "Web-Dyn-Compression","NET-WCF-HTTP-Activation45","Web-Asp-Net45","Web-Mgmt-Tools",
        "Web-Scripting-Tools","Web-Mgmt-Compat","Server-Media-Foundation","BITS"
    )

    $SkypeForBusinessSetupFilesLocation = $env:SystemDrive + "\SkypeForBusinessISOContents"
    $isoPath = ("{0}\{1}" -f @($env:SystemDrive, $isoURL.Split('/')[-1]))
    $SkypeForBusinessDeploymentPath = ("{0}\Setup\amd64" -f $SkypeForBusinessSetupFilesLocation)
    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    $modRewritePath = ("{0}\{1}" -f @($env:SystemDrive, $modRewriteURL.Split('/')[-1]))
    $PoolFqdn = ("pool.{0}" -f $DomainName)

    Node localhost {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
        }

        WindowsFeature RsatAdds
        {
            Name = 'RSAT-ADDS'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }
        
        WindowsFeature RsatDNS
        {
            Name = 'RSAT-DNS-Server'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        #Install required Windows features
        Foreach($feature in $features)
        {         
            WindowsFeature $feature
            {
                Ensure = 'Present'
                Name = $feature
            }
        }

        xWaitForADDomain DscForestWait
        { 
            DomainName = $DomainName 
            DomainUserCredential = $domainCred 
            RetryCount = 20 
            RetryIntervalSec = 5
        } 

        xComputer JoinDomain
        {
            Name = $env:COMPUTERNAME
            Credential = $DomainCred
            DomainName = $DomainName
            DependsOn = '[xWaitForADDomain]DscForestWait'            
        }

        xPendingReboot RebootAfterDomainJoin
        {
            Name = 'RebootAfterDomainJoin'
            DependsOn = '[xComputer]JoinDomain'
            PsDscRunAsCredential = $DomainCred
        }

        xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Administrators" 
        }       

        xDownloadFile DownloadISO
        {
            URL = "$isoURL"
            Checksum = $sfbISOSHA256
            DownloadPath = $isoPath
            Ensure = 'Present'
        }

        xDownloadFile DownloadCMU
        {
            URL = "$cmuURL"
            Checksum = $sfbCMUSHA256
            DownloadPath = ("{0}\{1}" -f @($env:SystemDrive, $cmuURL.Split('/')[-1]))
            Ensure = 'Present'
        }

        Script MountISOAndCopyFiles
        {
            DependsOn = "[xDownloadFile]DownloadISO"
            SetScript =
            {
                $mnt = Mount-DiskImage $using:isoPath -PassThru
                if(!(Test-Path $using:SkypeForBusinessSetupFilesLocation)){
                    mkdir $using:SkypeForBusinessSetupFilesLocation
                }
                $driveLetter = ($mnt | Get-Volume).DriveLetter
                New-PSDrive -Name $driveLetter -PSProvider FileSystem -Root "$($driveLetter):\"

                Write-Verbose ("{0}:\*" -f $driveLetter)
                Copy-Item -Recurse ("{0}:\*" -f ($mnt | Get-Volume).DriveLetter) $using:SkypeForBusinessSetupFilesLocation
            }
            TestScript = {
                Test-Path $using:SkypeForBusinessSetupFilesLocation
            }
            GetScript = { 
                $img = (Get-DiskImage $using:isoPath)
                $vol = $img | Get-Volume
                @{
                    Result = $vol.DriveLetter
                }
            }
        }
        Package VisualC
        {
            Name = 'Visual C++ Minimum Runtime package'
            Path = ("{0}\VCREDIST_X64.EXE" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/INSTALL /PASSIVE /NORESTART'
            ProductId = 'A749D8E6-B613-3BE3-8F5F-045C84EBA29B'
            DependsOn = "[Script]MountISOAndCopyFiles"
        }

        xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server" 
            DependsOn = '[Package]VisualC'           
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = "*"
            #DelegateComputers = ("{0}.{1}" -f ($env:COMPUTERNAME, $DomainName))
            DependsOn = '[xCredSSP]Server'
        }

        xWaitForCredSSP WaitForCredSSP {
            DependsOn = "[xCredSSP]Client"
            DomainName = $DomainName
            Credential = $DomainCred
        }

        Package SkypeForBusinessCoreComponents
        {
            Name = 'Skype for Business Server 2015, Core Components'
            Path =  ("{0}\SETUP\ocscore.msi" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/PASSIVE /NORESTART'
            ProductId = 'DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F'
            DependsOn = '[xWaitForCredSSP]WaitForCredSSP'
        }

        xCsBootStrapper BootstrapAdminTools
        {
            Name = 'BootstrapAdminTools'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[Package]SkypeForBusinessCoreComponents'
        }
        
        xCsBootStrapper InstallSqlExpress
        {
            Name = 'BootstrapSqlExpress'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            # LogFile = 'C:\BootStrapSqlEsxpressLog.txt'
            DependsOn = '[xCsBootStrapper]BootstrapAdminTools'
        }

        xCsBootStrapper BootStrapLocalMgmt
        {
            Name = 'BootStrapLocalMgmt'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            # LogFile = 'C:\BootStrapLocalMgmt.txt'
            DependsOn = '[xCsBootStrapper]InstallSqlExpress'
            # DependsOn = '[Script]SetConfigLocation'
            # DependsOn = "[xADGroupMember]RTCUniversalServerAdmins"
        }

        # Script SkypeForBusinessCMU
        # {
        #     SetScript = {
        #         $url = $using:cmuURL
        #         $cmuPath = ("{0}\{1}" -f @($env:SystemDrive, $url.split('/')[-1]))
        #         & $cmuPath /silentmode
        #     }
        #     GetScript = {
        #         @{
        #             Result = $null
        #         }
        #     }
        #     TestScript = { return $false }
        #     DependsOn = '[xCsBootStrapper]BootStrapLocalMgmt'
        # }

        Script Reboot
        {
            TestScript = {
                $stateExists = (Test-Path HKLM:\SOFTWARE\sfbState)
                if (!$stateExists) {
                    New-Item -Path HKLM:\SOFTWARE -Name sfbState -Force
                    return $false
                }
                $shouldReboot = Get-ItemProperty -Path HKLM:\SOFTWARE\sfbState -Name "ShouldReboot" -ErrorAction SilentlyContinue
                if (!$shouldReboot -or $shouldReboot -eq "1") {
                    return $false
                }
                return $true
            }
            SetScript = {
                Set-ItemProperty -Path HKLM:\SOFTWARE\sfbState -Name "ShouldReboot" -Value "0"
                $global:DSCMachineStatus = 1 
            }
            GetScript = { return @{result = 'result'}}
            DependsOn = '[xCsBootStrapper]BootStrapLocalMgmt'
        }

        xDnsServerResourceRecordA lyncdiscoverinternal
        {
            Name = "lyncdiscoverinternal"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }

        xDnsServerResourceRecordA webint
        {
            Name = "webint"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }
        xDnsServerResourceRecordA scheduler
        {
            Name = "scheduler"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }

        xDnsServerResourceRecordA Sip
        {
            Name = "sip"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }

        xDnsServerResourceRecordA Meet
        {
            Name = "meet"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }
        xDnsServerResourceRecordA Admin
        {
            Name = "admin"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }

        xDnsServerResourceRecordA dialin
        {
            Name = "dialin"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }

        xDnsServerResourceRecordA pool
        {
            Name = "pool"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[Script]Reboot'
        }

        xCsAdServerSchema AdServerSchema
        {
            Identity = 'ExtendSchema'
            Credential = $DomainCred
            DependsOn = '[Script]Reboot'

        }

        xCsAdForest AdForest
        {
            Identity = 'AdForestPrep'
            Credential = $DomainCred            
            DependsOn = '[xCsAdServerSchema]AdServerSchema'
        }

        xCsAdDomain AdDomain
        {
            Identity = 'AdDomainPrep'
            Credential = $DomainCred
            DependsOn = '[xCsAdForest]AdForest'   
        }

        xADGroupMember CSAdministrator
        {
            Identity = "CSAdministrator"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsAdDomain]AdDomain'
        }

        xADGroupMember RTCUniversalServerAdmins
        {
            Identity = "RTCUniversalServerAdmins"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsAdDomain]AdDomain'
        }

        xSetCsManagementConnection SetmanagementConnection {
            SqlServerFQDN = $PrimarySqlServerFQDN
            StoreProvider = "Sql"
            Credentials = $DomainCred
            DependsOn = "[xADGroupMember]RTCUniversalServerAdmins"
        }

        xCsDatabaseInstall CentralManagementDatabase
        {
            CentralManagementDatabase = $True
            DatabaseTypes = "User","Application"
            Credential = $DomainCred
            SqlServerFqdn = $PrimarySqlServerFQDN
            Ensure = 'Present' 
            DependsOn = '[xSetCsManagementConnection]SetmanagementConnection'       
        }

        xSqlNewAGDatabase AddDatabasesToAG {
            DatabaseNames = "lis","xds","rgsconfig","rgsdyn","cpsdyn","rtcxds","rtcshared","rtcab"
            SqlAdministratorCredential = $DomainCred
            PrimaryReplica = $PrimarySqlServerFQDN
            SecondaryReplica = $SecondarySqlServerFQDN
            SqlAlwaysOnAvailabilityGroupName = $SqlAG
            DependsOn = '[xCsDatabaseInstall]CentralManagementDatabase'       
        }

        xSetCsManagementConnection SetmanagementConnectionPost {
            SqlServerFQDN = $SqlAOListenerFQDN
            StoreProvider = "Sql"
            Credentials = $DomainCred
            DependsOn = "[xSqlNewAGDatabase]AddDatabasesToAG"
        }

        xCsTopology EnterpriseTopology
        {
            Name = "Enterprise"
            Credential = $DomainCred
            FrontEndServersFQDN = $FrontEndServersFQDN
            ShareFqdn = $ShareFqdn
            ShareName = $ShareName
            SqlServerFQDN = $PrimarySqlServerFQDN
            SqlAOGListenerFqdn = $SqlAOListenerFQDN
            Domain = $DomainName
            # InternalPoolOverride = ("webint.{0}" -f $DomainName)
            PoolFqdn = ("pool.{0}" -f $DomainName)
            DependsOn = '[xSqlNewAGDatabase]AddDatabasesToAG'
        }   

        xCsConfigurationImport ImportToLocalstore
        {
            Name = 'ImportToLocalstore'
            LocalStore = $true
            Credential = $DomainCred
            DependsOn = "[xCsTopology]EnterpriseTopology"
            # DependsOn = "[xCsWindowsService]Replica"
            # DependsOn = '[xSetCsManagementConnection]SetmanagementConnection2'
        }
        xDownloadFile DownloadModRewrite
        {
            URL = $modRewriteURL
            Checksum = $modRewriteSHA256
            DownloadPath = $modRewritePath
            Ensure = 'Present'
            DependsOn = '[xCsConfigurationImport]ImportToLocalstore'

        }

        Package ModRewriteModule
        {
            # An updated package of Rewrite mod needs to be installed
            # on windows server 2016 before bootstrapping the components
            Name = 'IIS URL Rewrite Module 2'
            Path =  $modRewritePath
            Arguments = '/PASSIVE /NORESTART'
            ProductId = '38D32370-3A31-40E9-91D0-D236F47E3C4A'
            DependsOn = '[xDownloadFile]DownloadModRewrite'
        }

        xCsReplica AssertReplicaEnabled
        {
            Name = "ReplicaEnabled"
            Credential = $DomainCred
            DependsOn = '[Package]ModRewriteModule'
        }

        xCsWindowsService Replica
        {
            Name = 'Replica'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsReplica]AssertReplicaEnabled'
        }
        
        xCsBootStrapper InstallRolesInTopology
        {
            Name = 'InstallRolesInTopology'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[xCsWindowsService]Replica'
        }
        
        # Script SkypeForBusinessCMUPostInstall
        # {
        #     SetScript = {
        #         $url = $using:cmuURL
        #         $cmuPath = ("{0}\{1}" -f @($env:SystemDrive, $url.split('/')[-1]))
        #         & $cmuPath /silentmode
        #     }
        #     GetScript = {
        #         @{
        #             Result = $null
        #         }
        #     }
        #     TestScript = { return $false }
        #     DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
        # }

        xCsCertificate DefaultInternalExternal
        {
            New = $true
            Type = 'Default','WebServicesInternal','WebServicesExternal'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'Enterprise Edition Certificate'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1},{3}" -f @("pool", $DomainName, "webint", ($FrontEndServersFQDN -Join ",")))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
            # DependsOn = '[Script]SkypeForBusinessCMUPostInstall'
        }

        xCsCertificate OAuthCert
        {
            New = $true
            Type = 'OAuthTokenIssuer'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'OAuth Cert'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1}" -f @("pool", $DomainName, "webint"))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsCertificate]DefaultInternalExternal'

        }
        <#
        xCsWindowsService StartAll
        {
            Name = 'All'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsCertificate]OAuthCert'
        }

        xCsUser EnableAdmin
        {
            Identity = ("{0}\{1}" -f @($DomainName, $AdminCreds.UserName))
            RegistrarPool = $PoolFqdn
            SipAddress = ("sip:{0}@{1}" -f @($AdminCreds.UserName, $DomainName))
            Ensure = 'Present'
            Credential = $DomainCred
        }
        #>
    }
}

Configuration Deploy_SkypeForBusinessPrereqAndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$isoURL,
        [Parameter(Mandatory=$true)]
        [string]$sfbISOSHA256,
        [Parameter(Mandatory=$true)]
        [string]$cmuURL,
        [Parameter(Mandatory=$true)]
        [string]$sfbCMUSHA256,
        [Parameter(Mandatory=$true)]
        [string]$CA,
        [Parameter(Mandatory=$true)]
        [array]$FrontEndServersFQDN,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteURL,
        [Parameter(Mandatory=$true)]
        [string]$modRewriteSHA256
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $features = @(
        "NET-Framework-Core","Web-Server", "Windows-Identity-Foundation",
        "Web-Static-Content","Web-Default-Doc","Web-Http-Errors","Web-Dir-Browsing",
        "Web-Asp-Net","Web-Net-Ext","Web-ISAPI-Ext","Web-ISAPI-Filter","Web-Http-Logging",
        "Web-Log-Libraries","Web-Request-Monitor","Web-Http-Tracing","Web-Basic-Auth",
        "Web-Windows-Auth","Web-Client-Auth","Web-Filtering","Web-Stat-Compression",
        "Web-Dyn-Compression","NET-WCF-HTTP-Activation45","Web-Asp-Net45","Web-Mgmt-Tools",
        "Web-Scripting-Tools","Web-Mgmt-Compat","Server-Media-Foundation","BITS"
    )
    $SkypeForBusinessSetupFilesLocation = $env:SystemDrive + "\SkypeForBusinessISOContents"
    $isoPath = ("{0}\{1}" -f @($env:SystemDrive, $isoURL.Split('/')[-1]))
    $SkypeForBusinessDeploymentPath = ("{0}\Setup\amd64" -f $SkypeForBusinessSetupFilesLocation)
    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    $modRewritePath = ("{0}\{1}" -f @($env:SystemDrive, $modRewriteURL.Split('/')[-1]))
    $PoolFqdn = ("pool.{0}" -f $DomainName)

    Node $AllNodes.Nodename {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            #PSDscAllowDomainUser = $true
        }

        WindowsFeature RsatAdds
        {
            Name = 'RSAT-ADDS'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }
        
        WindowsFeature RsatDNS
        {
            Name = 'RSAT-DNS-Server'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        #Install required Windows features
        Foreach($feature in $features)
        {         
            WindowsFeature $feature
            {
                Ensure = 'Present'
                Name = $feature
            }
        }

        #xWaitForADDomain DscForestWait
        #{ 
        #    DomainName = $DomainName 
        #    DomainUserCredential = $domainCred 
        #    RetryCount = 20 
        #    RetryIntervalSec = 5
        #} 

        #xComputer JoinDomain
        #{
        #    Name = $env:COMPUTERNAME
        #    Credential = $DomainCred
        #    DomainName = $DomainName
        #    DependsOn = '[xWaitForADDomain]DscForestWait'            
        #}

        #xPendingReboot RebootAfterDomainJoin
        #{
        #    Name = 'RebootAfterDomainJoin'
        #    DependsOn = '[xComputer]JoinDomain'
        #    PsDscRunAsCredential = $DomainCred
        #}

        xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Administrators" 
        }       

        xDownloadFile DownloadISO
        {
            URL = "$isoURL"
            Checksum = $sfbISOSHA256
            DownloadPath = $isoPath
            Ensure = 'Present'
        }

        xDownloadFile DownloadCMU
        {
            URL = "$cmuURL"
            Checksum = $sfbCMUSHA256
            DownloadPath = ("{0}\{1}" -f @($env:SystemDrive, $cmuURL.Split('/')[-1]))
            Ensure = 'Present'
        }

        Script MountISOAndCopyFiles
        {
            DependsOn = "[xDownloadFile]DownloadISO"
            SetScript =
            {
                $mnt = Mount-DiskImage $using:isoPath -PassThru
                if(!(Test-Path $using:SkypeForBusinessSetupFilesLocation)){
                    mkdir $using:SkypeForBusinessSetupFilesLocation
                }
                $driveLetter = ($mnt | Get-Volume).DriveLetter
                New-PSDrive -Name $driveLetter -PSProvider FileSystem -Root "$($driveLetter):\"

                Write-Verbose ("{0}:\*" -f $driveLetter)
                Copy-Item -Recurse ("{0}:\*" -f ($mnt | Get-Volume).DriveLetter) $using:SkypeForBusinessSetupFilesLocation
            }
            TestScript = {
                Test-Path $using:SkypeForBusinessSetupFilesLocation
            }
            GetScript = { 
                $img = (Get-DiskImage $using:isoPath)
                $vol = $img | Get-Volume
                @{
                    Result = $vol.DriveLetter
                }
            }
        }
        Package VisualC
        {
            Name = 'Visual C++ Minimum Runtime package'
            Path = ("{0}\VCREDIST_X64.EXE" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/INSTALL /PASSIVE /NORESTART'
            ProductId = 'A749D8E6-B613-3BE3-8F5F-045C84EBA29B'
            DependsOn = "[Script]MountISOAndCopyFiles"
        }

        xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server" 
            DependsOn = '[Package]VisualC'           
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            #DelegateComputers = ("{0}.{1}" -f ($env:COMPUTERNAME, $DomainName))
            DelegateComputers = "*"
            DependsOn = '[xCredSSP]Server'
        }

        xWaitForCredSSP WaitForCredSSP {
            DependsOn = "[xCredSSP]Client"
            DomainName = $DomainName
            Credential = $DomainCred
        }

        Package SkypeForBusinessCoreComponents
        {
            Name = 'Skype for Business Server 2015, Core Components'
            Path =  ("{0}\SETUP\ocscore.msi" -f $SkypeForBusinessDeploymentPath)
            Arguments = '/PASSIVE /NORESTART'
            ProductId = 'DE39F60A-D57F-48F5-A2BD-8BA3FE794E1F'
            DependsOn = '[xWaitForCredSSP]WaitForCredSSP'
        }

        xCsBootStrapper BootstrapAdminTools
        {
            Name = 'BootstrapAdminTools'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[Package]SkypeForBusinessCoreComponents'
        }
        
        xCsBootStrapper InstallSqlExpress
        {
            Name = 'BootstrapSqlExpress'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            # LogFile = 'C:\BootStrapSqlEsxpressLog.txt'
            DependsOn = '[xCsBootStrapper]BootstrapAdminTools'
        }

        xCsBootStrapper BootStrapLocalMgmt
        {
            Name = 'BootStrapLocalMgmt'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            # LogFile = 'C:\BootStrapLocalMgmt.txt'
            DependsOn = '[xCsBootStrapper]InstallSqlExpress'
            # DependsOn = '[Script]SetConfigLocation'
            # DependsOn = "[xADGroupMember]RTCUniversalServerAdmins"
        }

        #Script SkypeForBusinessCMU
        #{
        #    SetScript = {
        #        $url = $using:cmuURL
        #        $cmuPath = ("{0}\{1}" -f @($env:SystemDrive, $url.split('/')[-1]))
        #        & $cmuPath /silentmode
        #    }
        #    GetScript = {
        #        @{
        #            Result = $null
        #        }
        #    }
        #    TestScript = { return $false }
        #    DependsOn = '[xCsBootStrapper]BootstrapAdminTools'
        #}

        #Script Reboot
        #{
        #    TestScript = {
        #        $stateExists = (Test-Path HKLM:\SOFTWARE\sfbState)
        #        if (!$stateExists) {
        #            New-Item -Path HKLM:\SOFTWARE -Name sfbState -Force
        #            return $false
        #        }
        #        $shouldReboot = Get-ItemProperty -Path HKLM:\SOFTWARE\sfbState -Name "ShouldReboot" -ErrorAction SilentlyContinue
        #        if (!$shouldReboot -or $shouldReboot -eq "1") {
        #            return $false
        #        }
        #        return $true
        #    }
        #    SetScript = {
        #        Set-ItemProperty -Path HKLM:\SOFTWARE\sfbState -Name "ShouldReboot" -Value "0"
        #        $global:DSCMachineStatus = 1 
        #    }
        #    GetScript = { return @{result = 'result'}}
        #    DependsOn = '[xCsBootStrapper]BootStrapLocalMgmt'
        #}
        
        xADGroupMember CSAdministrator
        {
            Identity = "CSAdministrator"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsBootStrapper]BootStrapLocalMgmt'
        }

        xADGroupMember RTCUniversalServerAdmins
        {
            Identity = "RTCUniversalServerAdmins"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xADGroupMember]CSAdministrator'
        }


        xCsReplica AssertReplicaEnabled
        {
            Name = "ReplicaEnabled"
            Credential = $DomainCred
            DependsOn = '[xADGroupMember]RTCUniversalServerAdmins'
        }

        xCsWindowsService Replica
        {
            Name = 'Replica'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsReplica]AssertReplicaEnabled'
        }   

        xCsConfigurationImport ImportToLocalstore
        {
            Name = 'ImportToLocalstore'
            LocalStore = $True
            Credential = $DomainCred
            DependsOn = "[xCsWindowsService]Replica"
            # DependsOn = '[xSetCsManagementConnection]SetmanagementConnection2'
        }

        xDownloadFile DownloadModRewrite
        {
            URL = $modRewriteURL
            Checksum = $modRewriteSHA256
            DownloadPath = $modRewritePath
            Ensure = 'Present'
            DependsOn = '[xCsConfigurationImport]ImportToLocalstore'

        }

        Package ModRewriteModule
        {
            # An updated package of Rewrite mod needs to be installed
            # on windows server 2016 before bootstrapping the components
            Name = 'IIS URL Rewrite Module 2'
            Path =  $modRewritePath
            Arguments = '/PASSIVE /NORESTART'
            ProductId = '38D32370-3A31-40E9-91D0-D236F47E3C4A'
            DependsOn = '[xDownloadFile]DownloadModRewrite'
        }

        xCsBootStrapper InstallRolesInTopology
        {
            Name = 'InstallRolesInTopology'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Skype for Business Server 2015\Deployment\Bootstrapper.exe"
            SourceDirectory = $SkypeForBusinessDeploymentPath
            DependsOn = '[Package]ModRewriteModule'
        }

        xCsCertificate DefaultInternalExternal
        {
            New = $true
            Type = 'Default','WebServicesInternal','WebServicesExternal'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'Enterprise Edition Certificate'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1},{3}" -f @("pool", $DomainName, "webint", ($FrontEndServersFQDN -Join ",")))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
        }

        xCsCertificate OAuthCert
        {
            New = $true
            Type = 'OAuthTokenIssuer'
            ComputerFqdn = ("{0}.{1}" -f @($env:COMPUTERNAME, $DomainName))
            CA = $CA
            FriendlyName = 'OAuth Cert'
            PrivateKeyExportable = $true
            DomainName = ("{0}.{1},{2}.{1}" -f @("pool", $DomainName, "webint"))
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsCertificate]DefaultInternalExternal'

        }
        <#
        xCsWindowsService StartAll
        {
            Name = 'All'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsCertificate]OAuthCert'
        }

        xCsUser EnableAdmin
        {
            Identity = ("{0}\{1}" -f @($DomainName, $AdminCreds.UserName))
            RegistrarPool = $PoolFqdn
            SipAddress = ("sip:{0}@{1}" -f @($AdminCreds.UserName, $DomainName))
            Ensure = 'Present'
            Credential = $DomainCred
        }
        #>
    }
}

<#
$secpasswd = ConvertTo-SecureString "egPitEvJeam7" -AsPlainText -Force
$mycreds = New-Object System.Management.Automation.PSCredential ("lcladmin", $secpasswd)


$ErrorActionPreference = "Stop"

$ConfigData = @{
     AllNodes = @(
         @{
             NodeName="localhost"
             PSDscAllowPlainTextPassword = $true
             # CA = 'srvdc-dc-1.contoso.com\contoso-srvdc-dc-1-CA'
         }
)}  

$Parameters = @{
       AdminCreds = $mycreds
       ConfigurationData = $ConfigData
       OutPutPath = "C:\DSC"
       PrimarySqlServerFQDN = "server-sql-1.contoso.com"
       SecondarySqlServerFQDN = "server-sql-0.contoso.com"
       SqlAOListenerFQDN = "aon-listener-deploy.contoso.com"
       # Gateway = "10.0.0.1"
       # DnsServerAddress = "10.0.0.11"
       DomainName = "contoso.com"
       SqlAG = "alwayson-ag"
       LBIPAddress = "10.0.0.250"
       DnsServer = 'srvdc-dc-1.contoso.com'
       ShareName = "data"
       ShareFqdn = "fs01.contoso.com"
       CA = "srvdc-dc-1.contoso.com\contoso-srvdc-dc-1-CA"
       isoURL = "https://resources.blob.redmond.azurestack.corp.microsoft.com/resources/SfB-E-9319.0-enUS.ISO"
       sfbISOSHA256 = "00F5E5E878FE37D781E94AD62FF2032B13008753B5823324138F68D7DC7189F8"
       cmuURL = "https://resources.blob.redmond.azurestack.corp.microsoft.com/resources/SkypeServerUpdateInstaller.exe"
       sfbCMUSHA256 = "BB6FD362F7926EDA5107926762DCBB45E9AFA357AF9F89046C2442C24F6A0092"
       modRewriteURL = "https://resources.blob.redmond.azurestack.corp.microsoft.com/resources/rewrite_amd64_en-US.msi"
       modRewriteSHA256 = "7b327108055c4b5ba9445e3b1afcc4dc5edd373baa83ebe6dcb0b1ce57ee3fc2"
       FrontEndServersFQDN = "sfb13-fe-01.contoso.com","sfb13-fe-02.contoso.com","sfb13-fe-03.contoso.com"
}
   
Deploy_AllSkypeForBusinessComponents @Parameters
Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force

#>
<#
$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="*"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        },
       @{
             NodeName="sfb13-fe-02.contoso.com"
        },
        @{
             NodeName="sfb13-fe-03.contoso.com"
        }
 )}  

$Parameters = @{
    AdminCreds = $mycreds
    ConfigurationData = $ConfigData
    DomainName = "contoso.com"
    isoURL = "https://resources.blob.redmond.azurestack.corp.microsoft.com/resources/SfB-E-9319.0-enUS.ISO"
    sfbISOSHA256 = "00F5E5E878FE37D781E94AD62FF2032B13008753B5823324138F68D7DC7189F8"
    cmuURL = "https://resources.blob.redmond.azurestack.corp.microsoft.com/resources/SkypeServerUpdateInstaller.exe"
    sfbCMUSHA256 = "BB6FD362F7926EDA5107926762DCBB45E9AFA357AF9F89046C2442C24F6A0092"
    CA = "srvdc-dc-1.contoso.com\contoso-srvdc-dc-1-CA"
    modRewriteURL = "https://resources.blob.redmond.azurestack.corp.microsoft.com/resources/rewrite_amd64_en-US.msi"
    modRewriteSHA256 = "7b327108055c4b5ba9445e3b1afcc4dc5edd373baa83ebe6dcb0b1ce57ee3fc2"
    FrontEndServersFQDN = "sfb13-fe-01.contoso.com","sfb13-fe-02.contoso.com","sfb13-fe-03.contoso.com"
    OutPutPath = "C:\DSC2"
}


Deploy_SkypeForBusinessPrereqAndComponents @Parameters

Start-DscConfiguration -Path 'C:\DSC2' -Verbose -Wait -Force
#>
