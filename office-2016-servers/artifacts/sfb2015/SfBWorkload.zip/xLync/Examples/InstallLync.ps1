﻿Configuration Deploy_Lync
{
    Param
    (
        [pscredential]$DomainCred,
        [pscredential]$safeAdministratorPW,
        [pscredential]$ShareCred
    )
    Import-DscResource -ModuleName xComputerManagement,xActiveDirectory,xSystemSecurity,xNetworking,xAdcsDeployment,xPendingReboot,xSmbShare,xLync,xCredSSp,xDnsServer,xFileFolder



    Node $AllNodes.Where{$_.Role -eq "First Lync Server"}.Nodename 
    { 

        WindowsFeature RsatAdds
        {
            Name = 'RSAT-ADDS'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        xWaitForADDomain DscForestWait
        { 
                DomainName = $Node.DomainName 
                DomainUserCredential = $domainCred 
                RetryCount = $Node.RetryCount 
                RetryIntervalSec = $Node.RetryIntervalSec 
                DependsOn = "[WindowsFeature]RSATADDS"
        } 

        xComputer JoinDomain
        {
            Name = $node.NodeName
            Credential = $DomainCred
            DomainName = $node.DomainName
            DependsOn = '[xWaitForADDomain]DscForestWait'            
        }

        xPendingReboot RebootAfterDomainJoin
        {
            Name = 'RebootAfterDomainJoin'
            DependsOn = '[xComputer]JoinDomain'
        }

        xIEEsc DisableIEEsc 
        { 
            IsEnabled = $false 
            UserRole = "Administrators" 
        }       

        #Install required Windows features
        Foreach($feature in $node.RequiredFeatures)
        {         
            WindowsFeature $feature
            {
                Ensure = 'Present'
                Name = $feature
                Source = $node.OSSourcePath
            }
        }

        Package VisualC
        {
            Name = 'Visual C++ 2012 x64 Minimum Runtime package'
            Path = "$($node.LyncDeploymentPath)\VCREDIST_X64.EXE"
            Arguments = '/INSTALL /PASSIVE /NORESTART'
            ProductId = 'A2CB1ACB-94A2-32BA-A15E-7D80319F7589'
            
        }

        xCredSSP Server
        {
            Ensure = "Present"
            Role = "Server" 
            DependsOn = '[Package]VisualC'           
        }

        xCredSSP Client
        {
            Ensure = "Present"
            Role = "Client"
            DelegateComputers = $node.NodeFqdn
            DependsOn = '[xCredSSP]Server'
        }

        Package LyncCoreComponents
        {
            Name = 'Microsoft Lync Server 2013, Core Components'
            Path =  "$($node.LyncDeploymentPath)\SETUP\ocscore.msi"
            Arguments = '/PASSIVE /NORESTART'
            ProductId = '8901ADFC-435C-4E37-9045-9E2E7A613285'
            DependsOn = '[xCredSSP]Client'
        }

        xCsAdServerSchema AdServerSchema
        {
            Identity = 'ExtendSchema'
            Credential = $DomainCred
            DependsOn = '[Package]LyncCoreComponents'           
        }

        xCsAdForest AdForest
        {
            Identity = 'AdForestPrep'
            Credential = $DomainCred            
            DependsOn = '[xCsAdServerSchema]AdServerSchema'
        }

        xCsAdDomain AdDomain
        {
            Identity = 'AdDomainPrep'
            Credential = $DomainCred
            DependsOn = '[xCsAdForest]AdForest'
            
        }
        xADGroupMember CSAdministrator
        {
            Identity = "CSAdministrator"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsAdDomain]AdDomain'
        }
        xADGroupMember RTCUniversalServerAdmins
        {
            Identity = "RTCUniversalServerAdmins"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsAdDomain]AdDomain'
        }       
        xCsBootStrapper InstallSqlExpress
        {
            Name = 'BootstrapSqlExpress'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Microsoft Lync Server 2013\Deployment\Bootstrapper.exe"
            SourceDirectory = $node.LyncDeploymentPath
            LogFile = 'C:\BootStrapSqlExpressLog.txt'
            DependsOn = '[xCsAdDomain]AdDomain'
        }

        xCsBootStrapper BootStrapLocalMgmt
        {
            Name = 'BootStrapLocalMgmt'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Microsoft Lync Server 2013\Deployment\Bootstrapper.exe"
            SourceDirectory = $node.LyncDeploymentPath
            LogFile = 'C:\BootStrapLocalMgmt.txt'
            DependsOn = '[xCsBootStrapper]InstallSqlExpress'
        }

        xCsDatabaseInstall CentralManagementDatabase
        {
            CentralManagementDatabase = $True
            Credential = $DomainCred
            SqlServerFqdn = $node.NodeFqdn
            SqlInstanceName = 'RTC'
            Ensure = 'Present' 
            DependsOn = '[xCsBootStrapper]BootStrapLocalMgmt'                  
        }

        xCsConfigurationStoreLocation SetConfigStore
        {
            SqlServerFqdn = $node.NodeFqdn
            SqlInstanceName = 'RTC'
            Credential = $DomainCred
            DependsOn = '[xCsDatabaseInstall]CentralManagementDatabase'

        }

        xItem CreateShareFolder
        {
            Path = $node.LyncSharePath
            ItemType = 'Directory'
            Ensure = 'Present'
            DependsON = '[xCsConfigurationStoreLocation]SetConfigStore'

        }

        xSmbShare FileShare
        {
            Ensure = 'Present'
            Name = 'FileShare'
            Path = $node.LyncSharePath
            FullAccess = 'Everyone'
            DependsOn = '[xItem]FileShare'
        }

        xCsTopology StandardTopology
        {
            Name = "Standard"
            Credential = $DomainCred
            DependsOn = '[xSmbShare]FileShare'
        }

        xCsReplica AssertReplicaEnabled
        {
            Name = "ReplicaEnabled"
            Credential = $DomainCred
            DependsOn = '[xCsTopology]StandardTopology'
        }

        xCsWindowsService Replica
        {
            Name = 'Replica'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsReplica]AssertReplicaEnabled'
        }   
             
        xCsConfigurationImport ImportToLocalstore
        {
            Name = 'ImportToLocalstore'
            LocalStore = $True
            Credential = $DomainCred
            DependsOn = '[xCsWindowsService]Replica'            
        }      
          
        xCsBootStrapper InstallRolesInTopology
        {
            Name = 'InstallRolesInTopology'
            Credential = $DomainCred
            BootStrapPath = "$env:ProgramFiles\Microsoft Lync Server 2013\Deployment\Bootstrapper.exe"
            SourceDirectory = $node.LyncDeploymentPath
            LogFile = 'C:\InstallRolesInTopology.txt'
            DependsOn = '[xCsConfigurationImport]ImportToLocalstore'

        }

        xCsCertificate DefaultInternalExternal
        {
            New = $true
            Type = 'Default','WebServicesInternal','WebServicesExternal'
            ComputerFqdn = $node.NodeFqdn
            CA = $node.CA
            FriendlyName = 'Standard Edition Certificate'
            PrivateKeyExportable = $true
            DomainName = $node.LyncPoolName
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsBootStrapper]InstallRolesInTopology'
        }

        xCsCertificate OAuthCert
        {
            New = $true
            Type = 'OAuthTokenIssuer'
            ComputerFqdn = $node.NodeFqdn
            CA = $node.CA
            FriendlyName = 'OAuth Cert'
            PrivateKeyExportable = $true
            DomainName = $node.LyncPoolName
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[xCsCertificate]DefaultInternalExternal'

        }

        xCsWindowsService StartAll
        {
            Name = 'All'
            Status = 'Running'
            Credential = $DomainCred
            DependsOn = '[xCsCertificate]OAuthCert'
        }

        xDnsServerResourceRecordA lyncdiscoverinternal
        {
            Name = "lyncdiscoverinternal"
            IPv4Address = $node.IPAddress
            ZoneName = $node.DomainName
            ComputerName = $node.DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[WindowsFeature]RSAT-DNS-Server'
        }

        xDnsServerResourceRecordA Sip
        {
            Name = "sip"
            IPv4Address = $node.IPAddress
            ZoneName = $node.DomainName
            ComputerName = $node.DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[WindowsFeature]RSAT-DNS-Server'
        }

        xDnsServerResourceRecordA Meet
        {
            Name = "meet"
            IPv4Address = $node.IPAddress
            ZoneName = $node.DomainName
            ComputerName = $node.DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[WindowsFeature]RSAT-DNS-Server'
        }
        xDnsServerResourceRecordA Admin
        {
            Name = "admin"
            IPv4Address = $node.IPAddress
            ZoneName = $node.DomainName
            ComputerName = $node.DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[WindowsFeature]RSAT-DNS-Server'
        }

        xDnsServerResourceRecordA dialin
        {
            Name = "dialin"
            IPv4Address = $node.IPAddress
            ZoneName = $node.DomainName
            ComputerName = $node.DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
            DependsOn = '[WindowsFeature]RSAT-DNS-Server'
        }

        xCsUser EnableAdmin
        {
            Identity = "fabrikam\administrator"
            RegistrarPool = "lync1.fabrikam.com"
            SipAddress = "sip:administrator@fabrikam.com"
            Ensure = 'Present'
            Credential = $DomainCred
        }

        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
        }
        
    }
    

}

$ConfigData = @{
    AllNodes = @(
        @{
            NodeName="*"
            PSDscAllowPlainTextPassword = $true            
        }

        @{
            NodeName = "Lync1"
            NodeFqdn = "Lync1.fabrikam.com"
            Role = "First Lync Server"
            DomainName = "fabrikam.com"
            IPAddress = "192.168.10.206"
            Gateway = "192.168.10.0"
            DnsServerAddress = "192.168.10.201"
            OSSourcePath = "E:\Sources\sxs"
            LyncDeploymentPath = 'D:\Setup\amd64'
            RequiredFeatures =  "RSAT-DNS-Server","NET-WCF-HTTP-Activation45","AS-NET-Framework","Windows-Identity-Foundation","Web-Webserver","Web-Default-Doc","Web-Static-Content","Web-Http-Errors","Web-ASP-Net","Web-Net-Ext","Web-Isapi-Ext","Web-Isapi-Filter","Web-Http-Logging","Web-Http-Tracing","Web-Log-Libraries","Web-Windows-Auth","Web-Filtering","Web-Stat-Compression","Web-Dyn-Compression","Web-Mgmt-Console","Web-Scripting-Tools","Web-Client-Auth","Desktop-Experience","NET-Framework-Core"
            RetryCount = 10
            RetryIntervalSec = 10
            LyncSharePath = 'C:\FileShare'
            LyncDiscoverFqdn = 'lyncdiscoverinternal.fabrikam.com'
            LyncPoolName = 'lync1.fabrikam.com'
            DnsServer = 'dc1.fabrikam.com'
            CA = 'DC1.fabrikam.com\fabrikam-DC1-CA'
         }
)}  

$Parameters = @{
    DomainCred = (Get-Credential -Message "Enter Domain Cred")
    ConfigurationData = $ConfigData
    OutPutPath = "C:\DSC"
}

Deploy_Lync @Parameters

Set-DscLocalConfigurationManager -Path C:\DSC

Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force
