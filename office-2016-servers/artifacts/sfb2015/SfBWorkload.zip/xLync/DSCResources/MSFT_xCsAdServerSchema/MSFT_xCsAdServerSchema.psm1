function Get-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Collections.Hashtable])]
	param
	(
		[parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$Credential,

		[parameter(Mandatory = $true)]
		[System.String]
		$Identity
	)
    
    $Result = Invoke-Command -ScriptBlock { Get-CsAdServerSchema -ErrorAction SilentlyContinue } -ComputerName . -Credential $Credential -Authentication Credssp

    $val = "SCHEMA_VERSION_STATE_INVALID" 
	if ($result) {
		$val = $Result.value
	}
	$returnValue = @{
		Identity = $Identity
		SchemaValue = $Result.value
	}

	$returnValue
	
}


function Set-TargetResource
{
	[CmdletBinding()]
	param
	(
		[parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$Credential,

		[parameter(Mandatory = $true)]
		[System.String]
		$Identity,

		[System.String]
		$GlobalCatalog,

		[System.String]
		$GlobalSettingsDomainController,

		[System.String]
		$Ldf,

		[System.String]
		$Report,

		[System.Boolean]
		$Force
	)

    Import-Module $PSScriptRoot\..\Misc\Helper.psm1 -Verbose:0

    RemoveParameters -PSBoundParametersIn $PSBoundParameters -ParamsToRemove 'Credential','Identity'
 
	Invoke-Command -ScriptBlock { Install-CsAdServerSchema @using:PSBoundParameters } -ComputerName . -Authentication Credssp -Credential $Credential
	
}


function Test-TargetResource
{
	[CmdletBinding()]
	[OutputType([System.Boolean])]
	param
	(
		[parameter(Mandatory = $true)]
		[System.Management.Automation.PSCredential]
		$Credential,

		[parameter(Mandatory = $true)]
		[System.String]
		$Identity,

		[System.String]
		$GlobalCatalog,

		[System.String]
		$GlobalSettingsDomainController,

		[System.String]
		$Ldf,

		[System.String]
		$Report,

		[System.Boolean]
		$Force
	)

    $Result = Invoke-Command -ScriptBlock { Get-CsAdServerSchema -ErrorAction SilentlyContinue } -ComputerName . -Credential $Credential -Authentication Credssp

    $val = "SCHEMA_VERSION_STATE_INVALID" 
	if ($result) {
		$val = $Result.value
	}
    Write-Verbose "Schema state22: $($val)"	

	If($val -eq 'SCHEMA_VERSION_STATE_CURRENT')
	{
		Write-Verbose "The schema is in a valid state for Skype for business 2015 installation"
		return $true
	}
    return $false
    
}



Export-ModuleMember -Function *-TargetResource

