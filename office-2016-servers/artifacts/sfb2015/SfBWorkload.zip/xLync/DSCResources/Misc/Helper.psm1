﻿
Function Confirm-CMSDatabase
{
    [cmdletbinding()]
    param
    (
        [string]$Instance = "localhost\RTC"
    )
    
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
    $Smo = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $Instance
    $DatabaseList = $Smo.Databases.name

    $result = $DatabaseList -contains "lis" -and $DatabaseList -contains "xds"

    return $result
}



#Takes $PSBoundParameters from another function. If ParamsToRemove is specified, it will remove each param.
#If ParamsToKeep is specified, everything but those params will be removed. If both ParamsToRemove and ParamsToKeep
#are specified, only ParamsToKeep will be used.
function RemoveParameters
{
    param($PSBoundParametersIn, [string[]]$ParamsToKeep, [string[]]$ParamsToRemove)

    if ($ParamsToKeep -ne $null -and $ParamsToKeep.Count -gt 0)
    {
        [string[]]$ParamsToRemove = @()

        $lowerParamsToKeep = StringArrayToLower -Array $ParamsToKeep

        foreach ($key in $PSBoundParametersIn.Keys)
        {
            if (!($lowerParamsToKeep.Contains($key.ToLower())))
            {
                $ParamsToRemove += $key
            }
        }
    }

    if ($ParamsToRemove -ne $null -and $ParamsToRemove.Count -gt 0)
    {
        foreach ($param in $ParamsToRemove)
        {
            $PSBoundParametersIn.Remove($param) | Out-Null
        }
    }
}

#Takes an array of strings and converts all elements to lowercase
function StringArrayToLower
{
    param([string[]]$Array)
    
    if ($Array -ne $null)
    {
        for ($i = 0; $i -lt $Array.Count; $i++)
        {
            if (!([string]::IsNullOrEmpty($Array[$i])))
            {
                $Array[$i] = $Array[$i].ToLower()
            }
        }
    }

    return $Array
}

#this function is used to rename hashtbale keys to the paramter name of the cmdlet they will be passed to so they can be splatted
Function RenameHashTableKey
{
    Param
    (
        $HashTable,
        $Name,
        $NewName
    )
    
        $HashTable.Add($newName,$HashTable[$Name]) | Out-Null

        $HashTable.Remove($Name) | Out-Null
}

#Function used to get a list of SQL instances
Function GetSqlInstance
{
    [CmdletBinding()]
     
    $Instances = @()
    $InstanceList = Get-WmiObject win32_service  | Where {$_.Name -match "mssql*" -and $_.PathName -match "sqlservr.exe"} | Select -ExpandProperty Caption
    Foreach ($Caption in $InstanceList) 
    {
        If ($caption -eq "MSSQLSERVER")
        {
            $Instances += "MSSQLSERVER"
        } 
        Else
        {
            $temp = $caption| %{$_.split(" ")[-1]} | %{$_.trimStart("(")} | %{$_.trimEnd(")")}
            $Instances += $temp
        }
    }

    $Instances
}

#Function returns information about SQL. This is needed for Test-TargetResource in the  xBootStrapper resource
Function GetSqlInfo
{
    [CmdletBinding()]

    $LyncInstance = GetSqlInstance | Where {$_ -match "RTC"} | select -First 1
    
    $Instance = "$env:COMPUTERNAME\$LyncInstance"
    [System.Reflection.Assembly]::LoadWithPartialName('Microsoft.SqlServer.SMO') | out-null
    $Smo = New-Object ('Microsoft.SqlServer.Management.Smo.Server') $Instance

    [pscustomobject]@{
        Edition = $smo.Information.Edition
    }
}

#Function to verify bootstrapper tasks are complete
Function VerifyBootStrapperTask
{
    [CmdletBinding()]

    Param(
        [string]$Task,
        [PScredential]$Credential,
        [string]$AuthenticationType="credssp"
    )

    #Verify SqlExpress is installed
    If($Task -eq "BootstrapSqlExpress")
    {
        $SqlInfo = GetSqlInfo
        If($SqlInfo.Edition -match "Express")
        {
            Write-Verbose "Lync server has been SqlLExpress installed"
            return $true
        }
        Else
        {
            Write-Verbose "SqlExpress not installed"
            Return $false
        }
    }

    $params = @{
        "ComputerName" = "localhost";
        "Credential" = $Credential;
        "Authentication" = $AuthenticationType;
    }

    if ($AuthenticationType -eq "Basic") {
        $params["ComputerName"] = (hostname)
        $params["UseSSL"] = $true
    }
    #Verify local management store is installed by verifying the Sql instance RTCLOCAL and REPLICA and RTCCLSAGT services are present
    If($Task -eq "BootStrapLocalMgmt")
    {
        $LmsServices = Get-Service -Name REPLICA,RTCCLSAGT -ErrorAction SilentlyContinue
        $LmsServicesPresent = $LmsServices.Name -contains "replica" -and $LmsServices.Name -contains "RTCCLSAGT"
        $RtclocalPresnt = GetSqlInstance | where {$_ -eq "RTCLOCAL"}

        If($LmsServicesPresent -and $RtclocalPresnt -ne $null)
        {
            Write-Verbose "The central management store is installed"
            return $true
        }
        Else
        {
            Write-Verbose "Either the RTCLOCAL Sql instance is not present or the REPLICA and RTCCLSAGT services are not present."
            return $false
        }        
    }
    If($Task -eq 'InstallRolesInTopology')
    {
        $params["ErrorVariable"] = "TestCsComputerErr"
        $params["ErrorAction"] = 0
        $params["ScriptBlock"] = { Test-CsComputer }
        Invoke-Command @params

        If($TestCsComputerErr)
        {
            Write-Verbose "$($TestCsComputerErr.Exception)"
            return $false
        }
        Else
        {
            Write-Verbose "Test-CsComputer did not return an error. Tests passed"
            return $true
        }
    }
    if($Task -eq 'BootstrapAdminTools'){
        $folderPath = Join-Path $env:ProgramFiles "Skype for Business Server 2015\Administrative Tools"
        return (Test-Path $folderPath)
    }
}

#function determines what databaes component is being install since the *CsDatabase cmdlets determine this with switch parameters
Function GetComponent
{
    Param
    (
        $PSBoundParametersIn
    )
    If($PSBoundParametersIn.ContainsKey('CentralManagementDatabase'))
    {
        $Component = "CentralManagementDatabase"
    }
    If($PSBoundParametersIn.ContainsKey('ConfiguredDatabases'))
    {
        $Component = "ConfiguredDatabases"
    }
    return $Component
}

#Function to format the data returned from Get-CsConfigurationStoreLocation
Function GetCurrentConfigStore
{
    [CmdletBinding()]

    Param
    (
        [pscredential]$Credential
    )

    $ConfigStorLocation = Invoke-Command -ComputerName . -ScriptBlock {  Get-CsConfigurationStoreLocation } -Credential $Credential -Authentication Credssp
    [pscustomobject]@{
        CurrentSqlFqdn  = ($ConfigStorLocation.BackEndServer -split "\\")[0]
        CurrentInstance = ($ConfigStorLocation.BackEndServer -split "\\")[-1]

        CurrentMirBEFqdn = ($ConfigStorLocation.MirrorBackEndServer -split "\\")[0]
        CurrentMirBEInst = ($ConfigStorLocation.MirrorBackEndServer -split "\\")[-1]
    }
}

#Function to verify CsReplica has been installed and enabled
Function IsReplicaEnabled
{
    [cmdletbinding()]

    Param
    (
        [pscredential]$Credential,
        [string]$AuthenticationType="credssp"
    )

    $params = @{
        "ComputerName" = "localhost";
        "ScriptBlock" = { Test-CsReplica };
        "Credential" = $Credential;
        "Authentication" = $AuthenticationType;
        "WarningVariable" = "TestReplicaWarn";
        "ErrorVariable" = "TestReplicaErr";
        "ErrorAction" = 0;
    }

    if ($AuthenticationType -eq "Basic") {
        $params["ComputerName"] = (hostname)
        $params["UseSSL"] = $true
    }

    Invoke-Command @params
    
    If(($TestReplicaErr.Count -eq 0) -and ($TestReplicaWarn.Count -eq 0))
    {
        return $true
    }

    Foreach($err in $TestReplicaErr)
    {
        Write-Warning $err.Exception.Message
    }

    Foreach($Warning in $TestReplicaWarn)
    {
        Write-Warning $Warning
    }
    return $false
}

#Function used to get a list CsConfiguration signatures from RTCLocal to verify if configuration from RTC has been imported to RTCLocal
Function GetCsConfigurationSignature
{
    [cmdletbinding()]
    Param
    (
        [string]$ServerInstance
    )
        
    $Database = "xds"
    $Query = "select * from dbo.Item"
    $ConnectionTimeout = "60"
    $conn=new-object System.Data.SqlClient.SQLConnection      
    $ConnectionString = "Server={0};Database={1};Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout
    #$ConnectionString = "Server={0};Database={1},1433;Integrated Security=True;Connect Timeout={2}" -f $ServerInstance,$Database,$ConnectionTimeout
    Write-Verbose "Connection string: $ConnectionString"
    $conn.ConnectionString=$ConnectionString   
    $conn.Open() 
    $cmd=new-object system.Data.SqlClient.SqlCommand($Query,$conn) 
    $cmd.CommandTimeout=$QueryTimeout 
    $ds=New-Object system.Data.DataSet 
    $da=New-Object system.Data.SqlClient.SqlDataAdapter($cmd) 
    [void]$da.fill($ds) 
    $conn.Close() 
     $ds.Tables[0] | select Signature
}

#Function used to expand a zip file
Function Expand-ZIPFile
{
    [cmdletbinding()]
    Param
    (
        [string]$File, 
        [string]$Destination
    )

     $shell = new-object -com shell.application
     $zip = $shell.NameSpace($file)

     foreach($item in $zip.items())
     {
        $shell.Namespace($destination).copyhere($item)
     }
 }

#Function used get results from file produced by Export-CsConfiguration
Function GetSigFromExportLog
{
    [cmdletbinding()]
    Param
    (
        [string]$File
    )
    $TempRoot = [system.IO.Path]::GetTempFileName() -replace ".tmp"
    #Extract the xml file to compare
    $TempChild = (Get-Item $file).BaseName
    $TempDir = Join-Path $TempRoot $TempChild
    New-Item -Path $TempDir -ItemType Directory -Force | Out-Null

    Expand-ZIPFile -File $File -Destination $TempDir

    [xml]$SourceXml = Get-Content "$TempDir\DocItemSet.xml" -ErrorAction stop
     
    return $SourceXml.DocItemSet.DocItem | select Signature

}
#Function to asscert/verify all certs are present. Returns $true or $false
Function IsCsCertificatePresent
{
    [CmdletBinding()]
    Param
    (
        [String[]]$Type,
        [PSCredential]$Credential
    )

    $CsCertificate = Invoke-Command -ComputerName . -ScriptBlock { Get-CsCertificate -Type $using:type } -Credential $Credential -Authentication Credssp

    If($CsCertificate)
    {    
        $CompareResult = Compare-Object -ReferenceObject $CsCertificate.use -DifferenceObject $Type
        If($CompareResult)
        {
            Write-Verbose "CsCertificate $($CompareResult.InputObject) Absent"
            return $false
        }
        Else
        {
            Write-Verbose "CsCertificate $type Present"
            return $true
        }    
    }
    Else
    {
        Write-Verbose "CsCertificate $Type not found"
        return $false
    }
}

#Function to get a list of Absent Certificates
Function GetCsCertificateState
{
    [CmdletBinding()]
    Param
    (
        [String[]]$Type,
        [PSCredential]$Credential,
        [Parameter(Mandatory=$false)]
        [string]$AuthenticationType="credssp"
    )
    Write-Host "Running GetCsCertificateState with AuthenticationType: $AuthenticationType" 
    $CertResults = @()

    $params = @{
        "Credential" = $Credential;
        "Authentication" = $AuthenticationType;
        "UseSSL" = $false;
    }
    if ($AuthenticationType -eq "Basic") {
        $params["ComputerName"] = (hostname)
        $params["UseSSL"] = $true
    } else {
        $params["ComputerName"] = "localhost"
    }

    $params["ScriptBlock"] = { Get-CsCertificate -Type $using:type }
    
    Write-Host ("Running: Invoke-Command with UseSSL: {0} Authentication: {1}" -f ($params["UseSSL"], $params["Authentication"]))
    $CsCertificate = Invoke-Command @params

    If($CsCertificate)
    {    
        $CompareResult = Compare-Object -ReferenceObject $CsCertificate.use -DifferenceObject $Type

        Foreach($T in $Type)
        {
            If($CsCertificate.Use -contains $T )
            {
                Write-Verbose "$T certificate present"
                $CertResults += [pscustomobject]@{
                    Type = $T
                    Ensure = 'Present'
                }
            }
            Else
            {
                Write-Verbose "$T certificate Absent"
                 $CertResults += [pscustomobject]@{
                    Type = $T
                    Ensure = 'Absent'
                }
            }
        }    
    }
    Else
    {
        Write-Verbose "$type Absent"
        Foreach($T in $Type)
        {
            $CertResults += [pscustomobject]@{
                Type = $T
                Ensure = 'Absent'
            }
        }
    }

    return $CertResults
}

Function Get-CertificationAuthority
{
    $domain = Get-ADDomain
    $CA = "{0}\{1}-{2}-CA" -f $domain.InfrastructureMaster, $domain.Name, $domain.InfrastructureMaster.Replace($domain.DNSRoot,"").Trim(".")
    return $CA
}