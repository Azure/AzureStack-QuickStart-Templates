Param
(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$DomainName,
    [Parameter(Mandatory=$true)]
    [string]$PrimarySqlServerFQDN,
    [Parameter(Mandatory=$true)]
    [string]$SecondarySqlServerFQDN,
    [Parameter(Mandatory=$true)]
    [string]$SqlAOListenerFQDN,
    [Parameter(Mandatory=$true)]
    [string]$SqlAG,
    [Parameter(Mandatory=$true)]
    [string]$LBIPAddress,
    [Parameter(Mandatory=$true)]
    [string]$DNSserver,
    [Parameter(Mandatory=$true)]
    [array]$Servers,
    [Parameter(Mandatory=$true)]
    [string]$ShareFqdn,
    [Parameter(Mandatory=$true)]
    [string]$ShareName
)


Configuration Deploy_SkypeForBusinessTopology
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$PrimarySqlServerFQDN,
        [Parameter(Mandatory=$true)]
        [string]$SecondarySqlServerFQDN,
        [Parameter(Mandatory=$true)]
        [string]$SqlAOListenerFQDN,
        [Parameter(Mandatory=$true)]
        [string]$SqlAG,
        [Parameter(Mandatory=$true)]
        [string]$LBIPAddress,
        [Parameter(Mandatory=$true)]
        [string]$DNSserver,
        [Parameter(Mandatory=$true)]
        [array]$FrontEndServersFQDN,
        [Parameter(Mandatory=$true)]
        [string]$ShareFqdn,
        [Parameter(Mandatory=$true)]
        [string]$ShareName
    )
    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, xCsSimpleUrl, `
        xFileFolder,PSDesiredStateConfiguration

    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node localhost {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        xDnsServerResourceRecordA lyncdiscoverinternal
        {
            Name = "lyncdiscoverinternal"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DNSserver
            Credential = $DomainCred
            Ensure = 'Present'
        }

        xDnsServerResourceRecordA webint
        {
            Name = "webint"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DNSserver
            Credential = $DomainCred
            Ensure = 'Present'
        }
        xDnsServerResourceRecordA scheduler
        {
            Name = "scheduler"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
        }

        xDnsServerResourceRecordA Sip
        {
            Name = "sip"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
        }

        xDnsServerResourceRecordA Meet
        {
            Name = "meet"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
        }
        xDnsServerResourceRecordA Admin
        {
            Name = "admin"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
        }

        xDnsServerResourceRecordA dialin
        {
            Name = "dialin"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
        }

        xDnsServerResourceRecordA pool
        {
            Name = "pool"
            IPv4Address = $LBIPAddress
            ZoneName = $DomainName
            ComputerName = $DnsServer
            Credential = $DomainCred
            Ensure = 'Present'
        }

        xCsAdServerSchema AdServerSchema
        {
            Identity = 'ExtendSchema'
            Credential = $DomainCred

        }

        xCsAdForest AdForest
        {
            Identity = 'AdForestPrep'
            Credential = $DomainCred            
            DependsOn = '[xCsAdServerSchema]AdServerSchema'
        }

        xCsAdDomain AdDomain
        {
            Identity = 'AdDomainPrep'
            Credential = $DomainCred
            DependsOn = '[xCsAdForest]AdForest'   
        }

        xADGroupMember CSAdministrator
        {
            Identity = "CSAdministrator"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsAdDomain]AdDomain'
        }

        xADGroupMember RTCUniversalServerAdmins
        {
            Identity = "RTCUniversalServerAdmins"
            Members = "Domain Admins"
            Ensure = 'Present'
            Credential = $DomainCred
            DependsOn = '[xCsAdDomain]AdDomain'
        }

        xSetCsManagementConnection SetmanagementConnection {
            SqlServerFQDN = $PrimarySqlServerFQDN
            StoreProvider = "Sql"
            Credentials = $DomainCred
            DependsOn = "[xADGroupMember]RTCUniversalServerAdmins"
        }

        xCsDatabaseInstall CentralManagementDatabase
        {
            CentralManagementDatabase = $True
            DatabaseTypes = "User","Application"
            Credential = $DomainCred
            SqlServerFqdn = $PrimarySqlServerFQDN
            Ensure = 'Present' 
            DependsOn = '[xSetCsManagementConnection]SetmanagementConnection'       
        }

        xSqlNewAGDatabase AddDatabasesToAG {
            DatabaseNames = "lis","xds","rgsconfig","rgsdyn","cpsdyn","rtcxds","rtcshared","rtcab"
            SqlAdministratorCredential = $DomainCred
            PrimaryReplica = $PrimarySqlServerFQDN
            SecondaryReplica = $SecondarySqlServerFQDN
            SqlAlwaysOnAvailabilityGroupName = $SqlAG
            DependsOn = '[xCsDatabaseInstall]CentralManagementDatabase'       
        }

        xSetCsManagementConnection SetmanagementConnectionPost {
            SqlServerFQDN = $SqlAOListenerFQDN
            StoreProvider = "Sql"
            Credentials = $DomainCred
            DependsOn = "[xSqlNewAGDatabase]AddDatabasesToAG"
        }

        xCsTopology EnterpriseTopology
        {
            Name = "Enterprise"
            Credential = $DomainCred
            FrontEndServersFQDN = $FrontEndServersFQDN
            ShareFqdn = $ShareFqdn
            ShareName = $ShareName
            SqlServerFQDN = $PrimarySqlServerFQDN
            SqlAOGListenerFqdn = $SqlAOListenerFQDN
            Domain = $DomainName
            # InternalPoolOverride = ("webint.{0}" -f $DomainName)
            PoolFqdn = ("pool.{0}" -f $DomainName)
            DependsOn = '[xSetCsManagementConnection]SetmanagementConnectionPost'
        }

        xCsSimpleUrl SimpleURLEntries {
            Domain = $DomainName
            Credentials = $DomainCred
            DependsOn = '[xCsTopology]EnterpriseTopology'
        }

    }
}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="localhost"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

# foreach ($srv in $FrontEndServersFQDN){
#     $ConfigData["AllNodes"] += @{NodeName = $srv}
# }

$Parameters = @{
    ConfigurationData = $ConfigData
    OutPutPath = "C:\DSC"
    AdminCreds = $AdminCreds
    PrimarySqlServerFQDN = $PrimarySqlServerFQDN
    SecondarySqlServerFQDN = $SecondarySqlServerFQDN
    SqlAOListenerFQDN = $SqlAOListenerFQDN
    DNSserver = $DNSserver
    DomainName = $DomainName
    SqlAG = $SqlAG
    LBIPAddress = $LBIPAddress
    ShareName = $ShareName
    ShareFqdn = $ShareFqdn
    FrontEndServersFQDN = $Servers
}
cp -Recurse -Force "$env:ProgramFiles\Common Files\Skype for Business Server 2015\Modules\*" $env:ProgramFiles\WindowsPowerShell\Modules\
$env:PSModulePath += ";C:\Program Files\Common Files\Skype for Business Server 2015\Modules" 

Deploy_SkypeForBusinessTopology @Parameters

Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force
