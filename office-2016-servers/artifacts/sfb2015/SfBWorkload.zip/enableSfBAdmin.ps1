Param
(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$DomainName
)

Configuration Start_SkypeForBusinessFrontEndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration

    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)
    $PoolFqdn = ("pool.{0}" -f $DomainName)

    Node localhost {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        xCsUser EnableAdmin
        {
            Identity = ("{0}\{1}" -f @($DomainName, $AdminCreds.UserName))
            RegistrarPool = $PoolFqdn
            SipAddress = ("sip:{0}@{1}" -f @($AdminCreds.UserName, $DomainName))
            Ensure = 'Present'
            Credential = $DomainCred
        }
    }
}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="localhost"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

$Parameters = @{
    ConfigurationData = $ConfigData
    OutPutPath = "C:\DSC"
    AdminCreds = $AdminCreds
    DomainName = $DomainName
}

$env:PSModulePath += ";C:\Program Files\Common Files\Skype for Business Server 2015\Modules" 

Start_SkypeForBusinessFrontEndComponents @Parameters

Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force
