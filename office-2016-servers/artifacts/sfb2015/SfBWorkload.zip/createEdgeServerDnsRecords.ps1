Param
(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$DomainName,
    [Parameter(Mandatory=$true)]
    [string]$DNSserver,
    [Parameter(Mandatory=$true)]
    [array]$EdgeServersInfo
)

Configuration Create_EdgeServerDNSRecords
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$DomainName,
        [Parameter(Mandatory=$true)]
        [string]$DNSserver
    )
    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, xCsSimpleUrl, `
        xFileFolder,PSDesiredStateConfiguration

    $DomainCred = [System.Management.Automation.PSCredential]$DomainFQDNCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($AdminCreds.UserName)", $AdminCreds.Password)

    Node localhost {

        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        WindowsFeature RsatAdds
        {
            Name = 'RSAT-ADDS'
            IncludeAllSubFeature = $true
            Ensure = 'Present'
        }

        foreach ($edge in $EdgeServersInfo) {
            xDnsServerResourceRecordA $edge.HostName
            {
                Name = $edge["HostName"]
                IPv4Address = $edge["Internal"]
                ZoneName = $DomainName
                ComputerName = $DnsServer
                Credential = $DomainCred
                Ensure = 'Present'
                DependsOn = '[WindowsFeature]RsatAdds'
            }
        }

    }

}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="localhost"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

$OutPutPath = ("{0}\DSC" -f $env:SystemDrive)
Write-Host $ConfigData["AllNodes"].NodeName
$Parameters = @{
    ConfigurationData = $ConfigData
    AdminCreds = $AdminCreds
    DomainName = $DomainName
    OutPutPath = $OutPutPath
    DNSserver = $DNSserver
}


Create_EdgeServerDNSRecords @Parameters

Start-DscConfiguration -Path $OutPutPath -Verbose -Wait -Force