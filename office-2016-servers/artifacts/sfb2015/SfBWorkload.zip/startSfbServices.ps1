Param
(
    [Parameter(Mandatory=$true)]
    [System.Management.Automation.PSCredential]$AdminCreds,
    [Parameter(Mandatory=$true)]
    [string]$AuthenticationType="Credssp"
)

Configuration Start_SkypeForBusinessFrontEndComponents
{
    Param
    (
        [Parameter(Mandatory=$true)]
        [System.Management.Automation.PSCredential]$AdminCreds,
        [Parameter(Mandatory=$true)]
        [string]$AuthenticationType="Credssp"
    )

    Import-DscResource -ModuleName `
        xSetCsManagementConnection,xSql,xWaitForCredSSP, `
        xAzCopyTools,xModulesInstaller,xDownloadFile, `
        xComputerManagement,xActiveDirectory,xSystemSecurity, `
        xNetworking,xAdcsDeployment,xPendingReboot, `
        xSmbShare,xLync,xCredSSp,xDnsServer, `
        xFileFolder,PSDesiredStateConfiguration


    Node localhost {
        LocalConfigurationManager 
        {
            RebootNodeIfNeeded = $true
            # ConfigurationMode = 'ApplyOnly'
        }

        xCsWindowsService StartAll
        {
            Name = 'All'
            Status = 'Running'
            Credential = $AdminCreds
            AuthenticationType = $AuthenticationType
        }

    }
}


$ConfigData = @{
     AllNodes = @(
        @{
            NodeName="localhost"
            PSDscAllowPlainTextPassword = $true
            PSDscAllowDomainUser = $true
        }
)}

$Parameters = @{
    ConfigurationData = $ConfigData
    OutPutPath = "C:\DSC"
    AdminCreds = $AdminCreds
    AuthenticationType = $AuthenticationType
}

$env:PSModulePath += ";C:\Program Files\Common Files\Skype for Business Server 2015\Modules" 

Start_SkypeForBusinessFrontEndComponents @Parameters

Start-DscConfiguration -Path 'C:\DSC' -Verbose -Wait -Force
