Configuration InstallFirstADFS 
{ 
   param
    (
        [Parameter(Mandatory)]
        [string]$DomainName,
        
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Adfscreds,

        [Parameter(Mandatory)]
        [string]$SharePath,

        [Parameter(Mandatory)]
        [string]$CAName,

        [Parameter(Mandatory)]
        [string]$CAFQDN,
        
        [Parameter(Mandatory)]
        [string]$SqlAOListener,

        [Parameter(Mandatory)]
        [string]$DnsName,

        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )


    Import-DscResource -ModuleName "xActiveDirectory"
    Import-DscResource -ModuleName "xDSCDomainjoin"
    Import-DscResource -ModuleName "xPendingReboot"
    Import-DscResource -ModuleName "CertificateDsc"
    Import-DscResource -ModuleName "xADFSInstaller"
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$AdfsServiceCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Adfscreds.UserName)", $Adfscreds.Password)  

    Node localhost
    {
        LocalConfigurationManager 
        {
		    RebootNodeIfNeeded = $True
            ConfigurationID = ([guid]::NewGuid()).Guid
        }
         
        xDSCDomainjoin JoinDomain
        {
         Domain = $DomainName
         Credential = $DomainCreds
        }
        
        xPendingReboot AfterDomainJoin
        {
			Name = 'AfterDomainJoin'
			SkipCcmClientSDK=$True
			DependsOn = "[xDSCDomainjoin]JoinDomain"
        }
        
        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[xPendingReboot]AfterDomainJoin"
        }

        WindowsFeature installADFS  
        {
            Ensure = "Present"
            Name   = "ADFS-Federation"
            DependsOn = "[WindowsFeature]ADPS"
        }

        xADUser CreateServiceAccount
        {
            DomainAdministratorCredential = $DomainCreds
            DomainName                    = $DomainName
            UserName                      = $Adfscreds.UserName
            Password                      = $Adfscreds
            Ensure                        = "Present"
            PsDscRunAsCredential          = $DomainCreds
            DependsOn = "[WindowsFeature]installADFS"
        }

        ADFSInstaller InstallADFS
        {
            DependsOn           = "[xADUser]CreateServiceAccount"
            CertSubject = $DnsName
            AdfsSvcCreds = $AdfsServiceCreds
            Credential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            SharePath = $SharePath
            CAName = $CAName
            CAFQDN = $CAFQDN
            SqlAOListener = $SqlAOListener
            EndpointName = $DnsName
        }

    }
}

