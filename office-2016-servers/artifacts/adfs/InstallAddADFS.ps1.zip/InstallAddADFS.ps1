Configuration InstallAddADFS 
{ 
   param
    (
        [Parameter(Mandatory)]
        [string]$DomainName,
        
        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Admincreds,

        [Parameter(Mandatory)]
        [System.Management.Automation.PSCredential]$Adfscreds,

        [Parameter(Mandatory)]
        [string]$SharePath,
        
        [Parameter(Mandatory)]
        [string]$SqlAOListener,

        [Parameter(Mandatory)]
        [string]$DnsName,
        
        [Int]$RetryCount=20,
        [Int]$RetryIntervalSec=30
    )


    Import-DscResource -ModuleName xActiveDirectory;
    Import-DscResource -ModuleName xDSCDomainjoin;
    Import-DscResource -ModuleName xPendingReboot;
    Import-DscResource -ModuleName CertificateDsc;
    Import-DscResource -ModuleName xADFSInstaller;
    
    [System.Management.Automation.PSCredential ]$DomainCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Admincreds.UserName)", $Admincreds.Password)
    [System.Management.Automation.PSCredential ]$AdfsServiceCreds = New-Object System.Management.Automation.PSCredential ("${DomainName}\$($Adfscreds.UserName)", $Adfscreds.Password)  
    $savePath = join-path $SharePath "SSLCert.pfx"
    $firstDAFS = $env:COMPUTERNAME.Replace("1","0")

    Node localhost
    {
        LocalConfigurationManager 
        {
		    RebootNodeIfNeeded = $True
            ConfigurationID = ([guid]::NewGuid()).Guid
        }
         
        xDSCDomainjoin JoinDomain
        {
         Domain = $DomainName
         Credential = $DomainCreds
        }
        
        xPendingReboot AfterDomainJoin
        {
			Name = 'AfterDomainJoin'
			SkipCcmClientSDK=$True
			DependsOn = "[xDSCDomainjoin]JoinDomain"
		}

        WindowsFeature ADPS
        {
            Name = "RSAT-AD-PowerShell"
            Ensure = "Present"
            PsDscRunAsCredential = $Admincreds
            DependsOn = "[xPendingReboot]AfterDomainJoin"
        }

        WindowsFeature installADFS  
        {
            Ensure = "Present"
            Name   = "ADFS-Federation"
            DependsOn = "[WindowsFeature]ADPS"
        }

        ADFSNode AddADFS
        {
            DependsOn = "[WindowsFeature]installADFS"
            CertSubject = $DnsName
            AdfsSvcCreds = $AdfsServiceCreds
            Credential = $DomainCreds
            PsDscRunAsCredential = $DomainCreds
            SharePath = $SharePath
            SqlAOListener = $SqlAOListener
        }


    }
}

