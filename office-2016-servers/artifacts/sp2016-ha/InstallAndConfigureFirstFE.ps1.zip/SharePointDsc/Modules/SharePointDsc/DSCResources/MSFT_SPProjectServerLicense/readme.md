# Description

**Type:** Distributed

This resource is used to enable a Project Server license in to a SharePoint
2016 farm.
