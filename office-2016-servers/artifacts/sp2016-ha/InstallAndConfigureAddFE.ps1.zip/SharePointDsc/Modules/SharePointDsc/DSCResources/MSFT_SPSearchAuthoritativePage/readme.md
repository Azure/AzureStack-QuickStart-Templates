# Description

**Type:** Distributed

This resource is responsible for managing the search authoritative pages in the
search service application. You can create new pages, change existing pages and
remove existing pages.

The default value for the Ensure parameter is Present. When you omit this
parameter the crawl rule is created.
