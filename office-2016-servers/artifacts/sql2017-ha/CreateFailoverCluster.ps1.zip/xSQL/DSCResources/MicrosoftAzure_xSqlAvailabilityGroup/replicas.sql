--- YOU MUST EXECUTE THE FOLLOWING SCRIPT IN SQLCMD MODE.
:Connect primaryReplica

use [master]

GO

GRANT CONNECT ON ENDPOINT::[hadrName] TO [sqlServiceAccount]

GO

:Connect secondaryReplica

IF (SELECT state FROM sys.endpoints WHERE name = N'hadrName') <> 0
BEGIN
	ALTER ENDPOINT [hadrName] STATE = STARTED
END


GO

use [master]

GO

GRANT CONNECT ON ENDPOINT::[hadrName] TO [sqlServiceAccount]

GO

:Connect secondaryReplica

IF EXISTS(SELECT * FROM sys.server_event_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER WITH (STARTUP_STATE=ON);
END
IF NOT EXISTS(SELECT * FROM sys.dm_xe_sessions WHERE name='AlwaysOn_health')
BEGIN
  ALTER EVENT SESSION [AlwaysOn_health] ON SERVER STATE=START;
END

GO

:Connect primaryReplica

USE [master]

GO

ALTER AVAILABILITY GROUP [aoName]
ADD REPLICA ON N'secondaryReplica' WITH (ENDPOINT_URL = N'TCP://secondaryReplica.domainName:aoPort', FAILOVER_MODE = MANUAL, AVAILABILITY_MODE = SYNCHRONOUS_COMMIT, BACKUP_PRIORITY = 50, SECONDARY_ROLE(ALLOW_CONNECTIONS = NO));

GO

:Connect secondaryReplica

ALTER AVAILABILITY GROUP [aoName] JOIN;

GO


GO

