# Purpose: Configure the standalone external file server.

Param
(
    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $fileServerAdminUserName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $fileServerAdminPassword,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $fileShareOwnerUserName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $fileShareOwnerPassword,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $fileShareUserUserName,

    [Parameter(Mandatory=$true)]
    [ValidateNotNullOrEmpty()]
    [string] $fileShareUserPassword
);

# Load common functions
. ".\Common\common.ps1"

try
{
    Log "Configure File Server role"

    Set-ComputerToHighPerformanceMode

    Log "Configue role administrator account. UserName: $fileServerAdminUserName"
    Configure-Administrator $fileServerAdminUserName $fileServerAdminPassword

    Log "Configue file share owner account. UserName: $fileShareOwnerUserName"
    Configure-User $fileShareOwnerUserName $fileShareOwnerPassword

    Log "Configue file share user account. UserName: $fileShareUserUserName"
    Configure-User $fileShareUserUserName $fileShareUserPassword

    Log "Creating content share...";
    $websitesFolder = "$($env:SystemDrive)\Websites"
    New-Item -Path $websitesFolder -ItemType directory

    # Create share with share permissions set to "Everyone -> Full Control"
    New-SmbShare �Name websites �Path $websitesFolder -CachingMode None -FullAccess Everyone

    # Set NTFS folder permissions
    CMD.EXE /C "icacls $websitesFolder /reset"
    CMD.EXE /C "icacls $websitesFolder /grant Administrators:(OI)(CI)(F)"
    CMD.EXE /C "icacls $websitesFolder /grant $($fileShareOwnerUserName):(OI)(CI)(M)"
    CMD.EXE /C "icacls $websitesFolder /inheritance:r"
    CMD.EXE /C "icacls $websitesFolder /grant $($fileShareUserUserName):(CI)(S,X,RA)"
    CMD.EXE /C "icacls $websitesFolder /grant *S-1-1-0:(OI)(CI)(IO)(RA,REA,RD)"

    Log "File server role configuration completed."
}
catch
{
    Log "Error: $_"

    throw;
}