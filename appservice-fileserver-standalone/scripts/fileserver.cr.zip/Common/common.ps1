# Copyright (c) Microsoft Corporation. All rights reserved.

function Log($out)
{
    $out = [System.DateTime]::Now.ToString("yyyy.MM.dd hh:mm:ss") + " ---- " + $out;
    Write-Output $out;
}

function Configure-UAC()
{
    Log "Configure UAC remote administration policy."
    Set-ItemProperty -Path HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System -Name LocalAccountTokenFilterPolicy -Value 1 -Force
}

function Set-ComputerToHighPerformanceMode()
{
    Log "Configure Power Options to High performance mode."

    powercfg /SETACTIVE 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c

    if ($lastexitcode -eq 0)
    {
        Log "Power Options has changed successfully."
    }
    else
    {
        Log "Failed to change the power options. This is not a critical failure."
    }
}

function Wait-DnsPropagation($hostNameOrAddress)
{
    while(!$([System.Net.Dns]::GetHostAddresses($hostNameOrAddress)))
    {
        Log "Waiting for DNS. Address: $hostNameOrAddress";
        [System.Threading.Thread]::Sleep(20000);
    }
}

function Load-HostingFramework()
{
    $mwhc = Get-Item ".\bin\Microsoft.Web.Hosting.Common.dll"
    [void] [System.Reflection.Assembly]::LoadFrom($mwhc.FullName)
    Log "Microsoft.Web.Hosting.Common assembly was successfully loaded from: $mwhc"

    $mwh  = Get-Item ".\bin\Microsoft.Web.Hosting.dll"
    [void] [System.Reflection.Assembly]::LoadFrom($mwh.FullName)
    Log "Microsoft.Web.Hosting assembly was successfully loaded from: $mwh"
}

function Test-DatabaseConnectivity($cnstr)
{
    try
    {
        $cn = new-object System.Data.SqlClient.SqlConnection($cnstr);
        $cn.Open();

        return $true;
    }
    catch
    {
        Log "Database server not reachable. Error: $_";

        return $false;
    }
    finally
    {
        if($siteManager -ne $null)
        {
            $siteManager.Dispose();
        }
    }
}

function Test-HostingDatabaseConnectivity($cnstr)
{
    try
    {
        $siteManager = New-Object Microsoft.Web.Hosting.SiteManager $cnstr
        $siteManager.TestConnection()

        return $siteManager.IsWFFReady();
    }
    catch
    {
        Log "Hosting database not ready. Error: $_"

        return $false;
    }
    finally
    {
        if($siteManager -ne $null)
        {
            $siteManager.Dispose()
        }
    }
}

function Wait-DatabaseConnectivity($cnstr)
{
    $ready = Test-DatabaseConnectivity $cnstr
    if($ready -ne $true)
    {
        $retryCount = 1
        while ($retryCount -le 10)
        {
            Log "Waiting for database server to be reachable..."
            Start-Sleep -Seconds 60

            $ready = Test-DatabaseConnectivity $cnstr
            if ($ready -eq $true)
            {
                Log "Database server is up!"

                break;
            }

            $retryCount++
        }

        $ready = Test-DatabaseConnectivity $cnstr
        if($ready -ne $true)
        {
            throw New-Object System.TimeoutException "Wait for database connectivity has timed out"
        }
    }
}

function Wait-HostingDatabaseConnectivity($cnstr)
{
    $ready = Test-HostingDatabaseConnectivity $cnstr
    if($ready -ne $true)
    {
        $retryCount = 1
        while ($retryCount -le 120)
        {
            Log "Waiting for Hosting database to be ready..."
            Start-Sleep -Seconds 60

            $ready = Test-HostingDatabaseConnectivity $cnstr
            if ($ready -eq $true)
            {
                Log "Hosting Database is ready!"

                break;
            }

            $retryCount++
        }

        $ready = Test-HostingDatabaseConnectivity $cnstr
        if($ready -ne $true)
        {
            throw New-Object System.TimeoutException "Wait for hosting database connectivity has timed out"
        }
    }
}

function Configure-User($user, $password)
{
    $isDomain = $false

    # Identify if user is a domain user account
    $values = $user.Split('\');

    if ($values.Length -eq 1)
    {
        $domain = $env:COMPUTERNAME
        $username = $values[0]
    }
    elseif ($values.Length -eq 2)
    {
        if ([String]::Equals($values[0], ".") -Or
            [String]::Equals($values[0], [Environment]::MachineName, [StringComparison]::OrdinalIgnoreCase))
        {
            $isDomain = $false
            $domain = $env:COMPUTERNAME
            $username = $values[1]
        }
        else
        {
            $isDomain = $true
            $domain = $values[0]
            $username = $values[1]
        }
    }
    else
    {
        throw New-Object ArgumentException "Invalid user name" "roleadminusr"
    }

    # Create user if specified user is not a domain account
    if ($isDomain -eq $false)
    {
        try
        {
            $computer = [ADSI]"WinNT://$env:COMPUTERNAME"
            $user = $computer.Create("User", $username)
            $user.setpassword($password)
            $user.Put("UserFlags", 0x10000) # ADS_UF_DONT_EXPIRE_PASSWD
            $user.SetInfo()
        }
        catch [System.Runtime.InteropServices.COMException]
        {
            # User already exists
            if ($_.Exception.ErrorCode -eq -2147022672)
            {
                Log "User $domain\$username already exits."
                Log "Updating password for User $domain\$username."
                $user = [ADSI]("WinNT://$env:COMPUTERNAME/$username,user")
                $user.setpassword($password)
                $user.Put("UserFlags", 0x10000) # ADS_UF_DONT_EXPIRE_PASSWD
                $user.SetInfo()
            }
            else
            {
                Log "Error creating user $domain\$username."

                throw
            }
        }
    }
}

function Configure-Administrator($roleadminusr, $roleadminpwd)
{
    $isDomain = $false

    # Identify if user is a domain user account
    $values = $roleadminusr.Split('\');

    if ($values.Length -eq 1)
    {
        $domain = $env:COMPUTERNAME
        $username = $values[0]
    }
    elseif ($values.Length -eq 2)
    {
        if ([String]::Equals($values[0], ".") -Or
            [String]::Equals($values[0], [Environment]::MachineName, [StringComparison]::OrdinalIgnoreCase))
        {
            $isDomain = $false
            $domain = $env:COMPUTERNAME
            $username = $values[1]
        }
        else
        {
            $isDomain = $true
            $domain = $values[0]
            $username = $values[1]
        }
    }
    else
    {
        throw New-Object ArgumentException "Invalid user name" "roleadminusr"
    }

    # Create user if specified user is not a domain account
    if ($isDomain -eq $false)
    {
        try
        {
            $computer = [ADSI]"WinNT://$env:COMPUTERNAME"
            $user = $computer.Create("User", $username)
            $user.setpassword($roleadminpwd)
            $user.Put("UserFlags", 0x10000) # ADS_UF_DONT_EXPIRE_PASSWD
            $user.SetInfo()
        }
        catch [System.Runtime.InteropServices.COMException]
        {
            # User already exists
            if ($_.Exception.ErrorCode -eq -2147022672)
            {
                Log "User $domain\$username already exits."
                Log "Updating password for User $domain\$username."
                $user = [ADSI]("WinNT://$env:COMPUTERNAME/$username,user")
                $user.setpassword($roleadminpwd)
                $user.Put("UserFlags", 0x10000) # ADS_UF_DONT_EXPIRE_PASSWD
                $user.SetInfo()
            }
            else
            {
                Log "Error creating user $domain\$username."

                throw
            }
        }
    }

    # Add user to local administrators group

    # first translate the "Administrators" name to the name based on locale (make well known SID -> Name translation)
    $administratorsSID = New-Object System.Security.Principal.SecurityIdentifier("S-1-5-32-544")
    $administratorsGroupName = $administratorsSID.Translate([System.Security.Principal.NTAccount]).Value

    # retrieve the short name eg in german translate VORDEFINIERT\Administratoren ->Administratoren
    # the translation should always return fully qualified name equivalent to BUILTIN\Administrators
    $localizedAdministratorsGroupName=$administratorsGroupName.Split("\\")[1]
    $adminGroup = [ADSI]("WinNT://$env:COMPUTERNAME/$localizedAdministratorsGroupName,group")

    try
    {
        if ($isDomain -eq $true)
        {
            $adminGroup.add("WinNT://$domain/$username,user")
        }
        else
        {
            $adminGroup.add("WinNT://$env:COMPUTERNAME/$username,user")
        }
    }
    catch [System.Runtime.InteropServices.COMException]
    {
        if ($_.Exception.ErrorCode -eq -2147023518) # ERROR_MEMBER_IN_ALIAS 1378 (0x562)
        {
            Log "User $domain\$username is already member of Administrators group."
        }
        else
        {
            Log "Error adding user $domain\$username to Administrators group."

            throw
        }
    }
}

function Get-ComputerIPv4Address()
{
    $computerName = Get-WMIObject win32_NetworkAdapterConfiguration|?{ $_.IPEnabled -eq $true }|%{ $_.IPAddress }| %{ [IPAddress]$_ }|?{ $_.AddressFamily -eq 'Internetwork'  }|%{ $_.IPAddressToString }

    return $computerName
}

function Get-ComputerName([bool] $resolveByIpAddress = $false)
{
    if ($resolveByIpAddress)
    {
        $computerName = Get-ComputerIPv4Address
    }
    else
    {
        $computerName = [Microsoft.Web.Hosting.Common.NetworkHelper]::GetComputerName([Microsoft.Web.Hosting.Common.ComputerNameFormat]::DnsFullyQualified)
    }

    return $computerName
}

function Allow-WinRMCalls([string] $remoteAddress)
{
    # Update filewall rule to restrict WINRM calls only from white listed ip addresses. e.g. controller subnet : "10.0.0.0/24"
    Set-NetFirewallRule -Name "WINRM-HTTP-In-TCP-PUBLIC" -RemoteAddress $remoteAddress
}

function Get-AllServersCount([string] $cnstr)
{
    try
    {
        $siteManager = New-Object Microsoft.Web.Hosting.SiteManager $cnstr
        #$count = $siteManager.RoleServers.ToArray().Length
        
        $count = 0
        foreach ($server in $siteManager.RoleServers)
        {
            # just check for Management Servers
            if ($server.RoleTypes.HasFlag([Microsoft.Web.Hosting.HostingRoleType]::ManagementServer) -eq $true)
            {
                $count++;
            }
        }

        return $count
    }
    catch
    {
        Log "Error reading the servers count. Error: $_";

        Throw;
    }
    finally
    {
        if ($siteManager -ne $Null)
        {
            $siteManager.Dispose()
        }
    }
}

function Get-ReadyServersCount([string] $cnstr)
{
    try
    {
        $siteManager = New-Object Microsoft.Web.Hosting.SiteManager $cnstr

        $count = 0
        foreach ($server in $siteManager.RoleServers)
        {
            # just wait for Management Servers
            if ($server.RoleTypes.HasFlag([Microsoft.Web.Hosting.HostingRoleType]::ManagementServer) -eq $true)
            {
                if ($server.ReadyForLoadBalancing -eq $true)
                {
                    $count++;
                }
            }
        }

        return $count
    }
    catch
    {
        Log "Error reading the ready servers count. Error: $_";

        Throw;
    }
    finally
    {
        if ($siteManager -ne $Null)
        {
            $siteManager.Dispose()
        }
    }
}

function Wait-ForServers([string] $cnstr)
{
    $allcount = Get-AllServersCount $cnstr
    $readycount = Get-ReadyServersCount $cnstr

    if($allcount -eq 0 -or $allcount -ne $readycount)
    {
        $retryCount = 1
        while ($retryCount -le 240)
        {
            Log "Waiting for servers to be ready..."
            Start-Sleep -Seconds 60

            $allcount = Get-AllServersCount $cnstr
            $readycount = Get-ReadyServersCount $cnstr
            if ($allcount -gt 0 -and $allcount -eq $readycount)
            {
                Log "Servers are ready!"

                break;
            }

            $retryCount++
        }

        $allcount = Get-AllServersCount $cnstr
        $readycount = Get-ReadyServersCount $cnstr

        if($allcount -eq 0 -or $allcount -ne $readycount)
        {
            throw New-Object System.TimeoutException "Wait for servers has timed out"
        }
    }
}
