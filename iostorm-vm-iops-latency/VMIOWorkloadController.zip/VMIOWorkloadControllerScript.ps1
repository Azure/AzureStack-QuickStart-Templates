
param (
	[Parameter(Mandatory)]
    [string]$AzureUserName,
	[Parameter(Mandatory)]
    [string]$AzurePassword,
	[string]$AzureApplicationId = "https://azurestack.local-api/",
	[Parameter(Mandatory)]
	[string]$TenantId,
	[Parameter(Mandatory)]
	[string]$VMName,
	[Parameter(Mandatory)]
	[int32]$VMCount,
	[Parameter(Mandatory)]
	[int32]$VMIoMaxLatency,
	[Parameter(Mandatory)]
	[string]$AzureStorageAccount
)

# 1. Creates smb share '$smbshare' (e.g. \\10.0.0.6\smbshare\) to store results, pre-sync and post-sync iostorm signal
# 2. Creates pre-sync directory '$ioPreSyncShare' (e.g. \\10.0.0.6\smbshare\iopresync\) where all VMs saves a file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate they are up and waiting to start a workload
# 3. Creates a '$ioWorkloadStartSignalFile' file (e.g. \\10.0.0.6\smbshare\ioworkloadstart-0) to signal all VMs to start io workload with given 'QD' and 'THREAD' values inside the file
# 4. Waits for io workload results to arrive from all VMs in io result directory '$ioResultShare' (e.g. \\10.0.0.6\smbshare\ioresult\ioresult-0)
# 5. If io workload latency values is < given maxLatency, repeat step #3 with new values of 'QD' and 'THREAD', repeat step #4 and step #5
# 6. If io workload latency values is = or > given maxLatency, then Uploads io workload result to VMIOResult.log.ps1 to Azure Portal Storage Accounts Blob

# Creates a '$ioPreSyncSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) to signal all VMs to start io workload
# Waits for io workload results to arrive from all VMs in io result directory '$ioResultShare' (e.g. \\10.0.0.6\smbshare\ioresult\)
# Uploads io workload result to VMIOResult.log.ps1 to Azure Portal Storage Accounts Blob
function VMIOController {

	# Azure uses AzureAdApplicationId and AzureAdApplicationPassword values as AzureUserName and AzurePassword parameters respectively
	# AzureStack uses tenant UserName and Password values as AzureUserName and AzurePassword parameters respectively
	$azureUserName = $AzureUserName;
	$azurePassword = $AzurePassword;
	# Azure uses "" blank value as AzureApplicationId
	# AzureStack uses "https://azurestack.local-api/" value as AzureApplicationId parameter
    $applicationId = $AzureApplicationId;
	$tenant = $TenantId;
	$vmName = $VMName;
	$vmCount = $VMCount;
	$storageAccount = $AzureStorageAccount;
	
	# Local file storage location
	$localPath = "$env:SystemDrive";

	# Log file
	$logFileName = "VMWorkloadController.log";
	$logFilePath = "$localPath\$logFileName";

	# Turn off private firewall
	netsh advfirewall set privateprofile state off;
	
	# Create result SMB share
	$smbshare = "$env:SystemDrive\smbshare";
	"Creating result smb share $smbshare" | Out-File $logFilePath -Encoding ASCII -Append;
	New-Item -Path $smbshare -Type Directory -Force -Confirm:0;
	if((Get-SMBShare -Name smbshare -ErrorAction SilentlyContinue) -eq $null) {
		New-SMBShare -Path $smbshare -Name smbshare -FullAccess Everyone;
	}

	# Create io workload pre-sync directory
	$ioPreSyncShare = "$smbshare\iopresync";
	"Creating io pre-sync share $ioPreSyncShare" | Out-File $logFilePath -Encoding ASCII -Append;
	New-Item -Path $ioPreSyncShare -Type Directory -Force -Confirm:0;

	# Sync signal to start io pre-sync from controller vm
	$ioPreSyncStartSignalFile = "$smbshare\iopresyncstart.txt";

	# Start IO workload signal file (also indicates pre IO workload sync succeed singal)
	$ioWorkloadStartSignalFile = "$smbshare\ioworkloadstart-";
	
	#$ioPreSyncSignalFile = "$smbshare\iopresyncsucceed.txt";

	# Log directory
	$logShare = "$smbshare\logs";
	"Creating logs share $logShare" | Out-File $logFilePath -Encoding ASCII -Append;
	New-Item -Path $logShare -Type Directory -Force -Confirm:0;

	# Create io result directory
	$ioResultShare = "$smbshare\ioresult";
	"Creating io result share $ioResultShare" | Out-File $logFilePath -Encoding ASCII -Append;
	New-Item -Path $ioResultShare -Type Directory -Force -Confirm:0;
	
	# PS Credentials
	$pw = ConvertTo-SecureString -AsPlainText -Force -String $azurePassword;
	$pscred = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $azureUserName,$pw;
	if($pscred -eq $null) {
		Write-Host "Powershell Credential object is null. Cannot proceed.";
		return;
	}
	$azureCreds = Get-Credential -Credential $pscred;
	if($azureCreds -eq $null) {
		Write-Host "Get-Credential returned null. Cannot proceed.";
		return;
	}
	
	######################
	### AZURE RM SETUP ###
	######################
	# AzureStack
	if($applicationId -ne "")
	{
		# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
		add-type @"
		using System.Net;
		using System.Security.Cryptography.X509Certificates;
		public class TrustAllCertsPolicy : ICertificatePolicy {
			public bool CheckValidationResult(
				ServicePoint srvPoint, X509Certificate certificate,
				WebRequest request, int certificateProblem) {
				return true;
			}
		}
"@
		[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
		Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"
	}
	
	# Import Azure Resource Manager PS module if already present
	try {
		Write-Host "Importing Azure RM";
		"Importing Azure RM" | Out-File $logFilePath -Encoding ASCII -Append;
		Import-AzureRM;
	}
	# Install Azure Resource Manager PS module
	catch {
		Write-Host "Cannot import Azure RM module, proceeding with installation";
		"Installing Azure RM" | Out-File $logFilePath -Encoding ASCII -Append;

		# Suppress prompts
		$ConfirmPreference = 'None';

		# Install AzureRM
		Get-PackageProvider -Name nuget -ForceBootstrap �Force;
		Install-Module Azure �repository PSGallery �Force -Confirm:0;
		Install-Module AzureRM �repository PSGallery �Force -Confirm:0;
		Install-AzureRm;
	}

	# AzureStack
	if($applicationId -ne "")
	{
		# Authenticate to AzureStack
		Add-AzureRmEnvironment -Name 'AzureStack' -ActiveDirectoryEndpoint ("https://login.windows.net/$tenant/") -ActiveDirectoryServiceEndpointResourceId $applicationId `
			-ResourceManagerEndpoint ("https://api.azurestack.local/") -GalleryEndpoint ("https://gallery.azurestack.local:30016/") -GraphEndpoint "https://graph.windows.net/" -StorageEndpoint "azurestack.local";
		if($azureCreds -eq $null) {
			Write-Host "Powershell Credential object is null. Cannot proceed.";
			"Powershell Credential object is null. Cannot proceed." | Out-File $logFilePath -Encoding ASCII -Append;
			return;
		}
		#$azureEnv = Get-AzureRmEnvironment 'AzureStack';
		$azureAcc = Add-AzureRmAccount -EnvironmentName 'AzureStack' -Verbose -Credential $azureCreds;
	}
	# AzureCloud
	else {
		# Authenticate to Azure using AzureAdApplication
		if($azureCreds -eq $null) {
			Write-Host "Get-Credential returned null. Cannot proceed.";
			return;
		}
		"Authenticating Azure RM Account" | Out-File $logFilePath -Encoding ASCII -Append;
		Add-AzureRmAccount -Credential $azureCreds -ServicePrincipal -Tenant $tenant;
	}

	##############################
	### VM PRE-IOSTORM SETUP ###
	##############################
	# Get VMs
	$vms = Get-AzureRmVM | Where {$_.Name -match $vmName}
	"Getting VMs" | Out-File $logFilePath -Encoding ASCII -Append;

	$timeoutInSeconds = 7200;
	# Wait timeout retry count
	$numberOfRetries = $timeoutInSeconds/120;

	# Wait for all VMs are deployed
	$resourceGroupName = $null;
	$noOfRetries = $numberOfRetries;
	$noOfDeployedVMs = 0;
	while(($noOfRetries -gt 0) -and ($noOfDeployedVMs -lt $vmCount)) {
		Start-Sleep -Seconds 120;
		$noOfDeployedVMs = 0;
		$vms = Get-AzureRmVM | Where {$_.Name -match $vmName}
		foreach($vm in $vms) {
			# All VMs except jump box VM
			if($vm.Name -match "[0-9]$") {
				$noOfDeployedVMs += 1;
			}
			# Find resource group name for publishing results
			if($resourceGroupName -eq $null) {
				$resourceGroupName = $vm.ResourceGroupName;
			}
		}
		$noOfRetries -= 1;
	}
	if($noOfDeployedVMs -lt $vmCount) {
		Write-Host "Requested number $vmCount of VMs are not deployed. Currently $noOfDeployedVMs VMs are deployed."
		"Requested number $vmCount of VMs are not deployed. Currently $noOfDeployedVMs VMs are deployed" | Out-File $logFilePath -Encoding ASCII -Append;
	}

	##################
	### VM IOSTORM ###
	##################
	# Start signal for all VMs to start io pre-sync 
	"Start io pre-sync" | Out-File $ioPreSyncStartSignalFile -Encoding ASCII;
	"Start io pre-sync" | Out-File $logFilePath -Encoding ASCII -Append;
	
	$ioResultExpectedFiles = $vmCount;
	# Wait for 7200 seconds for io pre-sync files from all vms to be created
	$noOfRetries = $timeoutInSeconds/10;
	$ioPreSyncDidSucceed = $false;
	while($noOfRetries -gt 0) {
		$existingFiles = Get-ChildItem -Path $ioPreSyncShare;
		if($existingFiles.Count -ge $ioResultExpectedFiles){
			$ioPreSyncDidSucceed = $true;
			Write-Host "Pre io workload synchronization succeeded."
			break;
		}
		Start-Sleep -Seconds 10;
		$noOfRetries--;
	}
	
	# Start IO workload by creating sync success/failure file
	if($ioPreSyncDidSucceed)
	{
		"Sync Succeeded" | Out-File $logFilePath -Encoding ASCII -Append;
	}
	else {
		"Sync Failed" | Out-File $logFilePath -Encoding ASCII -Append;
	}

	# Display boot results
	$vmioResultFile = "$env:SystemDrive\VMIOResult.log.ps1";

	# QD and Thread values
	$nl = [Environment]::NewLine;
	$qd = 1;
	$threads = 1;
	# Threads equal to Logical Processors inside VM
	$lps = (Get-WmiObject Win32_ComputerSystem).NumberOfLogicalProcessors;
	if(($lps -gt $threads) -and ($lps -lt [Int32]::MaxValue)){
		$threads = $lps;
	}
	$avgLatency = 0;
	$iteration = 0;

	# Best Result
	$bestResTxt = "";
	$bestIOPS = -1;

	# Run IO workload in loop until we reach max latency
	while($avgLatency -lt $VMIoMaxLatency) {
		# Create io result share directory for current iteration
		$ioResultIterationShare = $ioResultShare + "\iteration-$iteration";
		New-Item -Path $ioResultIterationShare -Type Directory -Force -Confirm:0;

		# Request VMs to start io workload with calculated QD and THREAD values e.g. QD:4 \n THREADS:2
		$qdVal = "QD:$qd";
		$threadsVal = "THREADS:$threads";
		$ioWorkloadStartSignalFileIteration = "$ioWorkloadStartSignalFile$iteration"
		"$qdVal$nl$threadsVal" | Out-File $ioWorkloadStartSignalFileIteration;

		# Wait 7200 seconds for VM io workload to finish
		$noOfRetries = $timeoutInSeconds/10;
		$ioWorkloadDidSucceed = $false;
		while($noOfRetries -gt 0) {
			$existingFiles = Get-ChildItem -Path $ioResultIterationShare -Filter *.xml;
			if($existingFiles.Count -ge $ioResultExpectedFiles){
				$ioWorkloadDidSucceed = $true;
				Write-Host "IO workload iteration $iteration succeeded.";
				break;
			}
			Start-Sleep -Seconds 10;
			$noOfRetries--;
		}

		# Parse IO workload results
		$latencyResult = $null;
		if($ioWorkloadDidSucceed) {
			$latencyResult = DiskspdResultAnalyzeXml -inputpath $ioResultIterationShare -outpath $vmioResultFile;
			"IO workload iteration $iteration result succeeded." | Out-File $logFilePath -Encoding ASCII -Append;
		}
		else {
			"IO workload iteration $iteration result failed." | Out-File $vmioResultFile -Encoding ASCII -Append;
			"IO workload iteration $iteration result failed." | Out-File $logFilePath -Encoding ASCII -Append;
			break;
		}

		# Calculate new values of QD and Thread based on latency value of current run
		if($latencyResult -ne $null){
			$vmCount = $latencyResult.VmCount;

			$avgReadLatency = "{0:N0}" -f [float]$latencyResult.AvgReadLat;
			$avgWriteLatency = "{0:N0}" -f [float]$latencyResult.AvgWriteLat;
			$avgLatency = "{0:N0}" -f [float]$latencyResult.AvgTotalLat;
			
			$avg95thReadLat = "{0:N0}" -f [float]$latencyResult.Avg95thReadLat;
			$avg95thWriteLat = "{0:N0}" -f [float]$latencyResult.Avg95thWriteLat;
			$avg95thTotalLat= "{0:N0}" -f [float]$latencyResult.Avg95thTotalLat;

			$tReadIops = "{0:N0}" -f [float]$latencyResult.ReadIops;
			$tWriteIops = "{0:N0}" -f [float]$latencyResult.WriteIops;
			$tTotalIops = "{0:N0}" -f [float]$latencyResult.TotalIops;

			$blockSize = "{0:N0}" -f [float]$latencyResult.BlockSize;
			$writeRatio = "{0:N0}" -f [float]$latencyResult.WriteRatio;
			$readRatio = (100 - $writeRatio);
			
			#$txt = "Iteration $iteration, Avg Latency (in ms): (Total: $avgLatency, Read: $avgReadLatency, Write: $avgWriteLatency), Avg 95th % Latency (in ms): (Total: $avg95thTotalLat, Read: $avg95thReadLat, Write: $avg95thWriteLat), Combined IOPS: (Total: $tTotalIops, Read: $tReadIops, Write: $tWriteIops), QD: $qd, Threads: $threads";
			$resTxt = "Iteration $iteration, Overall-IOPS: (Total: $tTotalIops, Read: $tReadIops, Write: $tWriteIops), AvgLatencyInMsec: (Total: $avgLatency, Read: $avgReadLatency, Write: $avgWriteLatency), Avg95thPercLatencyInMsec: (Total: $avg95thTotalLat, Read: $avg95thReadLat, Write: $avg95thWriteLat), NumberOfVMs: $vmCount, QueueDepth: $qd, NumThreads: $threads, BlockSize: $blockSize, ReadWriteRatio: $readRatio/$writeRatio, AccessPattern: Random"
			$resTxt | Out-File $vmioResultFile -Encoding ASCII -Append;
			$resTxt | Out-File $logFilePath -Encoding ASCII -Append;
			
			# Save best result
			if($bestIOPS -lt $tTotalIops) 
			{ 
				$bestIOPS = $tTotalIops; 
				$bestResTxt = $resTxt; 
			}

			# New QD and Threads value
			$qd *= 2;
			#$threads = 1;
			$iteration += 1;
		}
		else {
			"IO workload iteration $iteration latency result $latencyResult is null. Cannot continue iterations." | Out-File $logFilePath -Encoding ASCII -Append;
			break;
		}
	}

	# Append best IOPS results of the test run
	"BEST IOPS RESULTS:" | Out-File $vmioResultFile -Encoding ASCII -Append;
	"BEST IOPS RESULTS:" | Out-File $logFilePath -Encoding ASCII -Append;
	$bestResTxt | Out-File $vmioResultFile -Encoding ASCII -Append;
	$bestResTxt | Out-File $logFilePath -Encoding ASCII -Append;
	
	# Upload VM io result to Portal
	"Publishing io workload results $vmioResultFile to Azure storage account $storageAccount in resource group $resourceGroupName" | Out-File $logFilePath -Encoding ASCII -Append;
	Publish-AzureRmVMDscConfiguration -ResourceGroupName $resourceGroupName -ConfigurationPath $vmioResultFile -StorageAccountName $storageAccount -SkipDependencyDetection -Force;
}

## COLUMNS ## VM Name	Write Ratio	Threads	Requests	Block Size	Read IOPS	Read Bytes	Write IOPS	Write Bytes	Avg Read (ms)	Avg Write (ms)	Read (ms) - 25%	Write (ms) - 25%	Read (ms) - 50%	Write (ms) - 50%	Read (ms) - 75%	Write (ms) - 75%	Read (ms) 90%	Write (ms) - 90%	Read (ms) - 95%	Write (ms) - 95%	Read (ms) - 99%	Write (ms) - 99%	Read (ms) - 99.9%	Write (ms) - 99.9%	Read (ms) - 100%	Write (ms) - 100%
function DiskspdResultAnalyzeXml {
	param([string]$inputpath=".", [string]$outpath)

	# Average Read/Write Latency
	$sumAvgReadLatencyForAllXml = 0.0;
	$sumAvgWriteLatencyForAllXml = 0.0;
	$sumAvgTotalLatencyForAllXml = 0.0;
	# 95th Percentile Read/Write Latency
	$sum95thReadLatencyForAllXml = 0.0;
	$sum95thWriteLatencyForAllXml = 0.0;
	$sum95thTotalLatencyForAllXml = 0.0;
	# Average Read/Write IOPS
	$sumAvgReadIopsForAllXml = 0.0;
	$sumAvgWriteIopsForAllXml = 0.0;
	$totalXml = 0;
	# Block Size
	$blockSize = 0;
	# Write Ratio
	$writeRatio = 0;

	# Header
	if((Test-Path $outpath) -eq $false) {
		"VM Name	Avg CPU Usage	Write Ratio	Threads	Requests	Block Size	Read IOPS	Read Bytes	Write IOPS	Write Bytes	Avg Read (ms)	Avg Write (ms)	Read (ms) - 25%	Write (ms) - 25%	Read (ms) - 50%	Write (ms) - 50%	Read (ms) - 75%	Write (ms) - 75%	Read (ms) 90%	Write (ms) - 90%	Read (ms) - 95%	Write (ms) - 95%	Read (ms) - 99%	Write (ms) - 99%	Read (ms) - 99.9%	Write (ms) - 99.9%	Read (ms) - 100%	Write (ms) - 100%" | out-file $outpath -Encoding ascii -Width 9999 -Append;
	}
	
	$l = @(); foreach ($i in 25,50,75,90,95,99,99.9,100) { $l += ,[string]$i };

	Get-ChildItem -Path $inputpath -Recurse -Filter *.xml | Sort-Object |% {
		$pwdir = (pwd).Path
		cd $_.Directory.FullName
		$x = [xml](Get-Content $_)

		#$system = $_.Directory.Name + "_" + $x.Results.System.ComputerName
		$system = $x.Results.System.ComputerName + "_" + $_.Directory.Name
		$t = $x.Results.TimeSpan.TestTimeSeconds

		# Sum of avg read/write latency
		$sumAvgReadLatencyForAllXml += $x.Results.TimeSpan.Latency.AverageReadMilliseconds;
		$sumAvgWriteLatencyForAllXml += $x.Results.TimeSpan.Latency.AverageWriteMilliseconds;
		$sumAvgTotalLatencyForAllXml += $x.Results.TimeSpan.Latency.AverageTotalMilliseconds;
		$totalXml += 1;

		# extract the subset of latency percentiles as specified above in $l
		$h = @{}; $x.Results.TimeSpan.Latency.Bucket |% { $h[$_.Percentile] = $_ }

		$ls = $l |% {
			$b = $h[$_];
			if ($b.ReadMilliseconds) { $b.ReadMilliseconds } else { "" }
			if ($b.WriteMilliseconds) { $b.WriteMilliseconds } else { "" }
		}

		# Sum of 95th percentile read/write latency
		$lat95th = $h[[string]95];
		if($lat95th.ReadMilliseconds) { $sum95thReadLatencyForAllXml += $lat95th.ReadMilliseconds; }
		if($lat95th.WriteMilliseconds) { $sum95thWriteLatencyForAllXml += $lat95th.WriteMilliseconds; }
		if($lat95th.TotalMilliseconds) { $sum95thTotalLatencyForAllXml += $lat95th.TotalMilliseconds }		

		# sum read and write iops across all threads and targets
		$ri = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property ReadCount).Sum
		$wi = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property WriteCount).Sum
		$rb = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property ReadBytes).Sum
		$wb = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property WriteBytes).Sum

		# Block size
		$blockSize = ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property BlockSize).Sum / ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property BlockSize).Count;
		$writeRatio = ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property WriteRatio).Sum / ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property WriteRatio).Count;

		# Sum of avg of read/write iops
		$sumAvgReadIopsForAllXml += ($ri / $t);
		$sumAvgWriteIopsForAllXml += ($wi / $t);

		# output tab-separated fields. note that with runs specified on the command
		# line, only a single write ratio, outstanding request count and blocksize
		# can be specified, so sampling the one used for the first thread is 
		# sufficient.
		(($system,
			$x.Results.TimeSpan.CpuUtilization.Average.UsagePercent,
			$x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.WriteRatio,
			$x.Results.TimeSpan.ThreadCount,
			$x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.RequestCount,
			$x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.BlockSize,
			# calculate iops
			($ri / $t),
			($rb / $t),
			($wi / $t),
			($wb / $t),
			$x.Results.TimeSpan.Latency.AverageReadMilliseconds,
			$x.Results.TimeSpan.Latency.AverageWriteMilliseconds
			) -join "`t"),
		($ls -join "`t") -join "`t"
		cd $pwdir
	} | out-file $outpath -Encoding ASCII -Width 9999 -Append
	
	$avgAvgReadLatencyForAllXml = $sumAvgReadLatencyForAllXml/$totalXml;
	$avgAvgWriteLatencyForAllXml = $sumAvgWriteLatencyForAllXml/$totalXml;
	$avgAvgTotalLatencyForAllXml = $sumAvgTotalLatencyForAllXml/$totalXml;

	$avg95thReadLatencyForAllXml = $sum95thReadLatencyForAllXml/$totalXml;
	$avg95thWriteLatencyForAllXml = $sum95thWriteLatencyForAllXml/$totalXml;
	$avg95thTotalLatencyForAllXml = $sum95thTotalLatencyForAllXml/$totalXml;

	# Create custom latency and iops result object
	$customResult = "" | Select-Object AvgReadLat, AvgWriteLat, AvgTotalLat, Avg95thReadLat, Avg95thWriteLat, Avg95thTotalLat, ReadIops, WriteIops, TotalIops, BlockSize, WriteRatio, VmCount;
	$customResult.AvgReadLat = $avgAvgReadLatencyForAllXml;
	$customResult.AvgWriteLat = $avgAvgWriteLatencyForAllXml;
	$customResult.AvgTotalLat = $avgAvgTotalLatencyForAllXml;
	$customResult.Avg95thReadLat = $avg95thReadLatencyForAllXml;
	$customResult.Avg95thWriteLat = $avg95thWriteLatencyForAllXml;
	$customResult.Avg95thTotalLat = $avg95thTotalLatencyForAllXml;
	$customResult.ReadIops = $sumAvgReadIopsForAllXml;
	$customResult.WriteIops = $sumAvgWriteIopsForAllXml;
	$customResult.TotalIops = ($sumAvgReadIopsForAllXml + $sumAvgWriteIopsForAllXml);
	$customResult.BlockSize = $blockSize;
	$customResult.WriteRatio = $writeRatio;
	$customResult.VmCount = $totalXml;
	return $customResult;
} # End function DiskspdResultAnalyzeXml

VMIOController
 