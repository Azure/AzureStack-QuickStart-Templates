#
# Copyright="?Microsoft Corporation. All rights reserved."
#

param (
    [Parameter(Mandatory)]
    [string]$VMName,
    [Parameter(Mandatory)]
    [int32]$VMCount,
    [Parameter(Mandatory)]
    [int32]$VMIoMaxLatency,
    [Parameter(Mandatory)]
    [string]$Location,
    [Parameter(Mandatory)]
    [string]$AzureStorageAccount,
    [Parameter(Mandatory)]
    [string]$AzureStorageAccessKey,
    [Parameter(Mandatory)]
    [string]$AzureStorageEndpoint,
    [Parameter(Mandatory)]
    [int32]$VMIoStartOperations,
    [int32]$FixedIops = 0,
    [string]$RunFixedIoLatencyTestAfterGoalSeek = $false,
    [int32]$DataDisks = 1

)

# 1. Creates smb share '$smbshare' (e.g. \\10.0.0.6\smbshare\) to store results, pre-sync and post-sync iostorm signal
# 2. Creates pre-sync directory '$ioPreSyncShare' (e.g. \\10.0.0.6\smbshare\iopresync\) where all VMs saves a file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate they are up and waiting to start IO workload
# 3. Creates a '$ioWorkloadStartSignalFile' file (e.g. \\10.0.0.6\smbshare\ioworkloadstart-0) to signal all VMs to start IO workload with given 'QD' and 'THREAD' values inside the file
# 4. Waits for IO workload results to arrive from all VMs in IO result directory '$ioResultShare' (e.g. \\10.0.0.6\smbshare\ioresult\ioresult-0)
# 5. If IO workload latency values is < given maxLatency, repeat step #3 with new values of 'QD' and 'THREAD', repeat step #4 and step #5
# 6. If IO workload latency values is = or > given maxLatency, then Uploads IO workload result to VMIOResult.log to Azure Portal Storage Accounts Blob

# Creates a '$ioPreSyncSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) to signal all VMs to start IO workload
# Waits for IO workload results to arrive from all VMs in IO result directory '$ioResultShare' (e.g. \\10.0.0.6\smbshare\ioresult\)
# Uploads IO workload result to VMIOResult.log to Azure Portal Storage Accounts Blob

$logFilePath = $null
function Get-IoStormMode {
    param (
        [bool]$RunFixedIoLatencyTestAfterGoalSeek,
        [int32]$FixedIops
    )
    if($RunFixedIoLatencyTestAfterGoalSeek -eq $true -and $FixedIops -ne 0) {
        $ioStormInitialMode = "GoalSeek"
        $ioStormMode = "GoalSeekFixedIops"
    } elseif($RunFixedIoLatencyTestAfterGoalSeek -eq $false -and $FixedIops -ne 0) {
        $ioStormMode = "FixedIops"
    } else {
        $ioStormMode = "GoalSeek"
    }
    return $ioStormMode
}

function VMIOController {
    $vmName = $VMName
    $vmCount = $VMCount
    $location = $Location
    $diskSpdSummaryResults = @()
    $storageAccount = $AzureStorageAccount
    $storageAccountKey = $AzureStorageAccessKey
    $storageEndpoint = $AzureStorageEndpoint
    # Local file storage location
    $localPath = "$env:SystemDrive"
    $csvPath = "$localPath\IoData.csv"
    $fixedIopsCsvPath = "$localPath\FixedIoData.csv"



    # Log file
    $logFileName = "VMWorkloadController.log"

    $statusFilePath = "$localPath\VMIoStatus.log"
    $logFilePath = "$localPath\$logFileName"
    $global:LogFilePath = "$logFilePath"
    # RunFixedIoLatencyTestAfterGoalSeek is passed as a parameter from
    # a scheduled task. It must be a string or int.
    if($RunFixedIoLatencyTestAfterGoalSeek -eq "true") {
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $true
    } else {
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $false
    }

    $ioStormMode = Get-IoStormMode -RunFixedIoLatencyTestAfterGoalSeek $RunFixedIoLatencyTestAfterGoalSeek -FixedIops $FixedIops

    $restartRun = $false
    if(Test-Path $logFilePath -ErrorAction SilentlyContinue) {
        if($FixedIops -ne 0) {
            $restartRun = $true
        } else {
            Log-Info -Message  "Log file already exists. Skipping test execution."
            return
        }
    }

    if($restartRun -eq $false) {
        New-CSVHeader -CsvPath $csvPath
    }

    # Turn off private firewall
    Set-NetFirewallProfile -Enabled:0 -Confirm:0

    # Create result SMB share
    $smbshare = "$env:SystemDrive\smbshare"
    if((Get-Item -Path $smbshare -ErrorAction SilentlyContinue) -eq $null) {
        Log-Info -Message "Creating result smb share $smbshare"
        New-Item -Path $smbshare -Type Directory -Force -Confirm:0
    }
    if((Get-SMBShare -Name smbshare -ErrorAction SilentlyContinue) -eq $null) {
        New-SMBShare -Path $smbshare -Name smbshare -FullAccess Everyone
    }

    # Create IO workload pre-sync directory
    $ioPreSyncShare = "$smbshare\iopresync"
    if((Get-Item -Path $ioPreSyncShare -ErrorAction SilentlyContinue) -eq $null) {
        Log-Info -Message "Creating IO pre-sync share $ioPreSyncShare"
        New-Item -Path $ioPreSyncShare -Type Directory -Force -Confirm:0
    }

    # Sync signal to start IO pre-sync from controller vm
    $ioPreSyncStartSignalFile = "$smbshare\iopresyncstart.txt"

    # Start IO workload signal file (also indicates pre IO workload sync succeed singal)
    $ioWorkloadStartSignalFile = "$smbshare\ioworkloadstart-"

    # Log directory
    $logShare = "$smbshare\logs"
    if((Get-Item -Path $logShare -ErrorAction SilentlyContinue) -eq $null) {
        Log-Info -Message "Creating logs share $logShare"
        New-Item -Path $logShare -Type Directory -Force -Confirm:0
    }

    # Create IO result directory
    $ioResultShare = "$smbshare\ioresult"
    if((Get-Item -Path $ioResultShare -ErrorAction SilentlyContinue) -eq $null) {
        Log-Info -Message "Creating IO result share $ioResultShare"
        New-Item -Path $ioResultShare -Type Directory -Force -Confirm:0
    }

    if($FixedIops -ne 0) {
        Log-Info -Message "Running fixed IO load of $FixedIops"
    }
    ######################
    ### AZURE RM SETUP ###
    ######################
    # AzureStack
    if($restartRun -eq $false) {
        if((IsAzureStack -Location $location) -eq $true){
            # Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
            add-type @"
            using System.Net;
            using System.Security.Cryptography.X509Certificates;
            public class TrustAllCertsPolicy : ICertificatePolicy {
                public bool CheckValidationResult(
                    ServicePoint srvPoint, X509Certificate certificate,
                    WebRequest request, int certificateProblem) {
                    return true;
                }
            }
"@
            [System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
            Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

            # Download AzureStack Powershell SDK
            while (!$installFinished -and $count -lt 5) {
                try {
                    Install-Module -Name AzureRM -RequiredVersion 1.2.6 -Scope AllUsers -ErrorAction Stop -Confirm:0
                    $installFinished = $true
                }
                catch {
                    $count++
                    Start-Sleep -Seconds 10
                    Write-Warning "Could not install AzureRM module.  Trying again ($count / 5)"
                }
            }
            Disable-AzureRmDataCollection

            # Import Azure Resource Manager PS module if already present
            try {
                Log-Info -Message "Importing Azure module"
                Import-Module AzureRm -ErrorAction Stop | Out-Null
            } catch [Exception] {
                Write-Error "Cannot import Azure module. Cannot proceed further without Azure module. Exception: $_"
                Log-Info -Message "Cannot import Azure module. Cannot proceed further without Azure module. Exception: $_"
                return
            }
        }
        # Azure Cloud
        else {
            # Import Azure Resource Manager PS module if already present
            try {
                Log-Info -Message "Importing Azure module"
                Import-Module Azure -ErrorAction Stop | Out-Null
                Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
            }
            # Install Azure Resource Manager PS module
            catch {
                # Suppress prompts
                $ConfirmPreference = 'None'
                Write-Error "Cannot import Azure module, proceeding with installation"
                "Cannot import Azure module, proceeding with installation" | Out-File $logFilePath -Encoding ASCII -Append

                # Install AzureRM
                try {
                    Get-PackageProvider -Name nuget -ForceBootstrap -Force | Out-Null
                    Install-Module Azure -Repository PSGallery -Force -Confirm:0 | Out-Null
                    Install-Module AzureRM.Compute -Repository PSGallery -Force -Confirm:0 | Out-Null
                }
                catch {
                    Write-Error "Installation of Azure module failed."
                    "Installation of Azure module failed." | Out-File $logFilePath -Encoding ASCII -Append
                }

                # Import AzureRM
                try {
                    Import-Module Azure -ErrorAction Stop | Out-Null
                    Import-Module AzureRM.Compute -ErrorAction Stop | Out-Null
                    Import-Module AzureRM.Profile -ErrorAction Stop | Out-Null
                } catch {
                    Write-Error "Cannot import Azure module. Cannot proceed further without Azure module."
                    "Cannot import Azure module. Cannot proceed further without Azure module." | Out-File $logFilePath -Encoding ASCII -Append
                    return
                }
            }
        }
    }
    ##################
    ### VM IOSTORM ###
    ##################
    # Start signal for all VMs to start IO pre-sync
    "Start IO pre-sync" | Out-File $ioPreSyncStartSignalFile -Encoding ASCII
    Log-Info -Message "Start IO pre-sync"


    $ioResultExpectedFiles = $vmCount
    $timeoutInSeconds = 7200
    # Wait for 7200 seconds for IO pre-sync files from all vms to be created
    $noOfRetries = $timeoutInSeconds/10
    $ioPreSyncDidSucceed = $false
    while($noOfRetries -gt 0) {
        $existingFiles = Get-ChildItem -Path $ioPreSyncShare
        if($existingFiles.Count -ge $ioResultExpectedFiles) {
            $ioPreSyncDidSucceed = $true
            Log-Info -Message "Pre IO workload synchronization succeeded."
            break
        }
        Start-Sleep -Seconds 10
        $noOfRetries--
    }

    # Start IO workload by creating sync success/failure file
    if($ioPreSyncDidSucceed) {
        Log-Info -Message  "Sync Succeeded"
    }
    else {
        Log-Info -Message "Sync Failed"
    }

    Log-Info -Message "Azure storage endpoint is $storageEndpoint"

    $storageContext = $null
    $storageTable = $null
    $executionId = Get-Date -Format yyyyMMdd_HHmm
    try {
        # Use TLS 1.2
        [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12

        $storageContext = New-AzureStorageContext $storageAccount -StorageAccountKey $storageAccountKey -Endpoint $storageEndpoint -ErrorAction Stop
        if($storageContext -eq $null) {
            Log-Info -Message "Azure storage context is null."
            Write-Error "Azure storage context is null."
        }
        else {
            Log-Info -Message "Azure storage context creation succeeded."
        }
        $storageTableName = "VMIoResults"

        # Retrieve the table if it already exists.
        try {
            Log-Info -Message "Checking if storage table $storageTableName already exists"
            $storageTable = Get-AzureStorageTable -Name $storageTableName -Context $storageContext -ErrorAction Stop
            if($storageTable -ne $null -and $restartRun -eq $false)
            {
                Log-Info -Message "Removing existing table $storageTableName"
                Remove-AzureStorageTable -Name $storageTableName -Context $storageContext -Force -Confirm:0 -ErrorAction Stop
                $storageTable = $null
            }
        } catch {
            Log-Info -Message "Storage table $storageTableName does not exists. Creating a new table."
        }

        #Create a new table if it does not exist.
        if ($storageTable -eq $null) {
            try {
                Log-Info -Message "Creating storage table $storageTableName"
                $storageTable = New-AzureStorageTable -Name $storageTableName -Context $storageContext -ErrorAction Stop
                Log-Info -Message "Creating storage table $storageTableName succeeded"
            } catch [Exception] {
                Log-Info -Message "Storage table $storageTableName cannot be created. $_"
                return
            }
        }
    }
    catch {
        Log-Info -Message "Azure storage context cannot be created for a given storage account $storageAccount"
        Write-Error "Azure storage context cannot be created."
    }

    # Display IO results
    $vmioResultFile = "$env:SystemDrive\VMIOResult.log"

    # QD and Thread values
    $nl = [Environment]::NewLine
    $qd = $VMIoStartOperations

    # Threads equal to Logical Processors inside VM
    # As we stripe data disks to create logical disks, use number of
    # logical disks as the divsor.
    # switch to using logfical disks in thread computation once dependants are altered
    $logicalDisks = 1

    $lps = (Get-WmiObject Win32_ComputerSystem).NumberOfLogicalProcessors
    $threads = $lps
    Log-Info -Message "$lps logical processors, $DataDisks data disks. $logicalDisks Logical Disks. Using $threads per file"
    $avg95thTotalLat = 0
    $avgLatency = 0
    $iteration = 0
    try {
        if($restartRun -eq $true) {
            #find highest iteration
            $startFilePath = "$smbshare\ioworkloadstart-*"
            $startFiles = Get-ChildItem $startFilePath
            $startNames = $startFiles.Name
            $allIterations = @()
            foreach($n in $startNames) {
                $splitStr = $n.Split("-")
                $iterStr = $splitStr[1]
                $iterNum = [convert]::ToInt32($iterStr, 10)
                $allIterations += $iterNum
            }
            $measure = $allIterations | Measure-Object -Maximum
            $iteration = $measure.Maximum + 1
        }
    } catch {
        Log-Info -Message "Failed to determine start iteration. Defaulting to 0. $_"
    }
    Log-Info -Message "Starting with iteration $iteration"
    # Best Result
    $bestResTxt = ""
    $bestIOPS = -1

    # Run IO workload in loop until we reach max latency
    # Tolerate $latencyFailureCountMax number of latency related failures
    # as the stamp may experience non-test related load from
    # infra at any point in time
    $latencyFailureCountMax = 3
    $latencyFailureCount = 0
    #while($avg95thLat -lt $VMIoMaxLatency -or ($ioStormMode -eq "FixedIops")) {
    while($latencyFailureCount -lt $latencyFailureCountMax -or ($ioStormMode -eq "FixedIops")) {
        Log-Info -Message "IoStorm mode: $ioStormMode"
        Log-Info -Message "Previous 95th latency: $avg95thLat. Max latency $VMIoMaxLatency"
        Log-Info -Message "Latency failure count: $latencyFailureCount. Max latency failures tolerated: $latencyFailureCountMax"

        # Create IO result share directory for current iteration
        $ioResultIterationShare = $ioResultShare + "\iteration-$iteration"
        New-Item -Path $ioResultIterationShare -Type Directory -Force -Confirm:0

        # Request VMs to start IO workload with calculated QD and THREAD values e.g. QD:4 \n THREADS:2
        $qdVal = "QD:$qd"
        $threadsVal = "THREADS:$threads"
        $ioWorkloadStartSignalFileIteration = "$ioWorkloadStartSignalFile$iteration"
        Log-Info -Message "Signaling to start IO workload | ITERATION: $iteration QD: $qdVal THREADS: $threadsVal"
        "$qdVal$nl$threadsVal" | Out-File $ioWorkloadStartSignalFileIteration

        # Wait 7200 seconds for VM IO workload to finish
        $noOfRetries = $timeoutInSeconds/10
        $ioWorkloadDidSucceed = $false
        Log-Info -Message "Waiting for IO workload to finish"
        while($noOfRetries -gt 0) {
            $existingFiles = Get-ChildItem -Path $ioResultIterationShare -Filter *.xml
            if($existingFiles.Count -ge $ioResultExpectedFiles) {
                $ioWorkloadDidSucceed = $true
                Log-Info -Message "IO workload iteration $iteration succeeded."
                break
            }
            Start-Sleep -Seconds 10
            $noOfRetries--
        }

        # Parse IO workload results
        # On fixed workload runs this a run may be interupted,
        # so parsing may fail
        try {
            $latencyResult = $null
            if($ioWorkloadDidSucceed) {
                $latencyResult = DiskspdResultAnalyzeXml -inputpath $ioResultIterationShare -outpath $vmioResultFile -storageTable $storageTable -executionId $executionId -iteration $iteration
                $fullLatencyResults = @{}
                $fullLatencyResults.summary = $latencyResult
                #qd is acutally diskspd operations per thread
                $fullLatencyResults.ops = $qd
                $fullLatencyResults.threads = $threads
                $fullLatencyResults.vmCount = $vmCount
                $fullLatencyResults.totalQD = $vmCount * $threads * $qd
                $diskSpdSummaryResults += $fullLatencyResults
                Log-Info -Message "IO workload iteration $iteration result succeeded."
            }
            else {
                "IO workload iteration $iteration result failed." | Out-File $vmioResultFile -Encoding ASCII -Append
                Log-Info -Message "IO workload iteration $iteration result failed."
                break
            }

            # Calculate new values of QD and Thread based on latency value of current run
            if($latencyResult -ne $null) {
                $vmCount = $latencyResult.VmCount

                $avgReadLatency = "{0:N0}" -f [float]$latencyResult.AvgReadLat
                $avgWriteLatency = "{0:N0}" -f [float]$latencyResult.AvgWriteLat
                $avgTotalLatency = "{0:N0}" -f [float]$latencyResult.AvgTotalLat
                $avgLatency = [float]$latencyResult.AvgTotalLat

                $avg95thReadLat = "{0:N0}" -f [float]$latencyResult.Avg95thReadLat
                $avg95thWriteLat = "{0:N0}" -f [float]$latencyResult.Avg95thWriteLat
                $avg95thTotalLat= "{0:N0}" -f [float]$latencyResult.Avg95thTotalLat
                $avg95thLat = [float]$latencyResult.Avg95thTotalLat

                $tReadIops = "{0:N0}" -f [float]$latencyResult.ReadIops
                $tWriteIops = "{0:N0}" -f [float]$latencyResult.WriteIops
                $tTotalIops = "{0:N0}" -f [float]$latencyResult.TotalIops

                $blockSize = "{0:N0}" -f [float]$latencyResult.BlockSize
                $writeRatio = "{0:N0}" -f [float]$latencyResult.WriteRatio
                $readRatio = (100 - $writeRatio)

                $resTxt = "Iteration $iteration, Overall-IOPS: (Total: $tTotalIops, Read: $tReadIops, Write: $tWriteIops), AvgLatencyInMsec: (Total: $avgTotalLatency, Read: $avgReadLatency, Write: $avgWriteLatency), Avg95thPercLatencyInMsec: (Total: $avg95thTotalLat, Read: $avg95thReadLat, Write: $avg95thWriteLat), NumberOfVMs: $vmCount, QueueDepth: $qd, NumThreads: $threads, BlockSize: $blockSize, ReadWriteRatio: $readRatio/$writeRatio, AccessPattern: Random"
                $resTxt | Out-File $vmioResultFile -Encoding ASCII -Append
                Log-Info -Message $resTxt

                $nocommaReadIops = "{0:F0}" -f $latencyResult.ReadIops
                $nocommaWriteIops = "{0:F0}" -f $latencyResult.WriteIops
                $nocommaTotalIops = "{0:F0}" -f $latencyResult.TotalIops
                $nocommaBlocksize =  "{0:F0}" -f $latencyResult.BlockSize
                $noFiles = "{0:N0}" -f $DataDisks

                # Add vm boot results to the Azure storage table
                if($storageTable -ne $null) {
                    try {
                        # Summary
                        Add-CsvRow -CSvPath $csvPath -RunName "Summary-Iteration-$iteration" -Iteration $iteration -NumberOfVMs $vmCount -QueueDepth $qd -NumberOfThreads $threads -BlockSize $nocommaBlocksize -ReadWriteRatio $readRatio/$writeRatio -AccessPattern "Random" -Total_IOPS $nocommaTotalIops -Read_IOPS $nocommaReadIops -Write_IOPS $nocommaWriteIops -Total_AvgLatency $avgTotalLatency -Read_AvgLatency $avgReadLatency -Write_AvgLatency $avgWriteLatency -Total_95thPercentile_AvgLatency $avg95thTotalLat -Read_95thPercentile_AvgLatency $avg95thReadLat -Write_95thPercentile_AvgLatency $avg95thWriteLat -NumberOfFiles $noFiles
                        Add-TableEntity -Table $storageTable -PartitionKey $executionId -RowKey "Summary-Iteration-$iteration" -Iteration $iteration -Details $resTxt -NumberOfVMs $vmCount -QueueDepth $qd -NumberOfThreads $threads -BlockSize $blockSize -ReadWriteRatio $readRatio/$writeRatio -AccessPattern "Random" -Total_IOPS $tTotalIops -Read_IOPS $tReadIops -Write_IOPS $tWriteIops -Total_AvgLatency $avgTotalLatency -Read_AvgLatency $avgReadLatency -Write_AvgLatency $avgWriteLatency -Total_95thPercentile_AvgLatency $avg95thTotalLat -Read_95thPercentile_AvgLatency $avg95thReadLat -Write_95thPercentile_AvgLatency $avg95thWriteLat -NumberOfFiles $noFiles
                    } catch {
                        Log-Info -Message "Adding Azure storage table entry for row $vmResultIndex failed. $_"
                    }
                }
                else {
                    Log-Info -Message "Azure storage table object $storageTable is null"
                }

                # Save best result for either the 1st iteration
                # or for the iteration that has the best iops and within latency max
                if($iteration -eq 0 -or ($bestIOPS -lt $tTotalIops -and $avg95thLat -lt $VMIoMaxLatency))
                {
                    $bestIOPS = $tTotalIops
                    $bestResTxt = $resTxt
                }

            }
            else {
                Log-Info -Message "IO workload iteration $iteration latency result $latencyResult is null. Cannot continue iterations."
                break
            }
        } catch {
            Log-Info -Message "Failed to parse results for iteration $_"
        }
        if($avg95thLat -ge $VMIoMaxLatency) {
            $latencyFailureCount++
            Log-Info -Message "latency of $avg95thLat exceeded threshhold of VMIoMaxLatency. This has occured $latencyFailureCount times"
        } else {
            $latencyFailureCount = 0
            # New QD and Threads value
            if($ioStormMode -ne "FixedIops") {
                $qd += 1
            }
        }
        $iteration += 1
        #if threads are to be incremented, do it here
    }
    Log-Info -Message "Average 95th% latency for iteration $iteration is $avg95thTotalLat, more than max latency value $VMIoMaxLatency."

    $resultHtmlPath = CreateHtmlSummary -ResultSummary $diskSpdSummaryResults
    Log-Info -Message "Result HTML summary in $resultHtmlPath"
    # Append best IOPS results of the test run
    "BEST IOPS RESULTS:" | Out-File $vmioResultFile -Encoding ASCII -Append
    Log-Info -Message "BEST IOPS RESULTS:"
    $bestResTxt | Out-File $vmioResultFile -Encoding ASCII -Append
    Log-Info -Message $bestResTxt

    $storageContainerName = "results-$vmName"

    try {
        if((Get-AzureStorageContainer -Name $storageContainerName -Context $storageContext -ErrorAction SilentlyContinue) -ne $null) {
            Log-Info -Message "Removing existing storage container $storageContainerName"
            Remove-AzureStorageContainer -Name $storageContainerName -Context $storageContext -PassThru -Force -Confirm:0 -ErrorAction Stop
        }
        New-AzureStorageContainer -Name $storageContainerName -Context $storageContext -Permission Blob -ErrorAction Stop

        # Upload iostorm results to azure storage blob
        Log-Info -Message "Uploading IO workload results $vmioResultFile to Azure storage account $storageAccount in resource group $resourceGroupName"
        Set-AzureStorageBlobContent -File $vmioResultFile -Context $storageContext -Container $storageContainerName -ErrorAction Stop

        # Upload iostorm execution logs to azure storage blob
        Log-Info -Message "Uploading IO workload execution logs $logFilePath to Azure storage account $storageAccount in resource group $resourceGroupName"
        Set-AzureStorageBlobContent -File $logFilePath -Context $storageContext -Container $storageContainerName -ErrorAction Stop

        #upload summary html
        Set-AzureStorageBlobContent -File $resultHtmlPath -Context $storageContext -Container $storageContainerName -ErrorAction Stop
    } catch [Exception] {
        Log-Info -Message "Uploading log and results to Azure Storage Blob failed with exception $_"
        Write-Error "Uploading log and results to Azure Storage Blob failed with exception $_"
    }

    if($ioStormMode -eq "GoalSeekFixedIops") {
        Log-Info -Message "Starting fixed IOPS run."
        $ioResultIterationShare = $ioResultShare + "\iteration-$iteration"
        New-Item -Path $ioResultIterationShare -Type Directory -Force -Confirm:0

        # Request VMs to start IO workload with calculated QD and THREAD values e.g. QD:4 \n THREADS:2
        $qdVal = "QD:$qd"
        $threadsVal = "THREADS:$threads"
        $fixedVal = "FIXED:$FixedIops"
        $ioWorkloadStartSignalFileIteration = "$ioWorkloadStartSignalFile$iteration"
        Log-Info -Message "Signaling to start IO workload | ITERATION: $iteration QD: $qdVal THREADS: $threadsVal FIXED: $fixedVal"
        "$qdVal$nl$threadsVal$nl$fixedVal" | Out-File $ioWorkloadStartSignalFileIteration

        # Wait 7200 seconds for VM IO workload to finish
        $noOfRetries = $timeoutInSeconds/10
        $ioWorkloadDidSucceed = $false
        Log-Info -Message "Waiting for IO workload to finish"
        while($noOfRetries -gt 0) {
            $existingFiles = Get-ChildItem -Path $ioResultIterationShare -Filter *.xml
            if($existingFiles.Count -ge $ioResultExpectedFiles) {
                $ioWorkloadDidSucceed = $true
                Log-Info -Message "IO workload iteration $iteration succeeded." | Out-File $logFilePath -Encoding ASCII -Append
                break
            }
            Start-Sleep -Seconds 10
            $noOfRetries--
        }
        try {
            $latencyResult = $null
            if($ioWorkloadDidSucceed) {
                $latencyResult = DiskspdResultAnalyzeXml -inputpath $ioResultIterationShare -outpath $vmioResultFile -storageTable $storageTable -executionId $executionId -iteration $iteration
                $fullLatencyResults = @{}
                $fullLatencyResults.summary = $latencyResult
                #qd is acutally diskspd operations per thread
                $fullLatencyResults.ops = $qd
                $fullLatencyResults.threads = $threads
                $fullLatencyResults.vmCount = $vmCount
                $fullLatencyResults.totalQD = $vmCount * $threads * $qd
                $diskSpdSummaryResults += $fullLatencyResults
                Log-Info -Message "IO workload iteration $iteration result succeeded."
            }
            else {
                "IO workload iteration $iteration result failed." | Out-File $vmioResultFile -Encoding ASCII -Append
                Log-Info -Message "IO workload iteration $iteration result failed."
                break
            }

            # Calculate new values of QD and Thread based on latency value of current run
            if($latencyResult -ne $null) {
                $vmCount = $latencyResult.VmCount

                $avgReadLatency = "{0:N0}" -f [float]$latencyResult.AvgReadLat
                $avgWriteLatency = "{0:N0}" -f [float]$latencyResult.AvgWriteLat
                $avgTotalLatency = "{0:N0}" -f [float]$latencyResult.AvgTotalLat
                $avgLatency = [float]$latencyResult.AvgTotalLat

                $avg95thReadLat = "{0:N0}" -f [float]$latencyResult.Avg95thReadLat
                $avg95thWriteLat = "{0:N0}" -f [float]$latencyResult.Avg95thWriteLat
                $avg95thTotalLat= "{0:N0}" -f [float]$latencyResult.Avg95thTotalLat
                $avg95thLat = [float]$latencyResult.Avg95thTotalLat

                $tReadIops = "{0:N0}" -f [float]$latencyResult.ReadIops
                $tWriteIops = "{0:N0}" -f [float]$latencyResult.WriteIops
                $tTotalIops = "{0:N0}" -f [float]$latencyResult.TotalIops

                $blockSize = "{0:N0}" -f [float]$latencyResult.BlockSize
                $writeRatio = "{0:N0}" -f [float]$latencyResult.WriteRatio
                $readRatio = (100 - $writeRatio)

                $resTxt = "Iteration $iteration, Overall-IOPS: (Total: $tTotalIops, Read: $tReadIops, Write: $tWriteIops), AvgLatencyInMsec: (Total: $avgTotalLatency, Read: $avgReadLatency, Write: $avgWriteLatency), Avg95thPercLatencyInMsec: (Total: $avg95thTotalLat, Read: $avg95thReadLat, Write: $avg95thWriteLat), NumberOfVMs: $vmCount, QueueDepth: $qd, NumThreads: $threads, BlockSize: $blockSize, ReadWriteRatio: $readRatio/$writeRatio, AccessPattern: Random"
                $resTxt | Out-File $vmioResultFile -Encoding ASCII -Append
                $resTxt | Out-File $logFilePath -Encoding ASCII -Append

                $nocommaReadIops = "{0:F0}" -f $latencyResult.ReadIops
                $nocommaWriteIops = "{0:F0}" -f $latencyResult.WriteIops
                $nocommaTotalIops = "{0:F0}" -f $latencyResult.TotalIops
                $nocommaBlocksize =  "{0:F0}" -f $latencyResult.BlockSize
                $noFiles = "{0:N0}" -f $DataDisks

                # Add vm boot results to the Azure storage table
                if($storageTable -ne $null) {
                    try {
                        # Summary
                        Add-CsvRow -CSvPath $fixedIopsCsvPath -RunName "FixedIoRun_$FixedIops" -Iteration $iteration -NumberOfVMs $vmCount -QueueDepth $qd -NumberOfThreads $threads -BlockSize $nocommaBlocksize -ReadWriteRatio $readRatio/$writeRatio -AccessPattern "Random" -Total_IOPS $nocommaTotalIops -Read_IOPS $nocommaReadIops -Write_IOPS $nocommaWriteIops -Total_AvgLatency $avgTotalLatency -Read_AvgLatency $avgReadLatency -Write_AvgLatency $avgWriteLatency -Total_95thPercentile_AvgLatency $avg95thTotalLat -Read_95thPercentile_AvgLatency $avg95thReadLat -Write_95thPercentile_AvgLatency $avg95thWriteLat -NumberOfFiles $noFiles
                        Add-TableEntity -Table $storageTable -PartitionKey $executionId -RowKey "FixedIoRun_$FixedIops" -Iteration $iteration -Details $resTxt -NumberOfVMs $vmCount -QueueDepth $qd -NumberOfThreads $threads -BlockSize $blockSize -ReadWriteRatio $readRatio/$writeRatio -AccessPattern "Random" -Total_IOPS $tTotalIops -Read_IOPS $tReadIops -Write_IOPS $tWriteIops -Total_AvgLatency $avgTotalLatency -Read_AvgLatency $avgReadLatency -Write_AvgLatency $avgWriteLatency -Total_95thPercentile_AvgLatency $avg95thTotalLat -Read_95thPercentile_AvgLatency $avg95thReadLat -Write_95thPercentile_AvgLatency $avg95thWriteLat -NumberOfFiles $noFiles
                    } catch {
                        Log-Info -Message "Adding Azure storage table entry for row $vmResultIndex failed. $_"
                    }
                }
                else {
                    Log-Info -Message "Azure storage table object $storageTable is null"
                }

            }
            else {
                Log-Info -Message "IO workload iteration $iteration latency result $latencyResult is null. Cannot continue iterations."
                break
            }
        } catch {
            Log-Info -Message "Failed to parse fixed io run $_"
        }
    }

    "VM IOStorm test finished." | Tee-Object -FilePath $statusFilePath -Append
}

# Function to add a result row to the Azure Storage Table
function Add-TableEntity() {
    [CmdletBinding()]
    param(
        $table,
        [String]$PartitionKey,
        [String]$RowKey,
        [String]$Iteration,
        [String]$Details,
        [String]$NumberOfVMs,
        [String]$CpuUtilization,
        [String]$QueueDepth,
        [String]$NumberOfThreads,
        [String]$BlockSize,
        [String]$ReadWriteRatio,
        [String]$AccessPattern,
        [String]$Total_IOPS,
        [String]$Read_IOPS,
        [String]$Write_IOPS,
        [String]$Total_AvgLatency,
        [String]$Read_AvgLatency,
        [String]$Write_AvgLatency,
        [String]$Total_95thPercentile_AvgLatency,
        [String]$Read_95thPercentile_AvgLatency,
        [String]$Write_95thPercentile_AvgLatency,
        [String]$NumberOfFiles
    )

    if($table -eq $null) {
        Log-Info -Message "Cannot insert entity in null Azure Storage Table"
        Write-Error "Cannot insert entity in null Azure Storage Table"
        return
    }

    $entity = New-Object "Microsoft.WindowsAzure.Storage.Table.DynamicTableEntity" $PartitionKey, $RowKey
    if($entity -eq $null) {
        Log-Info -Message "Cannot insert null entity in Azure Storage Table"
        Write-Error "Cannot insert null entity in Azure Storage Table"
        return
    }
    $entity.Properties.Add("Iteration", $Iteration)
    $entity.Properties.Add("NumberOfThreads", $NumberOfThreads)
    $entity.Properties.Add("QueueDepth", $QueueDepth)
    $entity.Properties.Add("Details", $Details)
    $entity.Properties.Add("NumberofVMs", $NumberOfVMs)
    $entity.Properties.Add("TotalIOPS", $Total_IOPS)
    $entity.Properties.Add("ReadIOPS", $Read_IOPS)
    $entity.Properties.Add("WriteIOPS", $Write_IOPS)
    $entity.Properties.Add("TotalAvgLatency", $Total_AvgLatency)
    $entity.Properties.Add("ReadAvgLatency", $Read_AvgLatency)
    $entity.Properties.Add("WriteAvgLatency", $Write_AvgLatency)
    $entity.Properties.Add("Total95thPercentileAvgLatency", $Total_95thPercentile_AvgLatency)
    $entity.Properties.Add("Read95thPercentileAvgLatency", $Read_95thPercentile_AvgLatency)
    $entity.Properties.Add("Write95thPercentileAvgLatency", $Write_95thPercentile_AvgLatency)
    $entity.Properties.Add("BlockSize", $BlockSize)
    $entity.Properties.Add("ReadWriteRatio", $ReadWriteRatio)
    $entity.Properties.Add("AccessPattern", $AccessPattern)
    $entity.Properties.Add("CpuUtilization", $CpuUtilization)
    $entity.Properties.Add("NumberOfFiles", $NumberOfFiles)

    $result = $null
    try {
        $result = $table.CloudTable.Execute([Microsoft.WindowsAzure.Storage.Table.TableOperation]::InsertOrReplace($entity))
    } catch [Exception] {
        Log-Info -Message "Inserting entity to Azure Storage Table failed with exception $_"
        Write-Error "Inserting entity to Azure Storage Table failed with exception $_"

    }

    return $result
} # End of function Add-TableEntity

function New-CSVHeader() {
    [CmdletBinding()]
    param(
        [String]$CsvPath
    )
    $str = "Run,Iteration,Date,NumberOfVMs,CpuUtilization,QueueDepth,NumberOfThreads,NumberOfFiles,BlockSize,ReadWriteRatio,AccessPattern,Total_IOPS,Read_IOPS,Write_IOPS,Total_AvgLatency,Read_AvgLatency,Write_AvgLatency,Total_95thPercentile_AvgLatency,Read_95thPercentile_AvgLatency,Write_95thPercentile_AvgLatency"
    $str | Out-File $CsvPath -Width 9999 -Append -Encoding ASCII

}

function Add-CSVRow() {
    [CmdletBinding()]
    param(
        [String]$CsvPath,
        [String]$RunName,
        [String]$Iteration,
        [String]$NumberOfVMs,
        [String]$CpuUtilization,
        [String]$QueueDepth,
        [String]$NumberOfThreads,
        [String]$BlockSize,
        [String]$ReadWriteRatio,
        [String]$AccessPattern,
        [String]$Total_IOPS,
        [String]$Read_IOPS,
        [String]$Write_IOPS,
        [String]$Total_AvgLatency,
        [String]$Read_AvgLatency,
        [String]$Write_AvgLatency,
        [String]$Total_95thPercentile_AvgLatency,
        [String]$Read_95thPercentile_AvgLatency,
        [String]$Write_95thPercentile_AvgLatency,
        [String]$NumberOfFiles
    )
    $d = Get-Date
    $str = "$RunName,$Iteration,$d,$NumberOfVMs,$CpuUtilization,$QueueDepth,$NumberOfThreads,$NumberOfFiles,$BlockSize,$ReadWriteRatio,$AccessPattern,$Total_IOPS,$Read_IOPS,$Write_IOPS,$Total_AvgLatency,$Read_AvgLatency,$Write_AvgLatency,$Total_95thPercentile_AvgLatency,$Read_95thPercentile_AvgLatency,$Write_95thPercentile_AvgLatency"
    $str | Out-File $CsvPath -Width 9999 -Append -Encoding ASCII
}

# Analyze diskspd output xml
## COLUMNS ## VM Name    Write Ratio    Threads    Requests    Block Size    Read IOPS    Read Bytes    Write IOPS    Write Bytes    Avg Read (ms)    Avg Write (ms)    Read (ms) - 25%    Write (ms) - 25%    Read (ms) - 50%    Write (ms) - 50%    Read (ms) - 75%    Write (ms) - 75%    Read (ms) 90%    Write (ms) - 90%    Read (ms) - 95%    Write (ms) - 95%    Read (ms) - 99%    Write (ms) - 99%    Read (ms) - 99.9%    Write (ms) - 99.9%    Read (ms) - 100%    Write (ms) - 100%
function DiskspdResultAnalyzeXml {
    param([string]$inputpath=".", [string]$outpath, $storageTable, $executionId, $iteration)

    if($storageTable -eq $null) {
        Log-Info -Message "Storage table is null."
        Write-Error "Storage table is null."
    }

    # Average Read/Write Latency
    $sumAvgReadLatencyForAllXml = 0.0
    $sumAvgWriteLatencyForAllXml = 0.0
    $sumAvgTotalLatencyForAllXml = 0.0
    # 95th Percentile Read/Write Latency
    $sum95thReadLatencyForAllXml = 0.0
    $sum95thWriteLatencyForAllXml = 0.0
    $sum95thTotalLatencyForAllXml = 0.0
    # Average Read/Write IOPS
    $sumAvgReadIopsForAllXml = 0.0
    $sumAvgWriteIopsForAllXml = 0.0
    $totalXml = 0
    # Block Size
    $blockSize = 0
    # Write Ratio
    $writeRatio = 0

    # Header
    if((Test-Path $outpath) -eq $false) {
        "VM Name    Avg CPU Usage    Write Ratio    Threads    Requests    Block Size    Read IOPS    Read Bytes    Write IOPS    Write Bytes    Avg Read (ms)    Avg Write (ms)    Read (ms) - 25%    Write (ms) - 25%    Read (ms) - 50%    Write (ms) - 50%    Read (ms) - 75%    Write (ms) - 75%    Read (ms) 90%    Write (ms) - 90%    Read (ms) - 95%    Write (ms) - 95%    Read (ms) - 99%    Write (ms) - 99%    Read (ms) - 99.9%    Write (ms) - 99.9%    Read (ms) - 100%    Write (ms) - 100%" | out-file $outpath -Encoding ascii -Width 9999 -Append
    }

    $l = @()
    foreach ($i in 25,50,75,90,95,99,99.9,100) { $l += ,[string]$i }

    Get-ChildItem -Path $inputpath -Recurse -Filter *.xml | Sort-Object |% {
        $pwdir = (pwd).Path
        cd $_.Directory.FullName
        $x = [xml](Get-Content $_)

        #$system = $_.Directory.Name + "_" + $x.Results.System.ComputerName
        $vname = $x.Results.System.ComputerName
        $system = $x.Results.System.ComputerName + "_" + $_.Directory.Name
        $t = $x.Results.TimeSpan.TestTimeSeconds

        # Sum of avg read/write latency
        $sumAvgReadLatencyForAllXml += $x.Results.TimeSpan.Latency.AverageReadMilliseconds
        $sumAvgWriteLatencyForAllXml += $x.Results.TimeSpan.Latency.AverageWriteMilliseconds
        $sumAvgTotalLatencyForAllXml += $x.Results.TimeSpan.Latency.AverageTotalMilliseconds
        $totalXml += 1

        # extract the subset of latency percentiles as specified above in $l
        $h = @{}
        $x.Results.TimeSpan.Latency.Bucket |% { $h[$_.Percentile] = $_ }

        $ls = $l |% {
            $b = $h[$_]
            if ($b.ReadMilliseconds) { $b.ReadMilliseconds } else { "" }
            if ($b.WriteMilliseconds) { $b.WriteMilliseconds } else { "" }
        }

        # Sum of 95th percentile read/write latency
        $lat95th = $h[[string]95]
        if($lat95th.ReadMilliseconds) { $sum95thReadLatencyForAllXml += $lat95th.ReadMilliseconds }
        if($lat95th.WriteMilliseconds) { $sum95thWriteLatencyForAllXml += $lat95th.WriteMilliseconds }
        if($lat95th.TotalMilliseconds) { $sum95thTotalLatencyForAllXml += $lat95th.TotalMilliseconds }

        # sum read and write iops across all threads and targets
        $ri = ($x.Results.TimeSpan.Thread.Target |
                measure -sum -Property ReadCount).Sum
        $wi = ($x.Results.TimeSpan.Thread.Target |
                measure -sum -Property WriteCount).Sum
        $rb = ($x.Results.TimeSpan.Thread.Target |
                measure -sum -Property ReadBytes).Sum
        $wb = ($x.Results.TimeSpan.Thread.Target |
                measure -sum -Property WriteBytes).Sum

        # Block size
        $blockSize = ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property BlockSize).Sum / ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property BlockSize).Count
        $writeRatio = ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property WriteRatio).Sum / ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property WriteRatio).Count
        $readRatio = (100 - $writeRatio)
        $threadCount = $x.Results.TimeSpan.ThreadCount #($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property ThreadCount).Sum / ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property ThreadCount).Count
        $qd = ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property RequestCount).Sum / ($x.Results.Profile.TimeSpans.TimeSpan.Targets.Target | Measure -Sum -Property RequestCount).Count
        $cpuUtilization = $x.Results.TimeSpan.CpuUtilization.Average.UsagePercent

        # Add VM stats in Azure Table
        try {
            Add-TableEntity -table $storageTable -PartitionKey $executionId -RowKey "$vname-Iteration-$iteration" -Iteration $iteration -CpuUtilization $cpuUtilization -QueueDepth $qd -NumberOfThreads $threadCount -BlockSize $blockSize -ReadWriteRatio $readRatio/$writeRatio -AccessPattern "Random" -Total_IOPS ("{0:N0}" -f [float](($ri / $t) + ($wi / $t))) -Read_IOPS ("{0:N0}" -f [float]($ri / $t)) -Write_IOPS ("{0:N0}" -f [float]($wi / $t)) -Total_AvgLatency ("{0:N0}" -f [float]($x.Results.TimeSpan.Latency.AverageTotalMilliseconds)) -Read_AvgLatency  ("{0:N0}" -f [float]($x.Results.TimeSpan.Latency.AverageReadMilliseconds)) -Write_AvgLatency ("{0:N0}" -f [float]($x.Results.TimeSpan.Latency.AverageWriteMilliseconds)) -Total_95thPercentile_AvgLatency ("{0:N0}" -f [float]($lat95th.TotalMilliseconds)) -Read_95thPercentile_AvgLatency ("{0:N0}" -f [float]($lat95th.ReadMilliseconds)) -Write_95thPercentile_AvgLatency ("{0:N0}" -f [float]($lat95th.WriteMilliseconds))
        } catch [Exception] {
            Log-Info -Message "Exception in adding Azure Storage Table entry. $_"
            Write-Error "Exception in adding Azure Storage Table entry. $_"
        }

        # Sum of avg of read/write iops
        $sumAvgReadIopsForAllXml += ($ri / $t)
        $sumAvgWriteIopsForAllXml += ($wi / $t)

        # output tab-separated fields. note that with runs specified on the command
        # line, only a single write ratio, outstanding request count and blocksize
        # can be specified, so sampling the one used for the first thread is
        # sufficient.
        (($system,
            $x.Results.TimeSpan.CpuUtilization.Average.UsagePercent,
            $x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.WriteRatio,
            $x.Results.TimeSpan.ThreadCount,
            $x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.RequestCount,
            $x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.BlockSize,
            # calculate iops
            ($ri / $t),
            ($rb / $t),
            ($wi / $t),
            ($wb / $t),
            $x.Results.TimeSpan.Latency.AverageReadMilliseconds,
            $x.Results.TimeSpan.Latency.AverageWriteMilliseconds
            ) -join "`t"),
        ($ls -join "`t") -join "`t"
        cd $pwdir
    } | out-file $outpath -Encoding ASCII -Width 9999 -Append

    $avgAvgReadLatencyForAllXml = $sumAvgReadLatencyForAllXml/$totalXml
    $avgAvgWriteLatencyForAllXml = $sumAvgWriteLatencyForAllXml/$totalXml
    $avgAvgTotalLatencyForAllXml = $sumAvgTotalLatencyForAllXml/$totalXml

    $avg95thReadLatencyForAllXml = $sum95thReadLatencyForAllXml/$totalXml
    $avg95thWriteLatencyForAllXml = $sum95thWriteLatencyForAllXml/$totalXml
    $avg95thTotalLatencyForAllXml = $sum95thTotalLatencyForAllXml/$totalXml

    # Create custom latency and iops result object
    $customResult = "" | Select-Object AvgReadLat, AvgWriteLat, AvgTotalLat, Avg95thReadLat, Avg95thWriteLat, Avg95thTotalLat, ReadIops, WriteIops, TotalIops, BlockSize, WriteRatio, VmCount
    $customResult.AvgReadLat = $avgAvgReadLatencyForAllXml
    $customResult.AvgWriteLat = $avgAvgWriteLatencyForAllXml
    $customResult.AvgTotalLat = $avgAvgTotalLatencyForAllXml
    $customResult.Avg95thReadLat = $avg95thReadLatencyForAllXml
    $customResult.Avg95thWriteLat = $avg95thWriteLatencyForAllXml
    $customResult.Avg95thTotalLat = $avg95thTotalLatencyForAllXml
    $customResult.ReadIops = $sumAvgReadIopsForAllXml
    $customResult.WriteIops = $sumAvgWriteIopsForAllXml
    $customResult.TotalIops = ($sumAvgReadIopsForAllXml + $sumAvgWriteIopsForAllXml)
    $customResult.BlockSize = $blockSize
    $customResult.WriteRatio = $writeRatio
    $customResult.VmCount = $totalXml
    return $customResult
} # End function DiskspdResultAnalyzeXml

function CreateHtmlSummary
{
    param
    (
        [Parameter(Mandatory)]
        $ResultSummary

    )
    # After each upload, create a new summary html file of all current results that have been uploaded to the table
    $summaryLog = $env:Temp + "\TableResultSummary.log"

    $fileName = "IoStormResults.html"
    $filePath = $env:Temp + "\" + $fileName

    #create html file
    try {
        "Creating HTML file" | Out-File -FilePath $summaryLog -Append -Width 10000
        $resTable = @()

        #header
        $style = "<style>"
        $style +=  "TABLE{border-width: 1px;border-style: solid;border-color: black;border-collapse: collapse;}"
        $style +=  "TH{border-width: 1px;padding: 2px;border-style: solid;border-color: black;}"
        $style +=  "TD{border-width: 1px;padding: 2px;border-style: solid;border-color: black;}"
        $style +=  "</style>"

        foreach($res in $ResultSummary) {
            $resBlob = New-Object System.Object

            $resBlob | Add-Member -type NoteProperty -name "QD" -value $res.totalQD
            $roundedVal = [math]::Round($res.summary.TotalIops)
            $resBlob | Add-Member -type NoteProperty -name "Total IOPS" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.AvgTotalLat)
            $resBlob | Add-Member -type NoteProperty -name "Average Total Latency" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.Avg95thTotalLat)
            $resBlob | Add-Member -type NoteProperty -name "Average 95th Total Latency" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.ReadIops)
            $resBlob | Add-Member -type NoteProperty -name "Read IOPS" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.AvgReadLat)
            $resBlob | Add-Member -type NoteProperty -name "Average Read Latency" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.Avg95thReadLat)
            $resBlob | Add-Member -type NoteProperty -name "Average 95th Read Latency" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.WriteIops)
            $resBlob | Add-Member -type NoteProperty -name "Write IOPS" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.AvgWriteLat)
            $resBlob | Add-Member -type NoteProperty -name "Average Write Latency" -value $roundedVal
            $roundedVal = [math]::Round($res.summary.Avg95thTotalLat)
            $resBlob | Add-Member -type NoteProperty -name "Average 95th Write Latency" -value $roundedVal

            $resBlob | Add-Member -type NoteProperty -name "Threads" -value $res.threads
            $resBlob | Add-Member -type NoteProperty -name "Operations" -value $res.ops
            $resBlob | Add-Member -type NoteProperty -name "VMs" -value $res.vmCount
            $resTable += $resBlob
        }

        $results = $resTable |  ConvertTo-HTML -Head $style
        $results | Out-File -FilePath $filePath -Encoding ASCII
        Log-Info -Message "Done creating HTML file"

    }
    catch {
        Log-Info -Message "Error generating summary html $filePath $_"
        Write-Error "Error generating summary html $filePath $_"
    }
    return $filePath
}

function IsAzureStack
{
    param
    (
        [Parameter(Mandatory)]
        $Location
    )
    if($Location -eq "AzureCloud" -or $Location -eq "AzureChinaCloud" -or $Location -eq "AzureUSGovernment"  -or $Location -eq "AzureGermanCloud") {
        return $false
    }
    return $true

}
function Log-Info
{
    param (
        [string]$Message
    )
    $str = "$(Get-Date) $Message"
    Write-Host $str
    $str | Out-File -FilePath $global:LogFilePath -Encoding ASCII -Width 999 -Append
}
VMIOController

# SIG # Begin signature block
# MIIjkgYJKoZIhvcNAQcCoIIjgzCCI38CAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBVrjeTGcVPTFEk
# qZ9eLTGun1uHgL4GDdLSyrt4jbS9/qCCDYEwggX/MIID56ADAgECAhMzAAACUosz
# qviV8znbAAAAAAJSMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjEwOTAyMTgzMjU5WhcNMjIwOTAxMTgzMjU5WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQDQ5M+Ps/X7BNuv5B/0I6uoDwj0NJOo1KrVQqO7ggRXccklyTrWL4xMShjIou2I
# sbYnF67wXzVAq5Om4oe+LfzSDOzjcb6ms00gBo0OQaqwQ1BijyJ7NvDf80I1fW9O
# L76Kt0Wpc2zrGhzcHdb7upPrvxvSNNUvxK3sgw7YTt31410vpEp8yfBEl/hd8ZzA
# v47DCgJ5j1zm295s1RVZHNp6MoiQFVOECm4AwK2l28i+YER1JO4IplTH44uvzX9o
# RnJHaMvWzZEpozPy4jNO2DDqbcNs4zh7AWMhE1PWFVA+CHI/En5nASvCvLmuR/t8
# q4bc8XR8QIZJQSp+2U6m2ldNAgMBAAGjggF+MIIBejAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUNZJaEUGL2Guwt7ZOAu4efEYXedEw
# UAYDVR0RBEkwR6RFMEMxKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVyYXRpb25zIFB1
# ZXJ0byBSaWNvMRYwFAYDVQQFEw0yMzAwMTIrNDY3NTk3MB8GA1UdIwQYMBaAFEhu
# ZOVQBdOCqhc3NyK1bajKdQKVMFQGA1UdHwRNMEswSaBHoEWGQ2h0dHA6Ly93d3cu
# bWljcm9zb2Z0LmNvbS9wa2lvcHMvY3JsL01pY0NvZFNpZ1BDQTIwMTFfMjAxMS0w
# Ny0wOC5jcmwwYQYIKwYBBQUHAQEEVTBTMFEGCCsGAQUFBzAChkVodHRwOi8vd3d3
# Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2NlcnRzL01pY0NvZFNpZ1BDQTIwMTFfMjAx
# MS0wNy0wOC5jcnQwDAYDVR0TAQH/BAIwADANBgkqhkiG9w0BAQsFAAOCAgEAFkk3
# uSxkTEBh1NtAl7BivIEsAWdgX1qZ+EdZMYbQKasY6IhSLXRMxF1B3OKdR9K/kccp
# kvNcGl8D7YyYS4mhCUMBR+VLrg3f8PUj38A9V5aiY2/Jok7WZFOAmjPRNNGnyeg7
# l0lTiThFqE+2aOs6+heegqAdelGgNJKRHLWRuhGKuLIw5lkgx9Ky+QvZrn/Ddi8u
# TIgWKp+MGG8xY6PBvvjgt9jQShlnPrZ3UY8Bvwy6rynhXBaV0V0TTL0gEx7eh/K1
# o8Miaru6s/7FyqOLeUS4vTHh9TgBL5DtxCYurXbSBVtL1Fj44+Od/6cmC9mmvrti
# yG709Y3Rd3YdJj2f3GJq7Y7KdWq0QYhatKhBeg4fxjhg0yut2g6aM1mxjNPrE48z
# 6HWCNGu9gMK5ZudldRw4a45Z06Aoktof0CqOyTErvq0YjoE4Xpa0+87T/PVUXNqf
# 7Y+qSU7+9LtLQuMYR4w3cSPjuNusvLf9gBnch5RqM7kaDtYWDgLyB42EfsxeMqwK
# WwA+TVi0HrWRqfSx2olbE56hJcEkMjOSKz3sRuupFCX3UroyYf52L+2iVTrda8XW
# esPG62Mnn3T8AuLfzeJFuAbfOSERx7IFZO92UPoXE1uEjL5skl1yTZB3MubgOA4F
# 8KoRNhviFAEST+nG8c8uIsbZeb08SeYQMqjVEmkwggd6MIIFYqADAgECAgphDpDS
# AAAAAAADMA0GCSqGSIb3DQEBCwUAMIGIMQswCQYDVQQGEwJVUzETMBEGA1UECBMK
# V2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0
# IENvcnBvcmF0aW9uMTIwMAYDVQQDEylNaWNyb3NvZnQgUm9vdCBDZXJ0aWZpY2F0
# ZSBBdXRob3JpdHkgMjAxMTAeFw0xMTA3MDgyMDU5MDlaFw0yNjA3MDgyMTA5MDla
# MH4xCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdS
# ZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMT
# H01pY3Jvc29mdCBDb2RlIFNpZ25pbmcgUENBIDIwMTEwggIiMA0GCSqGSIb3DQEB
# AQUAA4ICDwAwggIKAoICAQCr8PpyEBwurdhuqoIQTTS68rZYIZ9CGypr6VpQqrgG
# OBoESbp/wwwe3TdrxhLYC/A4wpkGsMg51QEUMULTiQ15ZId+lGAkbK+eSZzpaF7S
# 35tTsgosw6/ZqSuuegmv15ZZymAaBelmdugyUiYSL+erCFDPs0S3XdjELgN1q2jz
# y23zOlyhFvRGuuA4ZKxuZDV4pqBjDy3TQJP4494HDdVceaVJKecNvqATd76UPe/7
# 4ytaEB9NViiienLgEjq3SV7Y7e1DkYPZe7J7hhvZPrGMXeiJT4Qa8qEvWeSQOy2u
# M1jFtz7+MtOzAz2xsq+SOH7SnYAs9U5WkSE1JcM5bmR/U7qcD60ZI4TL9LoDho33
# X/DQUr+MlIe8wCF0JV8YKLbMJyg4JZg5SjbPfLGSrhwjp6lm7GEfauEoSZ1fiOIl
# XdMhSz5SxLVXPyQD8NF6Wy/VI+NwXQ9RRnez+ADhvKwCgl/bwBWzvRvUVUvnOaEP
# 6SNJvBi4RHxF5MHDcnrgcuck379GmcXvwhxX24ON7E1JMKerjt/sW5+v/N2wZuLB
# l4F77dbtS+dJKacTKKanfWeA5opieF+yL4TXV5xcv3coKPHtbcMojyyPQDdPweGF
# RInECUzF1KVDL3SV9274eCBYLBNdYJWaPk8zhNqwiBfenk70lrC8RqBsmNLg1oiM
# CwIDAQABo4IB7TCCAekwEAYJKwYBBAGCNxUBBAMCAQAwHQYDVR0OBBYEFEhuZOVQ
# BdOCqhc3NyK1bajKdQKVMBkGCSsGAQQBgjcUAgQMHgoAUwB1AGIAQwBBMAsGA1Ud
# DwQEAwIBhjAPBgNVHRMBAf8EBTADAQH/MB8GA1UdIwQYMBaAFHItOgIxkEO5FAVO
# 4eqnxzHRI4k0MFoGA1UdHwRTMFEwT6BNoEuGSWh0dHA6Ly9jcmwubWljcm9zb2Z0
# LmNvbS9wa2kvY3JsL3Byb2R1Y3RzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcmwwXgYIKwYBBQUHAQEEUjBQME4GCCsGAQUFBzAChkJodHRwOi8vd3d3Lm1p
# Y3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dDIwMTFfMjAxMV8wM18y
# Mi5jcnQwgZ8GA1UdIASBlzCBlDCBkQYJKwYBBAGCNy4DMIGDMD8GCCsGAQUFBwIB
# FjNodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpb3BzL2RvY3MvcHJpbWFyeWNw
# cy5odG0wQAYIKwYBBQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AcABvAGwAaQBjAHkA
# XwBzAHQAYQB0AGUAbQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAGfyhqWY
# 4FR5Gi7T2HRnIpsLlhHhY5KZQpZ90nkMkMFlXy4sPvjDctFtg/6+P+gKyju/R6mj
# 82nbY78iNaWXXWWEkH2LRlBV2AySfNIaSxzzPEKLUtCw/WvjPgcuKZvmPRul1LUd
# d5Q54ulkyUQ9eHoj8xN9ppB0g430yyYCRirCihC7pKkFDJvtaPpoLpWgKj8qa1hJ
# Yx8JaW5amJbkg/TAj/NGK978O9C9Ne9uJa7lryft0N3zDq+ZKJeYTQ49C/IIidYf
# wzIY4vDFLc5bnrRJOQrGCsLGra7lstnbFYhRRVg4MnEnGn+x9Cf43iw6IGmYslmJ
# aG5vp7d0w0AFBqYBKig+gj8TTWYLwLNN9eGPfxxvFX1Fp3blQCplo8NdUmKGwx1j
# NpeG39rz+PIWoZon4c2ll9DuXWNB41sHnIc+BncG0QaxdR8UvmFhtfDcxhsEvt9B
# xw4o7t5lL+yX9qFcltgA1qFGvVnzl6UJS0gQmYAf0AApxbGbpT9Fdx41xtKiop96
# eiL6SJUfq/tHI4D1nvi/a7dLl+LrdXga7Oo3mXkYS//WsyNodeav+vyL6wuA6mk7
# r/ww7QRMjt/fdW1jkT3RnVZOT7+AVyKheBEyIXrvQQqxP/uozKRdwaGIm1dxVk5I
# RcBCyZt2WwqASGv9eZ/BvW1taslScxMNelDNMYIVZzCCFWMCAQEwgZUwfjELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEoMCYGA1UEAxMfTWljcm9z
# b2Z0IENvZGUgU2lnbmluZyBQQ0EgMjAxMQITMwAAAlKLM6r4lfM52wAAAAACUjAN
# BglghkgBZQMEAgEFAKCBrjAZBgkqhkiG9w0BCQMxDAYKKwYBBAGCNwIBBDAcBgor
# BgEEAYI3AgELMQ4wDAYKKwYBBAGCNwIBFTAvBgkqhkiG9w0BCQQxIgQgwZjduBws
# MY0UsJib6sagpaD3z/96fRpVuz9Nx5WcvAYwQgYKKwYBBAGCNwIBDDE0MDKgFIAS
# AE0AaQBjAHIAbwBzAG8AZgB0oRqAGGh0dHA6Ly93d3cubWljcm9zb2Z0LmNvbTAN
# BgkqhkiG9w0BAQEFAASCAQDM10T7Yz3KajvpgfUXm1y9Pc82Xfx44sNF+l8Lde/i
# 7s4durXIPKNqbmEhJd84Sd0GqynS2uwINscngAROCUb/30wh9cbwMy7hfntri4ck
# KFUlsLWgre1aY8jsORnXxFkNvb1OvsqoLapg0XMz5F8Po6agompI8gGf/PIZEs8m
# Pa3uiPpypeNLnrSL/6q48cE8/2IMKabig8tyrIHyngQCmIx4L8c7pOz1eF2rgcYl
# 71GrQQaEAOkQqYAvrN6+REyjIHblpVbULyaX/nX0puQ2Vyk39iWRZtvraijyeemm
# oODJyMkjDs0ML26AdZ4BNBMzAyZYvinvVvwh/eJgwslboYIS8TCCEu0GCisGAQQB
# gjcDAwExghLdMIIS2QYJKoZIhvcNAQcCoIISyjCCEsYCAQMxDzANBglghkgBZQME
# AgEFADCCAVUGCyqGSIb3DQEJEAEEoIIBRASCAUAwggE8AgEBBgorBgEEAYRZCgMB
# MDEwDQYJYIZIAWUDBAIBBQAEILVFcWr0/kyLE7JqapAezSIaEjMcD9pWMLojWFDq
# ABLyAgZhk95XKL4YEzIwMjExMjEwMDk1MTAyLjUwN1owBIACAfSggdSkgdEwgc4x
# CzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRt
# b25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1p
# Y3Jvc29mdCBPcGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMg
# VFNTIEVTTjpEOURFLUUzOUEtNDNGRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUt
# U3RhbXAgU2VydmljZaCCDkQwggT1MIID3aADAgECAhMzAAABYfWiM16gKiRpAAAA
# AAFhMA0GCSqGSIb3DQEBCwUAMHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNo
# aW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29y
# cG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEw
# MB4XDTIxMDExNDE5MDIyMVoXDTIyMDQxMTE5MDIyMVowgc4xCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBPcGVy
# YXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpEOURF
# LUUzOUEtNDNGRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vydmlj
# ZTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAJeInahBrU//GzTqhxUy
# AC8UXct6UJCkb2xEZKV3gjggmLAheBrxJk7tH+Pw2tTcyarLRfmV2xo5oBk5pW/O
# cDc/n/TcTeQU6JIN5PlTcn0C9RlKQ6t9OuU/WAyAxGTjKE4ENnUjXtxiNlD/K2ZG
# MLvjpROBKh7TtkUJK6ZGWw/uTRabNBxRg13TvjkGHXEUEDJ8imacw9BCeR9L6und
# r32tj4duOFIHD8m1es3SNN98Zq4IDBP3Ccb+HQgxpbeHIUlK0y6zmzIkvfN73Zxw
# fGvFv0/Max79WJY0cD8poCnZFijciWrf0eD1T2/+7HgewzrdxPdSFockUQ8QovID
# IYkCAwEAAaOCARswggEXMB0GA1UdDgQWBBRWHpqd1hv71SVj5LAdPfNE7PhLLzAf
# BgNVHSMEGDAWgBTVYzpcijGQ80N7fEYbxTNoWoVtVTBWBgNVHR8ETzBNMEugSaBH
# hkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2NybC9wcm9kdWN0cy9NaWNU
# aW1TdGFQQ0FfMjAxMC0wNy0wMS5jcmwwWgYIKwYBBQUHAQEETjBMMEoGCCsGAQUF
# BzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vcGtpL2NlcnRzL01pY1RpbVN0
# YVBDQV8yMDEwLTA3LTAxLmNydDAMBgNVHRMBAf8EAjAAMBMGA1UdJQQMMAoGCCsG
# AQUFBwMIMA0GCSqGSIb3DQEBCwUAA4IBAQAQTA9bqVBmx5TTMhzj+Q8zWkPQXgCc
# SQiqy2YYWF0hWr5GEiN2LtA+EWdu1y8oysZau4CP7SzM8VTSq31CLJiOy39Z4RvE
# q2mr0EftFvmX2CxQ7ZyzrkhWMZaZQLkYbH5oabIFwndW34nh980BOY395tfnNS/Y
# 6N0f+jXdoFn7fI2c43TFYsUqIPWjOHJloMektlD6/uS6Zn4xse/lItFm+fWOcB2A
# xyXEB3ZREeSg9j7+GoEl1xT/iJuV/So7TlWdwyacQu4lv3MBsvxzRIbKhZwrDYog
# moyJ+rwgQB8mKS4/M1SDRtIptamoTFJ56Tk6DuUXx1JudToelgjEZPa5MIIGcTCC
# BFmgAwIBAgIKYQmBKgAAAAAAAjANBgkqhkiG9w0BAQsFADCBiDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJv
# b3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5IDIwMTAwHhcNMTAwNzAxMjEzNjU1WhcN
# MjUwNzAxMjE0NjU1WjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3Rv
# bjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0
# aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDCCASIw
# DQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBAKkdDbx3EYo6IOz8E5f1+n9plGt0
# VBDVpQoAgoX77XxoSyxfxcPlYcJ2tz5mK1vwFVMnBDEfQRsalR3OCROOfGEwWbEw
# RA/xYIiEVEMM1024OAizQt2TrNZzMFcmgqNFDdDq9UeBzb8kYDJYYEbyWEeGMoQe
# dGFnkV+BVLHPk0ySwcSmXdFhE24oxhr5hoC732H8RsEnHSRnEnIaIYqvS2SJUGKx
# Xf13Hz3wV3WsvYpCTUBR0Q+cBj5nf/VmwAOWRH7v0Ev9buWayrGo8noqCjHw2k4G
# kbaICDXoeByw6ZnNPOcvRLqn9NxkvaQBwSAJk3jN/LzAyURdXhacAQVPIk0CAwEA
# AaOCAeYwggHiMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBTVYzpcijGQ80N7
# fEYbxTNoWoVtVTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMC
# AYYwDwYDVR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBTV9lbLj+iiXGJo0T2UkFvX
# zpoYxDBWBgNVHR8ETzBNMEugSaBHhkVodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20v
# cGtpL2NybC9wcm9kdWN0cy9NaWNSb29DZXJBdXRfMjAxMC0wNi0yMy5jcmwwWgYI
# KwYBBQUHAQEETjBMMEoGCCsGAQUFBzAChj5odHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpL2NlcnRzL01pY1Jvb0NlckF1dF8yMDEwLTA2LTIzLmNydDCBoAYDVR0g
# AQH/BIGVMIGSMIGPBgkrBgEEAYI3LgMwgYEwPQYIKwYBBQUHAgEWMWh0dHA6Ly93
# d3cubWljcm9zb2Z0LmNvbS9QS0kvZG9jcy9DUFMvZGVmYXVsdC5odG0wQAYIKwYB
# BQUHAgIwNB4yIB0ATABlAGcAYQBsAF8AUABvAGwAaQBjAHkAXwBTAHQAYQB0AGUA
# bQBlAG4AdAAuIB0wDQYJKoZIhvcNAQELBQADggIBAAfmiFEN4sbgmD+BcQM9naOh
# IW+z66bM9TG+zwXiqf76V20ZMLPCxWbJat/15/B4vceoniXj+bzta1RXCCtRgkQS
# +7lTjMz0YBKKdsxAQEGb3FwX/1z5Xhc1mCRWS3TvQhDIr79/xn/yN31aPxzymXlK
# kVIArzgPF/UveYFl2am1a+THzvbKegBvSzBEJCI8z+0DpZaPWSm8tv0E4XCfMkon
# /VWvL/625Y4zu2JfmttXQOnxzplmkIz/amJ/3cVKC5Em4jnsGUpxY517IW3DnKOi
# PPp/fZZqkHimbdLhnPkd/DjYlPTGpQqWhqS9nhquBEKDuLWAmyI4ILUl5WTs9/S/
# fmNZJQ96LjlXdqJxqgaKD4kWumGnEcua2A5HmoDF0M2n0O99g/DhO3EJ3110mCII
# YdqwUB5vvfHhAN/nMQekkzr3ZUd46PioSKv33nJ+YWtvd6mBy6cJrDm77MbL2IK0
# cs0d9LiFAR6A+xuJKlQ5slvayA1VmXqHczsI5pgt6o3gMy4SKfXAL1QnIffIrE7a
# KLixqduWsqdCosnPGUFN4Ib5KpqjEWYw07t0MkvfY3v1mYovG8chr1m1rtxEPJdQ
# cdeh0sVV42neV8HR3jDA/czmTfsNv11P6Z0eGTgvvM9YBS7vDaBQNdrvCScc1bN+
# NR4Iuto229Nfj950iEkSoYIC0jCCAjsCAQEwgfyhgdSkgdEwgc4xCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xKTAnBgNVBAsTIE1pY3Jvc29mdCBP
# cGVyYXRpb25zIFB1ZXJ0byBSaWNvMSYwJAYDVQQLEx1UaGFsZXMgVFNTIEVTTjpE
# OURFLUUzOUEtNDNGRTElMCMGA1UEAxMcTWljcm9zb2Z0IFRpbWUtU3RhbXAgU2Vy
# dmljZaIjCgEBMAcGBSsOAwIaAxUAFW5ShAw5ekTEXvL/4V1s0rbDz3mggYMwgYCk
# fjB8MQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMH
# UmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQD
# Ex1NaWNyb3NvZnQgVGltZS1TdGFtcCBQQ0EgMjAxMDANBgkqhkiG9w0BAQUFAAIF
# AOVdV3IwIhgPMjAyMTEyMTAwODM0NThaGA8yMDIxMTIxMTA4MzQ1OFowdzA9Bgor
# BgEEAYRZCgQBMS8wLTAKAgUA5V1XcgIBADAKAgEAAgIRKwIB/zAHAgEAAgIRHTAK
# AgUA5V6o8gIBADA2BgorBgEEAYRZCgQCMSgwJjAMBgorBgEEAYRZCgMCoAowCAIB
# AAIDB6EgoQowCAIBAAIDAYagMA0GCSqGSIb3DQEBBQUAA4GBAJQdN0SuSSnrrymV
# aRTeo3R0ec1B6/QmPFD+LXSLZbwtZ9x2GdsKnUXpiQruUFhk9Kdqv4+dFJHwLnrf
# Xb4dmkJxWBkJEk7O214Lttfrp0m8SASDKudWFzaMJNg8ERd4aNG1XTAxQXVspMTx
# eiswXictNsIi9iItfT1CCux41MpmMYIDDTCCAwkCAQEwgZMwfDELMAkGA1UEBhMC
# VVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNV
# BAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRp
# bWUtU3RhbXAgUENBIDIwMTACEzMAAAFh9aIzXqAqJGkAAAAAAWEwDQYJYIZIAWUD
# BAIBBQCgggFKMBoGCSqGSIb3DQEJAzENBgsqhkiG9w0BCRABBDAvBgkqhkiG9w0B
# CQQxIgQgOFMvD/7FnUkTtzNyIDqrO+ghfupfYJxL3sOOg/hCVdEwgfoGCyqGSIb3
# DQEJEAIvMYHqMIHnMIHkMIG9BCBhz4un6mkSLd/zA+0N5YLDGp4vW/VBtNW/lpmh
# tAk4bzCBmDCBgKR+MHwxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9u
# MRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9yYXRp
# b24xJjAkBgNVBAMTHU1pY3Jvc29mdCBUaW1lLVN0YW1wIFBDQSAyMDEwAhMzAAAB
# YfWiM16gKiRpAAAAAAFhMCIEIMs1PJrNterdz2A+Yp84gycKIkEIfnZ4uirUuiBd
# NVZpMA0GCSqGSIb3DQEBCwUABIIBADPZFhBheO807WVl5lO6MnxoUcvz1ncYnrLI
# ip69k4+i9+e/qMTLEXoG+KmmvD3hISsYl032LaAma8C2p22Nxz3ZbYl9wniSDXnQ
# s/jaVhUmoKSFzTSJegI839XPGclu1j+v53OxSgWuckjQSxfPhagkqQR8oiuJsH8a
# 6HPzqMOOaCoKAnxPjyeD39R2mfVDduax1AtGWlGjn/0TJ7XLV5J6nnLrv6rZzAz1
# T8gAsY1h22VqjnCjhgaxbSqVxoWvsFZi5JFa4zm0/2d+D/QT/aA7uGarTl/vg2L7
# gfQWq9u3WUK/Tw2i46au9zgic5nbTjLV4M1SCj5HCzvJtxPVJbE=
# SIG # End signature block
