
param (
	[Parameter(Mandatory)]
    [string]$AzureUserName,
	[Parameter(Mandatory)]
    [string]$AzurePassword,
    [Parameter(Mandatory)]
	[string]$AzureApplicationId = "https://azurestack.local-api/",
	[Parameter(Mandatory)]
	[string]$TenantId = "7ea3e2b7-334d-4083-807b-fa2000faa9b8",
	[Parameter(Mandatory)]
	[string]$VMName,
	[Parameter(Mandatory)]
	[int32]$VMCount,
	[Parameter(Mandatory)]
	[string]$AzureStorageAccount
)
# Creates smb share '$smbshare' (e.g. \\10.0.0.6\smbshare\) to store results, pre-sync and post-sync iostorm signal
# Creates pre-sync directory '$ioPreSyncShare' (e.g. \\10.0.0.6\smbshare\iopresync\) where all VMs saves a file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate they are up and waiting to start a workload
# Creates a '$ioPreSyncSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) to signal all VMs to start io workload
# Waits for io workload results to arrive from all VMs in io result directory '$ioResultShare' (e.g. \\10.0.0.6\smbshare\ioresult\)
# Uploads io workload result to VMIOResult.log.ps1 to Azure Portal Storage Accounts Blob
function VMIOController {

	$azureUserName = $AzureUserName;
	$azurePassword = $AzurePassword;
    $applicationId = $AzureApplicationId;
	$tenant = $TenantId;
	$vmName = $VMName;
	$vmCount = $VMCount;
	$storageAccount = $AzureStorageAccount;
	
	# Local file storage location
	$localPath = "$env:SystemDrive";

	# Log file
	$logFileName = "VMWorkloadController.log";
	$logFilePath = "$localPath\$logFileName";
	
	# Turn off private firewall
	netsh advfirewall set privateprofile state off;
	
	# Create result SMB share
	$smbshare = "$env:SystemDrive\smbshare";
	echo "Creating result smb share $smbshare" >> $logFilePath;
	New-Item -Path $smbshare -Type Directory -Force -Confirm:0;
	if((Get-SMBShare -Name smbshare -ErrorAction SilentlyContinue) -eq $null) {
		New-SMBShare -Path $smbshare -Name smbshare -FullAccess Everyone;
	}

	# Create io workload pre-sync directory
	$ioPreSyncShare = "$smbshare\iopresync";
	echo "Creating io pre-sync share $ioPreSyncShare" >> $logFilePath;
	New-Item -Path $ioPreSyncShare -Type Directory -Force -Confirm:0;

	# Sync signal to start io pre-sync from controller vm
	$ioPreSyncStartSignalFile = "$smbshare\iopresyncstart.txt";

	# IO workload pre-sync success signal file
	$ioPreSyncSignalFile = "$smbshare\iopresyncsucceed.txt";

	# Log directory
	$logShare = "$smbshare\logs";
	echo "Creating logs share $logShare" >> $logFilePath;
	New-Item -Path $logShare -Type Directory -Force -Confirm:0;

	# Create io result directory
	$ioResultShare = "$smbshare\ioresult";
	echo "Creating io result share $ioResultShare" >> $logFilePath;
	New-Item -Path $ioResultShare -Type Directory -Force -Confirm:0;
	
	# PS Credentials
	$pw = ConvertTo-SecureString -AsPlainText -Force -String $azurePassword;
	$pscred = New-Object -TypeName System.Management.Automation.PSCredential -argumentlist $azureUserName,$pw;
	if($pscred -eq $null) {
		Write-Host "Powershell Credential object is null. Cannot proceed.";
		return;
	}
	$azureCreds = Get-Credential -Credential $pscred;
	if($azureCreds -eq $null) {
		Write-Host "Get-Credential returned null. Cannot proceed.";
		return;
	}
	
	######################
	### AZURE RM SETUP ###
	######################
	# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
	add-type @"
	using System.Net;
	using System.Security.Cryptography.X509Certificates;
	public class TrustAllCertsPolicy : ICertificatePolicy {
		public bool CheckValidationResult(
			ServicePoint srvPoint, X509Certificate certificate,
			WebRequest request, int certificateProblem) {
			return true;
		}
	}
"@
	[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
	Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"
	
	# Import Azure Resource Manager PS module if already present
	try {
		Write-Host "Importing Azure RM";
		echo "Importing Azure RM" >> $logFilePath;
		Import-AzureRM;
	}
	# Install Azure Resource Manager PS module
	catch {
		Write-Host "Cannot import Azure RM module, proceeding with installation";
		echo "Installing Azure RM" >> $logFilePath;

		# Suppress prompts
		$ConfirmPreference = 'None';

		# Install AzureRM
		Get-PackageProvider -Name nuget -ForceBootstrap �Force;
		Install-Module Azure �repository PSGallery �Force -Confirm:0;
		Install-Module AzureRM �repository PSGallery �Force -Confirm:0;
		Install-AzureRm;
	}

	# Authenticate to AzureStack
    Add-AzureRmEnvironment -Name 'AzureStack' -ActiveDirectoryEndpoint ("https://login.windows.net/$tenant/") -ActiveDirectoryServiceEndpointResourceId $applicationId `
        -ResourceManagerEndpoint ("https://api.azurestack.local/") -GalleryEndpoint ("https://gallery.azurestack.local:30016/") -GraphEndpoint "https://graph.windows.net/" -StorageEndpoint "azurestack.local";
    if($azureCreds -eq $null) {
		Write-Host "Powershell Credential object is null. Cannot proceed.";
		echo "Powershell Credential object is null. Cannot proceed." >> $logFilePath;
		return;
	}
    #$azureEnv = Get-AzureRmEnvironment 'AzureStack';
    $azureAcc = Add-AzureRmAccount -EnvironmentName 'AzureStack' -Verbose -Credential $azureCreds;

	$storageEndpoint = $(Get-AzureRmContext).Environment.StorageEndpointSuffix;
	echo "Azure Storage Endpoint $storageEndpoint" >> $logFilePath;
	##############################
	### VM PRE-IOSTORM SETUP ###
	##############################
	# Get VMs
	$vms = Get-AzureRmVM | Where {$_.Name -match $vmName}
	echo "Getting VMs $vms" >> $logFilePath;

	# Wait timeout retry count
	$numberOfRetries = 3;

	# Wait for all VMs are deployed
	$resourceGroupName = $null;
	$noOfRetries = $numberOfRetries;
	$noOfDeployedVMs = 0;
	while(($noOfRetries -gt 0) -and ($noOfDeployedVMs -lt $vmCount)) {
		Start-Sleep -Seconds 120;
		$noOfDeployedVMs = 0;
		$vms = Get-AzureRmVM | Where {$_.Name -match $vmName}
		foreach($vm in $vms) {
			# All VMs except jump box VM
			if($vm.Name -match "[0-9]$") {
				$noOfDeployedVMs += 1;
			}
			# Find resource group name for publishing results
			if($resourceGroupName -eq $null) {
				$resourceGroupName = $vm.ResourceGroupName;
			}
		}
		$noOfRetries -= 1;
	}
	if($noOfDeployedVMs -lt $vmCount) {
		Write-Host "Requested number $vmCount of VMs are not deployed. Currently $noOfDeployedVMs VMs are deployed."
		echo "Requested number $vmCount of VMs are not deployed. Currently $noOfDeployedVMs VMs are deployed" >> $logFilePath;
	}

	##################
	### VM IOSTORM ###
	##################
	# Start signal for all VMs to start io pre-sync 
	echo "Start io pre-sync" > $ioPreSyncStartSignalFile;
	echo "Start io pre-sync" >> $logFilePath;
	
	$ioResultExpectedFiles = $vmCount;
	# Wait for 3000 seconds for io pre-sync files from all vms to be created
	$noOfRetries = 300;
	$ioPreSyncDidSucceed = $false;
	while($noOfRetries -gt 0) {
		$existingFiles = Get-ChildItem -Path $ioPreSyncShare;
		if($existingFiles.Count -ge $ioResultExpectedFiles){
			$ioPreSyncDidSucceed = $true;
			Write-Host "Pre io workload synchronization succeeded."
			break;
		}
		Start-Sleep -Seconds 10;
		$noOfRetries--;
	}

	# Start IO workload by creating sync success/failure file
	if($ioPreSyncDidSucceed)
	{
		echo "Sync Succeeded" > $ioPreSyncSignalFile;
		echo "Sync Succeeded" >> $logFilePath;
	}
	else {
		echo "Sync Failed" > $ioPreSyncSignalFile;
		echo "Sync Failed" >> $logFilePath;
	}

	# Display boot results
	$vmioResultFile = "$env:SystemDrive\VMIOResult.log.ps1";

	# Wait for 3000 seconds
	$noOfRetries = 300;
	$ioWorkloadDidSucceed = $false;
	while($noOfRetries -gt 0) {
		$existingFiles = Get-ChildItem -Path $ioResultShare;
		if($existingFiles.Count -ge $ioResultExpectedFiles){
			$ioWorkloadDidSucceed = $true;
			Write-Host "IO workload succeeded.";
			break;
		}
		Start-Sleep -Seconds 10;
		$noOfRetries--;
	}

	# Parse IO workload results
	if($ioWorkloadDidSucceed) {
		DiskspdResultAnalyzeXml -inputpath $ioResultShare -outpath $vmioResultFile;
		echo "IO Workload Result Succeeded" >> $logFilePath;
	}
	else {
		echo "IO Workload Result Failed" >> $vmioResultFile;
		echo "IO Workload Result Failed" >> $logFilePath;
	}

	# Upload VM io result to Portal
	Publish-AzureRmVMDscConfiguration -ResourceGroupName $resourceGroupName -ConfigurationPath $vmioResultFile -StorageAccountName $storageAccount -SkipDependencyDetection -Force;
}

## COLUMNS ## VM Name	Write Ratio	Threads	Requests	Block Size	Read IOPS	Read Bytes	Write IOPS	Write Bytes	Avg Read (ms)	Avg Write (ms)	Read (ms) - 25%	Write (ms) - 25%	Read (ms) - 50%	Write (ms) - 50%	Read (ms) - 75%	Write (ms) - 75%	Read (ms) 90%	Write (ms) - 90%	Read (ms) - 95%	Write (ms) - 95%	Read (ms) - 99%	Write (ms) - 99%	Read (ms) - 99.9%	Write (ms) - 99.9%	Read (ms) - 100%	Write (ms) - 100%
function DiskspdResultAnalyzeXml {
	param([string]$inputpath=".", [string]$outpath)
	function get-latency( $x ) {

		$x.Results.TimeSpan.Latency.Bucket |% {
			$_.Percentile,$_.ReadMilliseconds,$_.WriteMilliseconds -join "`t"
		}
	}

	# Header
	"VM Name	Write Ratio	Threads	Requests	Block Size	Read IOPS	Read Bytes	Write IOPS	Write Bytes	Avg Read (ms)	Avg Write (ms)	Read (ms) - 25%	Write (ms) - 25%	Read (ms) - 50%	Write (ms) - 50%	Read (ms) - 75%	Write (ms) - 75%	Read (ms) 90%	Write (ms) - 90%	Read (ms) - 95%	Write (ms) - 95%	Read (ms) - 99%	Write (ms) - 99%	Read (ms) - 99.9%	Write (ms) - 99.9%	Read (ms) - 100%	Write (ms) - 100%" | out-file $outpath -Encoding ascii -Width 9999
	
	$l = @(); foreach ($i in 25,50,75,90,95,99,99.9,100) { $l += ,[string]$i };

	Get-ChildItem -Path $inputpath -Recurse -Filter *.xml | Sort-Object |% {
		$pwdir = (pwd).Path
		cd $_.Directory.FullName
		$x = [xml](Get-Content $_)

		$lf = $_.fullname -replace '.xml','.lat.tsv'
		
		if (-not [io.file]::Exists($lf)) {
			get-latency $x > $lf
		}

		$system = $_.Directory.Name + "_" + $x.Results.System.ComputerName
		$t = $x.Results.TimeSpan.TestTimeSeconds

		# extract the subset of latency percentiles as specified above in $l
		$h = @{}; $x.Results.TimeSpan.Latency.Bucket |% { $h[$_.Percentile] = $_ }

		$ls = $l |% {
			$b = $h[$_];
			if ($b.ReadMilliseconds) { $b.ReadMilliseconds } else { "" }
			if ($b.WriteMilliseconds) { $b.WriteMilliseconds } else { "" }
		}

		# sum read and write iops across all threads and targets
		$ri = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property ReadCount).Sum
		$wi = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property WriteCount).Sum
		$rb = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property ReadBytes).Sum
		$wb = ($x.Results.TimeSpan.Thread.Target |
				measure -sum -Property WriteBytes).Sum

		# output tab-separated fields. note that with runs specified on the command
		# line, only a single write ratio, outstanding request count and blocksize
		# can be specified, so sampling the one used for the first thread is 
		# sufficient.
		(($system,
			$x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.WriteRatio,
			$x.Results.TimeSpan.ThreadCount,
			$x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.RequestCount,
			$x.Results.Profile.TimeSpans.TimeSpan.Targets.Target.BlockSize,
			# calculate iops
			($ri / $t),
			($rb / $t),
			($wi / $t),
			($wb / $t),
			$x.Results.TimeSpan.Latency.AverageReadMilliseconds,
			$x.Results.TimeSpan.Latency.AverageWriteMilliseconds
			) -join "`t"),
		($ls -join "`t") -join "`t"
		cd $pwdir
	} | out-file $outpath -Encoding ascii -Width 9999 -Append
} # End function DiskspdResultAnalyzeXml
	
VMIOController
