
Configuration ConfigureVMIO
{
	param (
		[Parameter(Mandatory)]
		[string]$AzureUserName,
		[Parameter(Mandatory)]
		[string]$AzurePassword,
		[string]$AzureApplicationId = "https://azurestack.local-api/",
		[Parameter(Mandatory)]
		[string]$TenantId = "7ea3e2b7-334d-4083-807b-fa2000faa9b8",
		[Parameter(Mandatory)]
		[string]$VMName,
		[Parameter(Mandatory)]
		[int32]$VMCount,
		[Parameter(Mandatory)]
		[string]$VMAdminUserName,
		[Parameter(Mandatory)]
		[string]$VMAdminPassword,
		[int32]$VMIoMaxLatency = 100,
		[Parameter(Mandatory)]
		[string]$AzureStorageAccount
	)

	# Turn off private firewall
	netsh advfirewall set privateprofile state off
	# Get full path and name of the script being run
	$PSPath = $PSCommandPath;

	# DSC Script Resource - VM io-storm
	Script VMIOAll
	{
		TestScript = { $false }

		GetScript = { return @{}}

		SetScript = {
			# Azure uses AzureAdApplicationId and AzureAdApplicationPassword values as AzureUserName and AzurePassword parameters respectively
			# AzureStack uses tenant UserName and Password values as AzureUserName and AzurePassword parameters respectively
			$azureUserName = $using:AzureUserName;
			$azurePassword = $using:AzurePassword;
			# Azure uses "" blank value as AzureApplicationId
			# AzureStack uses "https://azurestack.local-api/" value as AzureApplicationId parameter
            $applicationId = $using:AzureApplicationId;
			$tenant = $using:TenantId;
			$vmName = $using:VMName;
			$vmCount = $using:VMCount;
			# Needed for scheduled task to run with no logged-in user
			$vmAdminUserName = $using:VMAdminUserName;
			$vmAdminPassword = $using:VMAdminPassword;
			$vmIoMaxLatency = $using:VMIoMaxLatency;
			$storageAccount = $using:AzureStorageAccount;
			$psPath = $using:PSPath;

			# AzureStack
			if($applicationId -ne "")
			{
				# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
				add-type @"
				using System.Net;
				using System.Security.Cryptography.X509Certificates;
				public class TrustAllCertsPolicy : ICertificatePolicy {
					public bool CheckValidationResult(
						ServicePoint srvPoint, X509Certificate certificate,
						WebRequest request, int certificateProblem) {
						return true;
					}
				}
"@
				[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
				Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"
			}

			# Import Azure Resource Manager PS module if already present
			try {
				Write-Host "Importing Azure RM";
				Import-AzureRM;
			}
			# Install Azure Resource Manager PS module
			catch {
				Write-Host "Cannot import Azure RM module, proceeding with installation";
	
				# Suppress prompts
				$ConfirmPreference = 'None';

				# Install AzureRM
				Get-PackageProvider -Name nuget -ForceBootstrap �Force;
				Install-Module Azure �repository PSGallery �Force -Confirm:0;
				Install-Module AzureRM �repository PSGallery �Force -Confirm:0;
				Install-AzureRm;
				try {
					Write-Host "Importing Azure RM";
					Import-AzureRM;
				} 
				catch {
					Write-Host "Cannot import Azure RM module after installation of AzureRM module";
				}
			}
			#Import-DscResource -ModuleName 'PSDesiredStateConfiguration';

			# Disable Azure Data Collection
			Disable-AzureDataCollection -ErrorAction Ignore;

			$psScriptDir = Split-Path -Parent -Path $psPath;
			$psScriptName = "VMIOWorkloadControllerScript.ps1";
			$psScriptPath = "$psScriptDir\$psScriptName";
			$action = $null;
			# AzureStack
			if($applicationId -ne "")
			{
				$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "& $psScriptPath -azureUserName $azureUserName -azurePassword $azurePassword -azureApplicationId $applicationId -tenant $tenant -vmName $vmName -vmCount $vmCount -vmIoMaxLatency $vmIoMaxLatency -azureStorageAccount $storageAccount";
			}
			# Azure Cloud
			else {
				$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument "& $psScriptPath -azureUserName $azureUserName -azurePassword $azurePassword -tenant $tenant -vmName $vmName -vmCount $vmCount -vmIoMaxLatency $vmIoMaxLatency -azureStorageAccount $storageAccount";
			}
			$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2);
			$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd;
			Unregister-ScheduledTask -TaskName "VMIOController" -Confirm:0 -ErrorAction Ignore;
			Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "VMIOController" -Description "VM iostorm" -User $vmAdminUserName -Password $vmAdminPassword -RunLevel Highest;
		}
	}
}