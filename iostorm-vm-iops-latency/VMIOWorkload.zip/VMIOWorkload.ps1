
Configuration ConfigureVMIO
{
	param (
		[Parameter(Mandatory)]
		[string]$ControllerVMName,
		[Parameter(Mandatory)]
		[string]$ControllerVMPrivateIP,
		[Parameter(Mandatory)]
		[string]$VMName,
		[Parameter(Mandatory)]
		[string]$VMUserName,
		[Parameter(Mandatory)]
		[string]$VMPassword
	)

	# Turn off private firewall
	netsh advfirewall set privateprofile state off
	# Get full path and name of the script being run
	$PSPath = $PSCommandPath;
	
	# DSC Script Resource - VM iostorm
	Script VMIOAll
	{
		TestScript = { $false }

		GetScript = { return @{}}

		SetScript = {
			$controllerVMName = $using:ControllerVMName
			$controllerVMPrivateIP = $using:ControllerVMPrivateIP
			$vmName = $using:VMName
			$vmUserName = $using:VMUserName
			$vmPassword = $using:VMPassword
			$psPath = $using:PSPath;
			
			# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
			add-type @"
			using System.Net;
			using System.Security.Cryptography.X509Certificates;
			public class TrustAllCertsPolicy : ICertificatePolicy {
				public bool CheckValidationResult(
					ServicePoint srvPoint, X509Certificate certificate,
					WebRequest request, int certificateProblem) {
					return true;
				}
			}
"@
			[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
			Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"

			# Import Azure Resource Manager PS module if already present
			try {
				Write-Host "Importing Azure RM";
				Import-AzureRM;
			}
			# Install Azure Resource Manager PS module
			catch {
				Write-Host "Cannot import Azure RM module, proceeding with installation";
	
				# Suppress prompts
				$ConfirmPreference = 'None';

				# Install AzureRM
				Get-PackageProvider -Name nuget -ForceBootstrap -Force;
				Install-Module Azure -repository PSGallery -Force -Confirm:0;
				Install-Module AzureRM -repository PSGallery -Force -Confirm:0;
				Install-AzureRm;
				try {
					Write-Host "Importing Azure RM";
					Import-AzureRM;
				} 
				catch {
					Write-Host "Cannot import Azure RM module after installation of AzureRM module";
				}
			}
			# To avoid warning before loading one or more built-in resources, explicitly import associated modules
			#Import-DscResource -ModuleName 'PSDesiredStateConfiguration';

			# Disable Azure Data Collection
			Disable-AzureDataCollection -ErrorAction Ignore;

			$psScriptDir = Split-Path -Parent -Path $psPath;
			$psScriptName = "VMIOWorkloadScript.ps1";
			$psScriptPath = "$psScriptDir\$psScriptName";
			#$action = New-ScheduledTaskAction -Execute 'Powershell.exe' -Argument '-NoProfile -WindowStyle Hidden -Command "& {$psScriptPath -controllerVMName $controllerVMName -controllerVMPrivateIP $controllerVMPrivateIP -vmName $vmName -vmUserName $vmUserName -vmPassword $vmPassword}"';
			$args = ' -NoProfile -WindowStyle Hidden -Command "& ' + "'" + $psScriptPath + "' '" + $controllerVMName + "' '" + $controllerVMPrivateIP + "' '" + $vmName + "' '" + $vmUserName + "' '" + $vmPassword + "'" + '"';
			$action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument $args;
			$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2);
			$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd
			Unregister-ScheduledTask -TaskName "VMIOWorkload" -Confirm:0 -ErrorAction Ignore;
			Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "VMIOWorkload" -Description "VM iostorm" -User $vmUserName -Password $vmPassword -RunLevel Highest;
		}
	}	
}