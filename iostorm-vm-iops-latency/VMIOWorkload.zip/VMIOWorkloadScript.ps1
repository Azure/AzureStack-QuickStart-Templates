#
# Copyright="?Microsoft Corporation. All rights reserved."
#

param (
	[Parameter(Mandatory)]
	[string]$ControllerVMName,
	[Parameter(Mandatory)]
	[string]$ControllerVMPrivateIP,
	[Parameter(Mandatory)]
	[string]$VMName,
	[Parameter(Mandatory)]
	[string]$VMAdminUserName,
	[Parameter(Mandatory)]
	[string]$VMAdminPassword,
	[Parameter(Mandatory)]
	[int32]$VMIoBlockSize,
	[Parameter(Mandatory)]
	[int32]$VMIoDuration,
	[Parameter(Mandatory)]
	[int32]$VMIoReadPercentage,
	[Parameter(Mandatory)]
	[int32]$VMIoMaxLatency
)

# 1. Waits for a '$controllerReadySignalFile' (e.g. \\10.0.0.6\smbshare\iopresyncstart.txt) from a Controller VM then starts io pre-sync 
# 2. Creates pre-sync file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate VM is up and waiting to start a workload
# 3. Waits for a '$ioWorkloadStartSignalFile' file (e.g. \\10.0.0.6\smbshare\ioworkloadstart-0) from a Controller VM (which indicates all VMs are ready and have created IOPreSync-VMx.log files) to signal all VMs to start io workload with given 'QD' and 'THREAD' values inside the file
# 4. Copy io result file '$ioResultFileName' (e.g. IOResult-VM0.log) in io result directory '$ioResultShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\ioresult\ioresult-0)
# 5. If io workload latency values is < given maxLatency, repeat step #3 with new values of 'QD' and 'THREAD', repeat step #4 and step #5
# 6. All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\logs\)

# Waits for a '$ioPreWorkloadSyncSucceedSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) (which indicates all VMs are ready and have created IOPreSync-VMx.log files) from a Controller VM then starts io workload
# Copy io result file '$ioResultFileName' (e.g. IOResult-VM0.log) in io result directory '$ioResultShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\ioresult\)
# All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\logs\)
function VMIOWorkload {
	# Turn off private firewall off
	netsh advfirewall set privateprofile state off

	# Local file storage location
	$localPath = "$env:SystemDrive"

	# Log file
	$logFileName = "VMWorkload-$VMName.log"
	$logFilePath = "$localPath\$logFileName"

	# Result SMB share
	$smbshare = "\\$ControllerVMPrivateIP\smbshare"

	# Create io workload pre-sync directory
	$ioPreSyncShare = "$smbshare\iopresync"
	$ioPreSyncFileName = "IOPreSync-$VMName.log"

	# Sync signal to start io pre-sync from controller vm
	$controllerReadySignalFile = "$smbshare\iopresyncstart.txt"

	# Start IO workload signal file from controller VM (also indicates pre IO workload sync succeed singal)
	$ioWorkloadStartSignalFile = "$smbshare\ioworkloadstart-";
	#$ioPreWorkloadSyncSucceedSignalFile = "$smbshare\iopresyncsucceed.txt"

	# Log directory
	$logShare = "$smbshare\logs"

	# Create io result directory
	$ioResultShare = "$smbshare\ioresult"
	$ioResultFileName = "IOResult-$VMName.xml"

	$timeoutInSeconds = 7200;
	# Setup connection to smb share of a controller VM, if net use fails retry until timeout
	$dtTime = Get-Date
	echo "Waiting for a share $smbshare to get online by a controller VM at $dtTime" >> $logFilePath
	$startTime = Get-Date
	$elapsedTime = $(Get-Date) - $startTime
	$syncTimeoutInSeconds = $timeoutInSeconds
	while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds)
	{
		net use $smbshare /user:$VMAdminUserName $VMAdminPassword
		if((Test-Path $smbshare) -eq $false)
		{
			Start-Sleep 3
		}
		else
		{
			$dtTime = Get-Date
			Write-Host "SMB share $smbshare is accessible"
			echo "Share $smbshare is made online by a controller VM at $dtTime" > $logFilePath
			break
		}
		$elapsedTime = $(Get-Date) - $startTime
	}

	# Wait for smb share on a controller VM
	$dtTime = Get-Date
	echo "Waiting for controller VM to get ready $controllerReadySignalFile at $dtTime" >> $logFilePath
	if((Test-Path $smbshare) -eq $true) {
		##########################################
		### WAIT TO START IO WORKLOAD PRE-SYNC ###
		##########################################
		# Wait for all VMs to boot and come up before timeout
		$noOfRetries = $timeoutInSeconds/10;
		while($noOfRetries -gt 0) {
			if((Test-Path $controllerReadySignalFile) -eq $true) {
				Write-Host "Wait to start pre-io synchronization is over"
				$noOfRetries = 0;
			}
			Start-Sleep -Seconds 10;
			if($noOfRetries -gt 0) {
				Write-Host "Waiting to start pre-io synchronization... $noOfRetries"
				$noOfRetries--;
			}
		}
	}

	# Create pre-sync file
	$dtTime = Get-Date
	echo "Creating pre-sync file at $dtTime" >> $logFilePath
	echo "$VMName" > $localPath\$ioPreSyncFileName

	# Setup connection to smb share of a controller VM, if net use fails retry until timeout
	$startTime = Get-Date
	$elapsedTime = $(Get-Date) - $startTime
	# Wait until timeout
	$syncTimeoutInSeconds = $timeoutInSeconds/3;
	while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds)
	{
		net use $smbshare /user:$VMAdminUserName $VMAdminPassword
		if((Test-Path $smbshare) -eq $false)
		{
			Start-Sleep 3
		}
		else
		{
			echo "SMB share $smbshare is accessible" >> $logFilePath
			break
		}
		$elapsedTime = $(Get-Date) - $startTime
	}

	if((Test-Path $smbshare) -eq $true) {
		#############################
		### DOWNLOAD DISKSPD TOOL ###
		#############################
		$diskspdSource = "https://raw.githubusercontent.com/Azure/AzureStack-QuickStart-Templates/master/iostorm-vm-iops-latency/diskspd.exe"
		$diskspdFileName = [System.IO.Path]::GetFileName($diskspdSource)
		$diskspdDestination = "$localPath\$diskspdFileName"
		$webClient = New-Object System.Net.WebClient
		$_date = Get-Date -Format hh:mmtt
		echo "Downloading diskspd io load generating tool from $diskspdSource to $diskspdDestination at $_date" >> $logFilePath
		$webClient.DownloadFile($diskspdSource, $diskspdDestination)
		$_date = Get-Date -Format hh:mmtt
		if((Test-Path $diskspdDestination) -eq $true)
		{
			echo "Downloading diskspd io load generating tool succeeded at $_date" >> $logFilePath
		}
		else
		{
			echo "ERROR: Downloading diskspd io load generating tool failed at $_date Cannot continue execution." >> $logFilePath
			return;
		}

		# Create target file of 4GB
		$workloadFileDrive = $env:SYSTEMDRIVE
		# Get all HDD (Drive Type 3)
		$allDrives = Get-WmiObject win32_logicaldisk -filter 'DriveType=3'
		if(($allDrives -eq $null) -or ($allDrives.Count -lt 2))
		{
			$workloadFileDrive = $env:SystemDrive
			Write-Host "Io workload target is a system drive: $WorkloadFile"
			echo "Io workload target is a system drive: $WorkloadFile" >> $logFilePath
		}
		else
		{
			$systemDrive = $env:SYSTEMDRIVE
			foreach($eachDr in $allDrives)
			{
				if($eachDr.DeviceID -ne $systemDrive)
				{
					$workloadFileDrive = $eachDr.DeviceID
					break
				}
			}
			Write-Host "Io workload target is a non-system drive: $workloadFileDrive"
			echo "Io workload target is a non-system drive: $workloadFileDrive" >> $logFilePath
		}
		$workloadFilePath = $workloadFileDrive + "\iobw.tst"
		$diskspdCmd = "$diskspdDestination -t4 -b512K -w100 -r -d10 -W0 -C0 -o32 -h -n -c2G -L -D $workloadFilePath"
		cmd /c $diskspdCmd | Out-Null

		# QD and Thread values
		$qd = -1;
		$threads = -1;
		$iteration = 0;
		# Stop io workload execution when either no QD and THREADS value is provided by a controller VM or io workload pre-synchronization fail
		$continueIoWorkloadExecution = $true;

		##########################################
		### IO WORKLOAD PRE-SYNC + IO WORKLOAD ###
		##########################################
		# Copy pre-sync file
		copy $localPath\$ioPreSyncFileName $ioPreSyncShare\;
		echo "Coyping pre-sync file $ioPreSyncFileName to $ioPreSyncShare" >> $logFilePath

		while($continueIoWorkloadExecution){
			############################
			### IO WORKLOAD PRE-SYNC ###
			############################
			$ioWorkloadStartSignalFileIteration = "$ioWorkloadStartSignalFile$iteration"
			# Flag to indicate sync succeed
			$ioWorkloadSyncDidSucceed = $false;
			# Wait for timeout
			$noOfRetries = $timeoutInSeconds/10;
			while(($noOfRetries -gt 0) -and ($ioWorkloadSyncDidSucceed -eq $false)) {
				
				# Check io workload sync file
				if((Test-Path $ioWorkloadStartSignalFileIteration) -eq $true) {
					$ioWorkloadSyncDidSucceed = $true;
					Write-Host "Start io-workload iteration $iteration synchronization succeeded."
					echo "Start io-workload iteration $iteration synchronization succeeded (Sync signal $ioWorkloadStartSignalFileIteration is present)" >> $logFilePath

					# Get QD and THREADS values from a controller VM
					$lines = Get-Content $ioWorkloadStartSignalFileIteration;
					foreach($line in $lines) {
						 if($line.Contains("QD") -eq $true) {
							 $qd = $line.Split(':')[1];
						 }
						if($line.Contains("THREADS") -eq $true) {
							 $threads = $line.Split(':')[1];
						 }
					}
					$noOfRetries = 0;
					# If Controller VM haven't provided QD or Thread value, stop io workload execution
					if(($qd -lt 0) -or ($threads -lt 0)) {
						$continueIoWorkloadExecution = $false;
					}
					break;
				}

				# Wait for io workload sync signal
				if(($noOfRetries -gt 0) -and ($ioWorkloadSyncDidSucceed -eq $false) -and $continueIoWorkloadExecution) {
					Write-Host "Start io-workload iteration $iteration waiting... $noOfRetries";
					if(($noOfRetries%6) -eq 0){
						echo "Start io-workload iteration $iteration waiting... $noOfRetries" >> $logFilePath;
					}
					$noOfRetries--;
					Start-Sleep -Seconds 10;
				}
			}
			# Workload synchronization failed
			if($ioWorkloadSyncDidSucceed -eq $false){
				$continueIoWorkloadExecution = $false;
				Write-Host "Start io-workload iteration $iteration failed. IO workload execution is stopped.";
				echo "Start io-workload iteration $iteration failed. IO workload execution is stopped." >> $logFilePath;
			}
			###################
			### IO WORKLOAD ###
			###################
			elseif($continueIoWorkloadExecution){
				# Io result share directory for current iteration
				$ioResultIterationShare = $ioResultShare + "\iteration-$iteration";

				# Validate parameters
				$VMIoWritePercentage = 100 - $VMIoReadPercentage
				if(($VMIoReadPercentage + $VMIoWritePercentage) -ne 100) {
					Write-Host "IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values are not valid. Both values must add upto 100."
					echo "IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values are not valid. Both values must add upto 100." >> $logFilePath

					# Update read/write % to valid default values
					$VMIoReadPercentage = 70
					$VMIoWritePercentage = 100 - $VMIoReadPercentage
					Write-Host "Proceeding with IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values"
					echo "Proceeding with IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values" >> $logFilePath
				}

				# Run io workload
				echo "Starting io load generation" >> $logFilePath

				# t - threads, b - block size, w - write ratio, r - random, d - duration, W - warmup period, C - cooldown period, o - queue depth, c - target file size
				#$diskspdCmd = "$diskspdDestination -t4 -b4k -w30 -r -d300 -W300 -C120 -o32 -h -n -c2G -L -D -Rxml $workloadFilePath > $localPath\$ioResultFileName"
				$diskspdCmd = "$diskspdDestination -t4 -b$VMIoBlockSize -w$VMIoWritePercentage -r -d$VMIoDuration -W300 -C120 -o32 -h -n -L -D -Rxml $workloadFilePath > $localPath\$ioResultFileName"
				cmd /c $diskspdCmd
				echo "IO workload has finished" >> $logFilePath

				# Update Machine Name to add right VM index as all VMs uses same name (e.g. VMBootVM => VMBootVM0, VMBootVM1, VMBootVM2...)
				(Get-Content $localPath\$ioResultFileName) | Foreach-Object {$_ -replace "<ComputerName>$env:COMPUTERNAME</ComputerName>", "<ComputerName>$VMName</ComputerName>"} | Set-Content $localPath\$ioResultFileName

				# Copy result file
				copy $localPath\$ioResultFileName $ioResultIterationShare\
			}
			else {
				Write-Host "Stopping io workload at iteration $iteration";
				echo "Stopping io workload at iteration $iteration" >> $logFilePath;
			}
		}

		# Copy log file
		copy $logFilePath $logShare\
	}
	else {
		$dtTime = Get-Date
		Write-Host "SMB Share $smbshare is not accessible at $dtTime"
		echo "SMB share $smbshare is not accessible at $dtTime" >> $logFilePath
		echo "Cannot run IO test as SMB Share $smbshare is not accessible at $dtTime" >> $localPath\$ioResultFileName
	}
	echo "Script execution ended" >> $logFilePath
}

VMIOWorkload
