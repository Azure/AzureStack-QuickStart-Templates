#
# Copyright="Microsoft Corporation. All rights reserved."
#

param (
    [Parameter(Mandatory)]
    [string]$ControllerVMName,
    [Parameter(Mandatory)]
    [string]$ControllerVMPrivateIP,
    [Parameter(Mandatory)]
    [string]$VMName,
    [Parameter(Mandatory)]
    [string]$VMAdminUserName,
    [Parameter(Mandatory)]
    [string]$VMAdminPassword,
    [Parameter(Mandatory)]
    [int32]$VMIoBlockSize,
    [Parameter(Mandatory)]
    [int32]$VMIoDuration,
    [Parameter(Mandatory)]
    [int32]$VMIoReadPercentage,
    [Parameter(Mandatory)]
    [int32]$VMIoMaxLatency,
    [int32]$FixedIops = 0,
    [string]$RunFixedIoLatencyTestAfterGoalSeek = "false",
    [int32]$DataDisks = 1,
    [bool]$StripeDisk = $true
)

# 1. Waits for a '$controllerReadySignalFile' (e.g. \\10.0.0.6\smbshare\iopresyncstart.txt) from a Controller VM then starts IO pre-sync 
# 2. Creates pre-sync file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate VM is up and waiting to start a workload
# 3. Waits for a '$ioWorkloadStartSignalFile' file (e.g. \\10.0.0.6\smbshare\ioworkloadstart-0) from a Controller VM (which indicates all VMs are ready and have created IOPreSync-VMx.log files) to signal all VMs to start IO workload with given 'QD' and 'THREAD' values inside the file
# 4. Copy IO result file '$ioResultFileName' (e.g. IOResult-VM0.log) in IO result directory '$ioResultShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\ioresult\ioresult-0)
# 5. If IO workload latency values is < given maxLatency, repeat step #3 with new values of 'QD' and 'THREAD', repeat step #4 and step #5
# 6. All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\logs\)

# Waits for a '$ioPreWorkloadSyncSucceedSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) (which indicates all VMs are ready and have created IOPreSync-VMx.log files) from a Controller VM then starts IO workload
# Copy IO result file '$ioResultFileName' (e.g. IOResult-VM0.log) in IO result directory '$ioResultShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\ioresult\)
# All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' on a Controller VM (e.g. \\10.0.0.6\smbshare\logs\)
function VMIOWorkload {
    # Turn off private firewall off

    # RunFixedIoLatencyTestAfterGoalSeek is passed as a parameter from 
    # a scheduled task. It must be a string or int.
    if($RunFixedIoLatencyTestAfterGoalSeek -eq "true") {
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $true
    } else {
        [bool]$RunFixedIoLatencyTestAfterGoalSeek = $false
    }
    $ioStormMode = Get-IoStormMode -RunFixedIoLatencyTestAfterGoalSeek $RunFixedIoLatencyTestAfterGoalSeek -FixedIops $FixedIops

    netsh advfirewall set privateprofile state off
    netsh advfirewall set publicprofile state off

    # Local file storage location
    $localPath = "$env:SystemDrive"

    # Log file
    $logFileName = "VMWorkload-$VMName.log"
    $logFilePath = "$localPath\$logFileName"
    $restartRun = $false
    if(Test-Path $logFilePath -ErrorAction SilentlyContinue) {
        if($ioStormMode -eq "FixedIops") {
            "Restarting fixed IOPS run" | Out-File $logFilePath -Encoding ASCII -Append
            $restartRun = $true
        } else {
            Write-Host "Log file already exists. Skipping test execution."
            "Log file already exists. Skipping test execution." | Out-File $logFilePath -Encoding ASCII -Append
            return
        }
    }

    # Result SMB share
    $smbshare = "\\$ControllerVMPrivateIP\smbshare"

    # Create IO workload pre-sync directory
    $ioPreSyncShare = "$smbshare\iopresync"
    $ioPreSyncFileName = "IOPreSync-$VMName.log"

    # Sync signal to start IO pre-sync from controller vm
    $controllerReadySignalFile = "$smbshare\iopresyncstart.txt"

    # Start IO workload signal file from controller VM (also indicates pre IO workload sync succeed singal)
    $ioWorkloadStartSignalFile = "$smbshare\ioworkloadstart-"
    #$ioPreWorkloadSyncSucceedSignalFile = "$smbshare\iopresyncsucceed.txt"

    # Log directory
    $logShare = "$smbshare\logs"

    # Create IO result directory
    $ioResultShare = "$smbshare\ioresult"
    $ioResultFileName = "IOResult-$VMName.xml"

    $timeoutInSeconds = 7200
    # Setup connection to smb share of a controller VM, if net use fails retry until timeout
    $dtTime = Get-Date
    "Waiting for a share $smbshare to get online by a controller VM at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
    $startTime = Get-Date
    $elapsedTime = $(Get-Date) - $startTime
    $syncTimeoutInSeconds = $timeoutInSeconds
    while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds) {
        net use $smbshare /user:$VMAdminUserName $VMAdminPassword
        if((Test-Path $smbshare) -eq $false) {
            Start-Sleep 3
        }
        else {
            $dtTime = Get-Date
            Write-Verbose "SMB share $smbshare is accessible"
            "Share $smbshare is made online by a controller VM at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
            break
        }
        $elapsedTime = $(Get-Date) - $startTime
    }

    # Wait for smb share on a controller VM
    $dtTime = Get-Date
    "Waiting for controller VM to get ready $controllerReadySignalFile at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
    if((Test-Path $smbshare) -eq $true) {
        ##########################################
        ### WAIT TO START IO WORKLOAD PRE-SYNC ###
        ##########################################
        # Wait for all VMs to boot and come up before timeout
        $noOfRetries = $timeoutInSeconds/10
        while($noOfRetries -gt 0) {
            if((Test-Path $controllerReadySignalFile) -eq $true) {
                Write-Verbose "Wait to start pre-io synchronization is over"
                $noOfRetries = 0
            }
            Start-Sleep -Seconds 10
            if($noOfRetries -gt 0) {
                Write-Verbose "Waiting to start pre-io synchronization... $noOfRetries"
                $noOfRetries--
            }
        }
    }

    # Create pre-sync file
    $dtTime = Get-Date
    "Creating pre-sync file at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
    "$VMName" | Out-File $localPath\$ioPreSyncFileName -Encoding ASCII -Append

    # Setup connection to smb share of a controller VM, if net use fails retry until timeout
    $startTime = Get-Date
    $elapsedTime = $(Get-Date) - $startTime
    # Wait until timeout
    $syncTimeoutInSeconds = $timeoutInSeconds/3
    while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds) {
        net use $smbshare /user:$VMAdminUserName $VMAdminPassword
        if((Test-Path $smbshare) -eq $false) {
            Start-Sleep 3
        }
        else {
            "SMB share $smbshare is accessible" | Out-File $logFilePath -Encoding ASCII -Append
            break
        }
        $elapsedTime = $(Get-Date) - $startTime
    }

    if ($StripeDisk) {
        $stripeDataDisks = 1
    }
    else {
        $stripeDataDisks = $StripeDisk
    }
    $testFileList = BuildFileList -NumDisks $stripeDataDisks -FileName "iobw.tst"
    "Test file list: $testFileList" | Out-File $logFilePath -Encoding ASCII -Append

    if((Test-Path $smbshare) -eq $true) {
        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
        #############################
        ### DOWNLOAD DISKSPD TOOL ###
        #############################
        $diskspdSource = "https://raw.githubusercontent.com/Azure/AzureStack-QuickStart-Templates/master/iostorm-vm-iops-latency/diskspd.exe"
        $diskspdFileName = [System.IO.Path]::GetFileName($diskspdSource)
        $diskspdDestination = "$localPath\$diskspdFileName"
        $workloadFileDrive = "F:"
        $workloadFilePath = $workloadFileDrive + "\iobw.tst"

        if($restartRun -eq $false) {
            
            $webClient = New-Object System.Net.WebClient
            [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.SecurityProtocolType]::Tls12;
            $_date = Get-Date -Format hh:mmtt
            "Downloading diskspd IO load generating tool from $diskspdSource to $diskspdDestination at $_date" | Out-File $logFilePath -Encoding ASCII -Append
            $success = $false
            $downloadRetries = 20
            while($success -eq $false -and $downloadRetries -gt 0 ) {
                $success = $true
                $webClient.DownloadFile($diskspdSource, $diskspdDestination)
                $_date = Get-Date -Format hh:mmtt
                if((Test-Path $diskspdDestination) -eq $true) {
                    "Downloading diskspd IO load generating tool succeeded at $_date" | Out-File $logFilePath -Encoding ASCII -Append
                }
                else {
                    "WARN: Downloading diskspd IO load generating tool failed at $_date Retrying." | Out-File $logFilePath -Encoding ASCII -Append
                    $success = $false
                    $downloadRetries--
                    Start-Sleep -Seconds 30
                }
            }
            if($success -eq $false) {
                "ERROR: Downloading diskspd IO load generating tool failed at $_date No more retries, failing test." | Out-File $logFilePath -Encoding ASCII -Append
                return
            }
            # Create target file
            #unsure why we tried defaulting to this. Test would fail rather than no use the specified disk below
            #$workloadFileDrive = $env:SYSTEMDRIVE
        
            # Initialize disk
            InitializeAllDisks -NumDisks $DataDisks -StripeDisk $StripeDisk
                        
            $diskspdCmd = "$diskspdDestination -t2 -b512K -w90 -d600 -W0 -C0 -o8 -Sh -n -r -c768G $testFileList"
            "Starting diskspd workload $diskspdCmd" | Out-File $logFilePath -Encoding ASCII -Append
            Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
            cmd /c $diskspdCmd | Out-Null
        }

        # if we are striping disks treat the data disk count as 1 from this point
        if ($StripeDisk) {
            $DataDisks = 1
        }

        # QD and Thread values
        $qd = -1
        $threads = -1
        $iteration = 0
        try {
            if($restartRun -eq $true) {
                #find highest iteration
                $startFilePath = "$ioWorkloadStartSignalFile*"
                $startFiles = Get-ChildItem $startFilePath
                $startNames = $startFiles.Name
                $allIterations = @()
                foreach($n in $startNames) {
                    $splitStr = $n.Split("-")
                    $iterStr = $splitStr[1]
                    $iterNum = [convert]::ToInt32($iterStr, 10)
                    $allIterations += $iterNum
                }
                $measure = $allIterations | Measure-Object -Maximum
                $iteration = $measure.Maximum + 1
            }
        } catch {
            "Failed to determine start iteration. Defaulting to 0. $_" | Out-File $logFilePath -Encoding ASCII -Append
        }
        "Starting with iteration $iteration" | Out-File $logFilePath -Encoding ASCII -Append
        # Stop IO workload execution when either no QD and THREADS value is provided by a controller VM or IO workload pre-synchronization fail
        $continueIoWorkloadExecution = $true

        ##########################################
        ### IO WORKLOAD PRE-SYNC + IO WORKLOAD ###
        ##########################################
        # Copy pre-sync file
        "Coyping pre-sync file $ioPreSyncFileName to $ioPreSyncShare" | Out-File $logFilePath -Encoding ASCII -Append
        Copy-Item $localPath\$ioPreSyncFileName $ioPreSyncShare\
        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
        while($continueIoWorkloadExecution) {                       
            ############################
            ### IO WORKLOAD PRE-SYNC ###
            ############################
            $ioWorkloadStartSignalFileIteration = "$ioWorkloadStartSignalFile$iteration"
            # Flag to indicate sync succeed
            $ioWorkloadSyncDidSucceed = $false
            # Wait for timeout
            $noOfRetries = $timeoutInSeconds/10
            while(($noOfRetries -gt 0) -and ($ioWorkloadSyncDidSucceed -eq $false)) {
                $fixedIopsPerDisk = 0

                # Check IO workload sync file
                if((Test-Path $ioWorkloadStartSignalFileIteration) -eq $true) {
                    $ioWorkloadSyncDidSucceed = $true
                    Write-Verbose "Start io-workload iteration $iteration synchronization succeeded."
                    "Start io-workload iteration $iteration synchronization succeeded (Sync signal $ioWorkloadStartSignalFileIteration is present)" | Out-File $logFilePath -Encoding ASCII -Append

                    # Get QD and THREADS values from a controller VM
                    $lines = Get-Content $ioWorkloadStartSignalFileIteration
                    foreach($line in $lines) {
                        if($line.Contains("QD") -eq $true) {
                            $qd = $line.Split(':')[1]
                        }
                        if($line.Contains("THREADS") -eq $true) {
                             $threads = $line.Split(':')[1]
                        }
                        if($line.Contains("FIXED") -eq $true) {
                            [int32]$fixedIopsPerDisk = [convert]::ToInt32($line.Split(':')[1], 10)
                        }
                    }
                    $noOfRetries = 0
                    # If Controller VM haven't provided QD or Thread value, stop IO workload execution
                    if(($qd -lt 0) -or ($threads -lt 0)) {
                        $continueIoWorkloadExecution = $false
                    }
                    break
                }

                # Wait for IO workload sync signal
                if(($noOfRetries -gt 0) -and ($ioWorkloadSyncDidSucceed -eq $false) -and $continueIoWorkloadExecution) {
                    Write-Verbose "Start io-workload iteration $iteration waiting... $noOfRetries"
                    if(($noOfRetries%6) -eq 0) {
                        "Start io-workload iteration $iteration waiting... $noOfRetries" | Out-File $logFilePath -Encoding ASCII -Append
                        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
                    }
                    $noOfRetries--
                    Start-Sleep -Seconds 10
                }
            }
            # Workload synchronization failed
            if($ioWorkloadSyncDidSucceed -eq $false) {
                $continueIoWorkloadExecution = $false
                Write-Verbose "Start io-workload iteration $iteration failed. IO workload execution is stopped."
                "Start io-workload iteration $iteration failed. IO workload execution is stopped." | Out-File $logFilePath -Encoding ASCII -Append
                Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
            }
            ###################
            ### IO WORKLOAD ###
            ###################
            elseif($continueIoWorkloadExecution) {
                # Io result share directory for current iteration
                $ioResultIterationShare = $ioResultShare + "\iteration-$iteration"

                # Validate parameters
                $VMIoWritePercentage = 100 - $VMIoReadPercentage
                if(($VMIoReadPercentage + $VMIoWritePercentage) -ne 100) {
                    Write-Verbose "IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values are not valid. Both values must add upto 100."
                    "IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values are not valid. Both values must add upto 100." | Out-File $logFilePath -Encoding ASCII -Append

                    # Update read/write % to valid default values
                    $VMIoReadPercentage = 70
                    $VMIoWritePercentage = 100 - $VMIoReadPercentage
                    Write-Verbose "Proceeding with IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values"
                    "Proceeding with IO Read Percentage $VMIoReadPercentage and IO Write Percentage $VMIoWritePercentage values" | Out-File $logFilePath -Encoding ASCII -Append
                }

                # Run IO workload
                "Starting IO load generation with QD: $qd and THREADS: $threads" | Out-File $logFilePath -Encoding ASCII -Append

                # Refer to http://aka.ms/diskspd : 
                # t - threads, b - block size, w - write ratio, r - random, d - duration, W - warmup period, C - cooldown period, o - queue depth, Sh - disable software and hardware write caching, n - disable affinity, L - measure latency, D - capture IOPS higher-order stats in intervals of ms
                if($fixedIopsPerDisk -eq 0 -and $FixedIops -eq 0) {
                    $diskspdCmd = "$diskspdDestination -t$threads -b$VMIoBlockSize -w$VMIoWritePercentage -rs70 -rdpct90/10 -d$VMIoDuration -W60 -C10 -o$qd -Sh -n -L -D -z -Rxml $testFileList > $localPath\$ioResultFileName"
                } elseif($fixedIopsPerDisk -ne 0 -and $RunFixedIoLatencyTestAfterGoalSeek -eq $true) {
                    $bytesPerMs = ($VMIoBlockSize * $fixedIopsPerDisk) / 1000 / ($threads * $DataDisks)
                    if($bytesPerMs -lt 1) {
                        $bytesPerMs = 1
                    }
                    "Using fixed IO -g$bytesPerMs" | Out-File $logFilePath -Encoding ASCII -Append
                    $diskspdCmd = "$diskspdDestination -t$threads -g$bytesPerMs -b$VMIoBlockSize -w$VMIoWritePercentage -rs70 -rdpct90/10 -d120 -W60 -C10 -o$qd -Sh -n -L -D -z -Rxml $testFileList > $localPath\$ioResultFileName"
                } else {
                    $bytesPerMs = ($VMIoBlockSize * $FixedIops) / 1000 / ($threads * $DataDisks)
                    if($bytesPerMs -lt 1) {
                        $bytesPerMs = 1
                    }
                    "$FixedIops IOPS requested. Using fixed IO -g$bytesPerMs" | Out-File $logFilePath -Encoding ASCII -Append
                    $diskspdCmd = "$diskspdDestination -t$threads -g$bytesPerMs -b$VMIoBlockSize -w$VMIoWritePercentage -rs70 -rdpct90/10 -d$VMIoDuration -W60 -C10 -o$qd -Sh -n -L -D -z -Rxml $testFileList > $localPath\$ioResultFileName"
                }

                "IO workload: $diskspdCmd" | Out-File $logFilePath -Encoding ASCII -Append
                Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath
                cmd /c $diskspdCmd
                "IO workload has finished" | Out-File $logFilePath -Encoding ASCII -Append

                # Update Machine Name to add right VM index as all VMs uses same name (e.g. VMBootVM => VMBootVM0, VMBootVM1, VMBootVM2...)
                (Get-Content $localPath\$ioResultFileName) | Foreach-Object {$_ -replace "<ComputerName>$env:COMPUTERNAME</ComputerName>", "<ComputerName>$VMName</ComputerName>"} | Set-Content $localPath\$ioResultFileName

                # Copy result file
                Copy-LogFiles -Src $localPath\$ioResultFileName -Dest $ioResultIterationShare\ -LogFilePath $logFilePath               
            }
            else {
                Write-Verbose "Stopping IO workload at iteration $iteration"
                "Stopping IO workload at iteration $iteration" | Out-File $logFilePath -Encoding ASCII -Append
            }
            $iteration += 1
        }

        # Copy log file
        Copy-LogFiles -Src $logFilePath -Dest $logShare\ -LogFilePath $logFilePath

    }
    else {
        $dtTime = Get-Date
        Write-Verbose "SMB Share $smbshare is not accessible at $dtTime"
        "SMB share $smbshare is not accessible at $dtTime" | Out-File $logFilePath -Encoding ASCII -Append
        "Cannot run IO test as SMB Share $smbshare is not accessible at $dtTime" | Out-File $localPath\$ioResultFileName -Encoding ASCII -Append
    }
    "Script execution ended" | Out-File $logFilePath -Encoding ASCII -Append
}

function WaitForDisk
{
    param(
    [UInt32]$DiskNumber,
    [UInt64]$RetryIntervalSec = 10,
    [UInt32]$RetryCount = 60
    )
    $diskFound = $false
    Write-Verbose -Message "Checking for disk '$($DiskNumber)' ..."

    for ($count = 0; $count -lt $RetryCount; $count++)
    {
        $disk = Get-Disk -Number $DiskNumber -ErrorAction SilentlyContinue
        if (!!$disk)
        {
            Write-Verbose -Message "Found disk '$($disk.FriendlyName)'."
            $diskFound = $true
            break
        }
        else
        {
            Write-Verbose -Message "Disk '$($DiskNumber)' NOT found."
            Write-Verbose -Message "Retrying in $RetryIntervalSec seconds ..."
            Start-Sleep -Seconds $RetryIntervalSec
        }
    }

    if (!$diskFound)
    {
        throw "Disk '$($DiskNumber)' NOT found after $RetryCount attempts."
    }
    return $diskFound
}

function InitializeDisk
{
    param(
    [UInt32] $DiskNumber,
    [String] $DriveLetter
    )
    
    $disk = Get-Disk -Number $DiskNumber
    
    if($disk -eq $null){
        return $false
    }

    if ($disk.PartitionStyle -ne "RAW") {
        "Disk number '$($DiskNumber)' has already been initialized." | Out-File $logFilePath -Encoding ASCII -Append                    
        return $true
    }

    if ($disk.IsOffline -eq $true)
    {
        "Setting disk Online" | Out-File $logFilePath -Encoding ASCII -Append                    
        $disk | Set-Disk -IsOffline $false
    }
    
    if ($disk.IsReadOnly -eq $true)
    {
        "Setting disk to not ReadOnly" | Out-File $logFilePath -Encoding ASCII -Append                    
        $disk | Set-Disk -IsReadOnly $false
    }
    
    if ($disk.PartitionStyle -eq "RAW")
    {
        "Initializing disk number $($DiskNumber)..." | Out-File $logFilePath -Encoding ASCII -Append                    

        $disk | Initialize-Disk -PartitionStyle GPT -PassThru
        if ($DriveLetter)
        {
            $partition = $disk | New-Partition -DriveLetter $DriveLetter -UseMaximumSize
        }
        else
        {
            $partition = $disk | New-Partition -AssignDriveLetter -UseMaximumSize
        }

        # Sometimes the disk will still be read-only after the call to New-Partition returns.
        Start-Sleep -Seconds 5

        if($partition -ne $null) {
            $volume = $partition | Format-Volume -FileSystem NTFS -Confirm:$false

            "Successfully initialized disk number '$($DiskNumber)'." | Out-File $logFilePath -Encoding ASCII -Append                    
        }
        else {
            "Failed to initialize disk num '$($DiskNumber)'." | Out-File $logFilePath -Encoding ASCII -Append                    
        }
    }
    
    if (($disk | Get-Partition | Where-Object { $_.DriveLetter -ne "`0" } | Select-Object -ExpandProperty DriveLetter) -ne $DriveLetter)
    {
        "Changing drive letter to $DriveLetter" | Out-File $logFilePath -Encoding ASCII -Append                    
        Set-Partition -DiskNumber $disknumber -PartitionNumber (Get-Partition -Disk $disk | Where-Object { $_.DriveLetter -ne "`0" } | Select-Object -ExpandProperty PartitionNumber) -NewDriveLetter $driveletter
    }

    return true
}

function InitializeDiskPool
{
    param(
        [UInt32] $DiskPoolSize,
        [String] $DriveLetter
    )

    $physicalDisk = Get-PhysicalDisk | where {$_.CanPool -eq $true}

    if ($physicalDisk.Count -eq 0) {
        return $false
    }

    if ($physicalDisk.Count -ne $DiskPoolSize) {
        throw "Unexpected number of data disk found. Expected value: $DiskPoolSize. Actual value: $($physicalDisk.Count)."
    }

    $poolName = "TestDiskPool"
    $vdName = "TestVD"
    $volName = "TestVolume"
    $storage = Get-StorageSubSystem
    New-StoragePool -FriendlyName $poolName -PhysicalDisks $physicalDisk -StorageSubSystemName $storage.Name
    New-VirtualDisk -FriendlyName $vdName `
                    -ResiliencySettingName Simple `
                    -NumberOfColumns $physicalDisk.Count `
                    -UseMaximumSize -Interleave 65536 -StoragePoolFriendlyName $poolName
    $vdiskNumber = (Get-Disk -FriendlyName $vdName).Number
    Initialize-Disk -FriendlyName $vdName -PartitionStyle GPT -PassThru
    New-Partition -UseMaximumSize -DiskNumber $vdiskNumber -DriveLetter $DriveLetter
    Format-Volume -DriveLetter $DriveLetter -FileSystem NTFS -NewFileSystemLabel $volName -AllocationUnitSize 65536 -Force -Confirm:$false

    return $true
}

function Copy-LogFiles
{
    param(
    [String] $Src,
    [String] $Dest,
    [string] $LogFilePath
    )
    $success = $false
    $iteration = 0
    while(!$success) {        
        try {
            Copy-Item $Src $Dest -Force
            $success = $true
        } catch {
            $success = $false
            $d = Get-Date
            "$d Failed to copy logs for $iteration. Src: $Src Dest: $Dest Retrying. $_" | Out-File $LogFilePath -Encoding ASCII -Append
            $iteration++
            Start-Sleep -Seconds 10
        }
    }
}
function InitializeAllDisks
{
    param(
        [int32]$NumDisks,
        [bool] $StripeDisk
    )

    $driveLetters = "FGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
    $diskNumber = 1

    if ((-not $StripeDisk) -or ($NumDisks -eq 1))
    {
        for ($i = 0; $i -lt $NumDisks; $i++)
        {
            ++$diskNumber

            if(WaitForDisk -DiskNumber $diskNumber) {
                [string]$driveLetter = $driveLetters[$i]

                if(InitializeDisk -DiskNumber $diskNumber -DriveLetter $driveLetter) {
                    "Initializing disk $diskNumber at $driveLetter)" | Out-File $logFilePath -Encoding ASCII -Append
                }
            }
        }
    }
    else
    {
        [string]$driveLetter = $driveLetters[0]
        $poolDisk = Get-Disk -Number $($diskNumber + $NumDisks + 1) -ErrorAction SilentlyContinue

        if ($poolDisk)
        {
            "Found pool disk '$($poolDisk.FriendlyName)'." | Out-File $logFilePath -Encoding ASCII -Append
        }
        else
        {
            for($i = 0; $i -lt $NumDisks; $i++) {
                ++$diskNumber
                WaitForDisk -DiskNumber $diskNumber
            }

            ++$diskNumber
            if(InitializeDiskPool -DiskPoolSize $NumDisks -DriveLetter $driveLetter) {
                "Initializing disk $diskNumber at $driveLetter with a pool of $NumDisks disks" | Out-File $logFilePath -Encoding ASCII -Append
            }
        }
    }
}

function BuildFileList
{
    param(
    [int32]$NumDisks,
    [string]$FileName
    )
    $driveLetters = "FGHIJKLMNOPQRSTUVWXYZ".ToCharArray()
    $str = ""
    for($i = 0; $i -lt $NumDisks; $i++) {        
        $str += "$($driveLetters[$i]):\$FileName "
    }
    return $str
}

function Get-IoStormMode {
    param (
        [bool]$RunFixedIoLatencyTestAfterGoalSeek,
        [int32]$FixedIops
    )
    if($RunFixedIoLatencyTestAfterGoalSeek -eq $true -and $FixedIops -ne 0) {
        $ioStormInitialMode = "GoalSeek"
        $ioStormMode = "GoalSeekFixedIops"
    } elseif($RunFixedIoLatencyTestAfterGoalSeek -eq $false -and $FixedIops -ne 0) {
        $ioStormMode = "FixedIops"
    } else {
        $ioStormMode = "GoalSeek"
    }
    return $ioStormMode
}

VMIOWorkload

# SIG # Begin signature block
# MIIjegYJKoZIhvcNAQcCoIIjazCCI2cCAQExDzANBglghkgBZQMEAgEFADB5Bgor
# BgEEAYI3AgEEoGswaTA0BgorBgEEAYI3AgEeMCYCAwEAAAQQH8w7YFlLCE63JNLG
# KX7zUQIBAAIBAAIBAAIBAAIBADAxMA0GCWCGSAFlAwQCAQUABCBznXD01v66hmRw
# /xn565wa5YGrHWVqn0g+JXCQ8bFghaCCDXYwggX0MIID3KADAgECAhMzAAAB3vl+
# gOdHKPWkAAAAAAHeMA0GCSqGSIb3DQEBCwUAMH4xCzAJBgNVBAYTAlVTMRMwEQYD
# VQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNpZ25p
# bmcgUENBIDIwMTEwHhcNMjAxMjE1MjEzMTQ0WhcNMjExMjAyMjEzMTQ0WjB0MQsw
# CQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9u
# ZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMR4wHAYDVQQDExVNaWNy
# b3NvZnQgQ29ycG9yYXRpb24wggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
# AQC42o7GuqPBrC9Z9N+JtpXANgk2m77zmZSuuBKQmr5pZRmQCht/u/V21N5nwBWK
# NGwCZNdI98dyYGYORRZgrMOh8JWxDBjLMQYtqklGLw5ZPw3OCGCIM2ZU0snDlvZ3
# nKwys5NtPlY4shJxcVM2dhMnXhRTqvtexmeWpfmvtiop7jJn2Sdq0iDybDyU2vMz
# nH2ASetgjvuW2eP4d6zQXlboTBBu1ZxTv/aCRrWCWUPge8lHr3wtiPJHMyxmRHXT
# ulS2VksZ6iI9RLOdlqup9UOcnKRaj1usJKjwADu75+fegAZ4HPWSEXXmpBmuhvbT
# Euwa04eiL7ZKbG3mY9EqpiJ7AgMBAAGjggFzMIIBbzAfBgNVHSUEGDAWBgorBgEE
# AYI3TAgBBggrBgEFBQcDAzAdBgNVHQ4EFgQUbrkwVx/G26M/PsNzHEotPDOdBMcw
# RQYDVR0RBD4wPKQ6MDgxHjAcBgNVBAsTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEW
# MBQGA1UEBRMNMjMwMDEyKzQ2MzAwODAfBgNVHSMEGDAWgBRIbmTlUAXTgqoXNzci
# tW2oynUClTBUBgNVHR8ETTBLMEmgR6BFhkNodHRwOi8vd3d3Lm1pY3Jvc29mdC5j
# b20vcGtpb3BzL2NybC9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3JsMGEG
# CCsGAQUFBwEBBFUwUzBRBggrBgEFBQcwAoZFaHR0cDovL3d3dy5taWNyb3NvZnQu
# Y29tL3BraW9wcy9jZXJ0cy9NaWNDb2RTaWdQQ0EyMDExXzIwMTEtMDctMDguY3J0
# MAwGA1UdEwEB/wQCMAAwDQYJKoZIhvcNAQELBQADggIBAHBTJKafCqTZswwxIpvl
# yU+K/+9oxjswaMqV+yGkRLa7LDqf917yb+IHjsPphMwe0ncDkpnNtKazW2doVHh3
# wMNXUYX6DzyVg1Xr/MTYaai0/GkPR/RN4MSBfoVBDzXJSisnYEWlK1TbI1J1mNTU
# iyiaktveVsH3xQyOVXQEpKFW17xYoHGjYm8s5v22mRE/ShVgsEW9ckxeQbJPCkPc
# PiqD4eXwPguTxv06Pwxva8lsjsPDvo2EgwozBCNGRAxsv2pEl0bh+yOtaFpfQWG7
# yMskiLQwWWoWFyuzm6yiKmZ/jdfO98xR1bFUhQMdwQoMi0lCUMx6YQJj1WpNUTDq
# X0ttJGny2aPWsoOgZ5fzKHNfCowOA+7hLc6gCVRBzyMN/xvV19aKymPt8I/J5gqA
# ZCQT19YgNKyhHUYS4GnFyMr/0GCezE8kexDGeQ3JX1TpHQvcz/dghK30fWM9z44l
# BjNcMV/HtTuefSFsr9tCp53wVaw65LudxSjH+/a2zUa85KKCBzj/GU4OhDaa5Wd4
# 8jr0JSm/515Ynzm1Xje5Ai/qo9xaGCrjrVcJUxBXd/SZPorm3HN6U1aJnL2Kw6nY
# 8Rs205CIWT28aFTecMQ6+KnMt1NZR4pogBnnpWSLc92JMbUd1Z6IbauU6U/oOjyl
# WOtkYUKbyE7EvK9GwUQXMds/MIIHejCCBWKgAwIBAgIKYQ6Q0gAAAAAAAzANBgkq
# hkiG9w0BAQsFADCBiDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEyMDAGA1UEAxMpTWljcm9zb2Z0IFJvb3QgQ2VydGlmaWNhdGUgQXV0aG9yaXR5
# IDIwMTEwHhcNMTEwNzA4MjA1OTA5WhcNMjYwNzA4MjEwOTA5WjB+MQswCQYDVQQG
# EwJVUzETMBEGA1UECBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwG
# A1UEChMVTWljcm9zb2Z0IENvcnBvcmF0aW9uMSgwJgYDVQQDEx9NaWNyb3NvZnQg
# Q29kZSBTaWduaW5nIFBDQSAyMDExMIICIjANBgkqhkiG9w0BAQEFAAOCAg8AMIIC
# CgKCAgEAq/D6chAcLq3YbqqCEE00uvK2WCGfQhsqa+laUKq4BjgaBEm6f8MMHt03
# a8YS2AvwOMKZBrDIOdUBFDFC04kNeWSHfpRgJGyvnkmc6Whe0t+bU7IKLMOv2akr
# rnoJr9eWWcpgGgXpZnboMlImEi/nqwhQz7NEt13YxC4Ddato88tt8zpcoRb0Rrrg
# OGSsbmQ1eKagYw8t00CT+OPeBw3VXHmlSSnnDb6gE3e+lD3v++MrWhAfTVYoonpy
# 4BI6t0le2O3tQ5GD2Xuye4Yb2T6xjF3oiU+EGvKhL1nkkDstrjNYxbc+/jLTswM9
# sbKvkjh+0p2ALPVOVpEhNSXDOW5kf1O6nA+tGSOEy/S6A4aN91/w0FK/jJSHvMAh
# dCVfGCi2zCcoOCWYOUo2z3yxkq4cI6epZuxhH2rhKEmdX4jiJV3TIUs+UsS1Vz8k
# A/DRelsv1SPjcF0PUUZ3s/gA4bysAoJf28AVs70b1FVL5zmhD+kjSbwYuER8ReTB
# w3J64HLnJN+/RpnF78IcV9uDjexNSTCnq47f7Fufr/zdsGbiwZeBe+3W7UvnSSmn
# Eyimp31ngOaKYnhfsi+E11ecXL93KCjx7W3DKI8sj0A3T8HhhUSJxAlMxdSlQy90
# lfdu+HggWCwTXWCVmj5PM4TasIgX3p5O9JawvEagbJjS4NaIjAsCAwEAAaOCAe0w
# ggHpMBAGCSsGAQQBgjcVAQQDAgEAMB0GA1UdDgQWBBRIbmTlUAXTgqoXNzcitW2o
# ynUClTAZBgkrBgEEAYI3FAIEDB4KAFMAdQBiAEMAQTALBgNVHQ8EBAMCAYYwDwYD
# VR0TAQH/BAUwAwEB/zAfBgNVHSMEGDAWgBRyLToCMZBDuRQFTuHqp8cx0SOJNDBa
# BgNVHR8EUzBRME+gTaBLhklodHRwOi8vY3JsLm1pY3Jvc29mdC5jb20vcGtpL2Ny
# bC9wcm9kdWN0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3JsMF4GCCsG
# AQUFBwEBBFIwUDBOBggrBgEFBQcwAoZCaHR0cDovL3d3dy5taWNyb3NvZnQuY29t
# L3BraS9jZXJ0cy9NaWNSb29DZXJBdXQyMDExXzIwMTFfMDNfMjIuY3J0MIGfBgNV
# HSAEgZcwgZQwgZEGCSsGAQQBgjcuAzCBgzA/BggrBgEFBQcCARYzaHR0cDovL3d3
# dy5taWNyb3NvZnQuY29tL3BraW9wcy9kb2NzL3ByaW1hcnljcHMuaHRtMEAGCCsG
# AQUFBwICMDQeMiAdAEwAZQBnAGEAbABfAHAAbwBsAGkAYwB5AF8AcwB0AGEAdABl
# AG0AZQBuAHQALiAdMA0GCSqGSIb3DQEBCwUAA4ICAQBn8oalmOBUeRou09h0ZyKb
# C5YR4WOSmUKWfdJ5DJDBZV8uLD74w3LRbYP+vj/oCso7v0epo/Np22O/IjWll11l
# hJB9i0ZQVdgMknzSGksc8zxCi1LQsP1r4z4HLimb5j0bpdS1HXeUOeLpZMlEPXh6
# I/MTfaaQdION9MsmAkYqwooQu6SpBQyb7Wj6aC6VoCo/KmtYSWMfCWluWpiW5IP0
# wI/zRive/DvQvTXvbiWu5a8n7dDd8w6vmSiXmE0OPQvyCInWH8MyGOLwxS3OW560
# STkKxgrCxq2u5bLZ2xWIUUVYODJxJxp/sfQn+N4sOiBpmLJZiWhub6e3dMNABQam
# ASooPoI/E01mC8CzTfXhj38cbxV9Rad25UAqZaPDXVJihsMdYzaXht/a8/jyFqGa
# J+HNpZfQ7l1jQeNbB5yHPgZ3BtEGsXUfFL5hYbXw3MYbBL7fQccOKO7eZS/sl/ah
# XJbYANahRr1Z85elCUtIEJmAH9AAKcWxm6U/RXceNcbSoqKfenoi+kiVH6v7RyOA
# 9Z74v2u3S5fi63V4GuzqN5l5GEv/1rMjaHXmr/r8i+sLgOppO6/8MO0ETI7f33Vt
# Y5E90Z1WTk+/gFcioXgRMiF670EKsT/7qMykXcGhiJtXcVZOSEXAQsmbdlsKgEhr
# /Xmfwb1tbWrJUnMTDXpQzTGCFVowghVWAgEBMIGVMH4xCzAJBgNVBAYTAlVTMRMw
# EQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVN
# aWNyb3NvZnQgQ29ycG9yYXRpb24xKDAmBgNVBAMTH01pY3Jvc29mdCBDb2RlIFNp
# Z25pbmcgUENBIDIwMTECEzMAAAHe+X6A50co9aQAAAAAAd4wDQYJYIZIAWUDBAIB
# BQCgga4wGQYJKoZIhvcNAQkDMQwGCisGAQQBgjcCAQQwHAYKKwYBBAGCNwIBCzEO
# MAwGCisGAQQBgjcCARUwLwYJKoZIhvcNAQkEMSIEIDfd6Gj4q9ENmUPBjJjyxWfp
# LPtusz2jtq9HdVW9YFUaMEIGCisGAQQBgjcCAQwxNDAyoBSAEgBNAGkAYwByAG8A
# cwBvAGYAdKEagBhodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20wDQYJKoZIhvcNAQEB
# BQAEggEAfJjjZa9y/blKeABWPv82B3isH7YPLknfCdcPhuzMaRp9P1Yqiv4OOWrk
# 8oNktYTgn+OYpV9w0YHd9MKL4xmP67pC6TmtsLobospNpimTUc1pnobDGDiD6k6E
# MOp0RstpXscxIeLw9PM2DJYOJmL/TBTWfNvJQfp2sZE/magcgRbVbTR0WMduG+/n
# 5pyqn3jrLqu2AhLNCzv7u17P4gV293n7+Qzmgp6vQXDN8TLrBcSNnNsc051Ofosm
# 15YsYF5YgFPOMRdVH47sItjPoU7pPKLdmusCub6fJL0OdYjz6NEKaYLxW/LK8Wl0
# IWbEcQN73gPoqZsnIXqKsXZU5fI/26GCEuQwghLgBgorBgEEAYI3AwMBMYIS0DCC
# EswGCSqGSIb3DQEHAqCCEr0wghK5AgEDMQ8wDQYJYIZIAWUDBAIBBQAwggFQBgsq
# hkiG9w0BCRABBKCCAT8EggE7MIIBNwIBAQYKKwYBBAGEWQoDATAxMA0GCWCGSAFl
# AwQCAQUABCDFJoAYot6sBKLOIUgQuspvVGNIc/jEsCXIPdQmLuLaiwIGYUObw4A2
# GBIyMDIxMDkyNzE4MTI1MC41MVowBIACAfSggdCkgc0wgcoxCzAJBgNVBAYTAlVT
# MRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQK
# ExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJTAjBgNVBAsTHE1pY3Jvc29mdCBBbWVy
# aWNhIE9wZXJhdGlvbnMxJjAkBgNVBAsTHVRoYWxlcyBUU1MgRVNOOjQ5QkMtRTM3
# QS0yMzNDMSUwIwYDVQQDExxNaWNyb3NvZnQgVGltZS1TdGFtcCBTZXJ2aWNloIIO
# PDCCBPEwggPZoAMCAQICEzMAAAFJgAhKuwmgMwsAAAAAAUkwDQYJKoZIhvcNAQEL
# BQAwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcT
# B1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UE
# AxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwHhcNMjAxMTEyMTgyNTU3
# WhcNMjIwMjExMTgyNTU3WjCByjELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hp
# bmd0b24xEDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jw
# b3JhdGlvbjElMCMGA1UECxMcTWljcm9zb2Z0IEFtZXJpY2EgT3BlcmF0aW9uczEm
# MCQGA1UECxMdVGhhbGVzIFRTUyBFU046NDlCQy1FMzdBLTIzM0MxJTAjBgNVBAMT
# HE1pY3Jvc29mdCBUaW1lLVN0YW1wIFNlcnZpY2UwggEiMA0GCSqGSIb3DQEBAQUA
# A4IBDwAwggEKAoIBAQCvE/uJD4XYdtp6OSoZPkolG9p3CWcwLle1XkQMluEejNzI
# QMeWMsd8ZbujdfjJfWG/c3SOmZBwUAWEfVSdlCaMayt8gQHkKFikoD/bY1Q4y7Rf
# da7sCJw8CXf5wfLqzsGMvKkhtBFGOhqN/YqQm5j7B0c9qq128i40lrrspOm31Vel
# +UAqlVt1L7Jb5MGKMWmEaoQpgvLGQq9NPBDMdgVjm1XwFFVcpeBRWWn3Vb0UCWA6
# tqRuFLLaOsheYCA/jw6zw3+UwITm3JmnQVMIr9HALgvKY2uS7lnSKiEaKRjb1oB1
# v0U0s8WPzkgbVpsyro+Uml2v7VreagzQzwvR+dWtAgMBAAGjggEbMIIBFzAdBgNV
# HQ4EFgQUVnea8aPvuLS8NTXWT8mpc+pvJIEwHwYDVR0jBBgwFoAU1WM6XIoxkPND
# e3xGG8UzaFqFbVUwVgYDVR0fBE8wTTBLoEmgR4ZFaHR0cDovL2NybC5taWNyb3Nv
# ZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWljVGltU3RhUENBXzIwMTAtMDctMDEu
# Y3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEFBQcwAoY+aHR0cDovL3d3dy5taWNy
# b3NvZnQuY29tL3BraS9jZXJ0cy9NaWNUaW1TdGFQQ0FfMjAxMC0wNy0wMS5jcnQw
# DAYDVR0TAQH/BAIwADATBgNVHSUEDDAKBggrBgEFBQcDCDANBgkqhkiG9w0BAQsF
# AAOCAQEAEN54Cz4g7OBKqc8iwqLzNdQj2OCTxKmH+jr3Ayp+AY/1qw4d77A/4WCP
# 8g8PdToYiC47UXC6Fd2epJ07Olen50f88rFAz49H5BV7XlwPjiyE1ZU0vLKHiCcB
# 2mibalui7W0dtg4W4bIqi7UlQkhBLERS5nn+zHYQg/rFQUQvvJrKpx2NM0MFgv2h
# ki4B3JkDUfFwoHxYbAAJR1UtXaH+0PG1BW5yL1DLs451q7D/RsHGmvx1M6+RKSr3
# qCUicbfQEa8vaP+nKJ0T/Da5vSqpSKocfD8dwM3Unn0tpoC+lKmqQMDbllghGs7N
# Vhps+9xG95s7beCMr3AuUZG/E6RQaTCCBnEwggRZoAMCAQICCmEJgSoAAAAAAAIw
# DQYJKoZIhvcNAQELBQAwgYgxCzAJBgNVBAYTAlVTMRMwEQYDVQQIEwpXYXNoaW5n
# dG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYDVQQKExVNaWNyb3NvZnQgQ29ycG9y
# YXRpb24xMjAwBgNVBAMTKU1pY3Jvc29mdCBSb290IENlcnRpZmljYXRlIEF1dGhv
# cml0eSAyMDEwMB4XDTEwMDcwMTIxMzY1NVoXDTI1MDcwMTIxNDY1NVowfDELMAkG
# A1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24xEDAOBgNVBAcTB1JlZG1vbmQx
# HjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlvbjEmMCQGA1UEAxMdTWljcm9z
# b2Z0IFRpbWUtU3RhbXAgUENBIDIwMTAwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAw
# ggEKAoIBAQCpHQ28dxGKOiDs/BOX9fp/aZRrdFQQ1aUKAIKF++18aEssX8XD5WHC
# drc+Zitb8BVTJwQxH0EbGpUdzgkTjnxhMFmxMEQP8WCIhFRDDNdNuDgIs0Ldk6zW
# czBXJoKjRQ3Q6vVHgc2/JGAyWGBG8lhHhjKEHnRhZ5FfgVSxz5NMksHEpl3RYRNu
# KMYa+YaAu99h/EbBJx0kZxJyGiGKr0tkiVBisV39dx898Fd1rL2KQk1AUdEPnAY+
# Z3/1ZsADlkR+79BL/W7lmsqxqPJ6Kgox8NpOBpG2iAg16HgcsOmZzTznL0S6p/Tc
# ZL2kAcEgCZN4zfy8wMlEXV4WnAEFTyJNAgMBAAGjggHmMIIB4jAQBgkrBgEEAYI3
# FQEEAwIBADAdBgNVHQ4EFgQU1WM6XIoxkPNDe3xGG8UzaFqFbVUwGQYJKwYBBAGC
# NxQCBAweCgBTAHUAYgBDAEEwCwYDVR0PBAQDAgGGMA8GA1UdEwEB/wQFMAMBAf8w
# HwYDVR0jBBgwFoAU1fZWy4/oolxiaNE9lJBb186aGMQwVgYDVR0fBE8wTTBLoEmg
# R4ZFaHR0cDovL2NybC5taWNyb3NvZnQuY29tL3BraS9jcmwvcHJvZHVjdHMvTWlj
# Um9vQ2VyQXV0XzIwMTAtMDYtMjMuY3JsMFoGCCsGAQUFBwEBBE4wTDBKBggrBgEF
# BQcwAoY+aHR0cDovL3d3dy5taWNyb3NvZnQuY29tL3BraS9jZXJ0cy9NaWNSb29D
# ZXJBdXRfMjAxMC0wNi0yMy5jcnQwgaAGA1UdIAEB/wSBlTCBkjCBjwYJKwYBBAGC
# Ny4DMIGBMD0GCCsGAQUFBwIBFjFodHRwOi8vd3d3Lm1pY3Jvc29mdC5jb20vUEtJ
# L2RvY3MvQ1BTL2RlZmF1bHQuaHRtMEAGCCsGAQUFBwICMDQeMiAdAEwAZQBnAGEA
# bABfAFAAbwBsAGkAYwB5AF8AUwB0AGEAdABlAG0AZQBuAHQALiAdMA0GCSqGSIb3
# DQEBCwUAA4ICAQAH5ohRDeLG4Jg/gXEDPZ2joSFvs+umzPUxvs8F4qn++ldtGTCz
# wsVmyWrf9efweL3HqJ4l4/m87WtUVwgrUYJEEvu5U4zM9GASinbMQEBBm9xcF/9c
# +V4XNZgkVkt070IQyK+/f8Z/8jd9Wj8c8pl5SpFSAK84Dxf1L3mBZdmptWvkx872
# ynoAb0swRCQiPM/tA6WWj1kpvLb9BOFwnzJKJ/1Vry/+tuWOM7tiX5rbV0Dp8c6Z
# ZpCM/2pif93FSguRJuI57BlKcWOdeyFtw5yjojz6f32WapB4pm3S4Zz5Hfw42JT0
# xqUKloakvZ4argRCg7i1gJsiOCC1JeVk7Pf0v35jWSUPei45V3aicaoGig+JFrph
# pxHLmtgOR5qAxdDNp9DvfYPw4TtxCd9ddJgiCGHasFAeb73x4QDf5zEHpJM692VH
# eOj4qEir995yfmFrb3epgcunCaw5u+zGy9iCtHLNHfS4hQEegPsbiSpUObJb2sgN
# VZl6h3M7COaYLeqN4DMuEin1wC9UJyH3yKxO2ii4sanblrKnQqLJzxlBTeCG+Sqa
# oxFmMNO7dDJL32N79ZmKLxvHIa9Zta7cRDyXUHHXodLFVeNp3lfB0d4wwP3M5k37
# Db9dT+mdHhk4L7zPWAUu7w2gUDXa7wknHNWzfjUeCLraNtvTX4/edIhJEqGCAs4w
# ggI3AgEBMIH4oYHQpIHNMIHKMQswCQYDVQQGEwJVUzETMBEGA1UECBMKV2FzaGlu
# Z3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9zb2Z0IENvcnBv
# cmF0aW9uMSUwIwYDVQQLExxNaWNyb3NvZnQgQW1lcmljYSBPcGVyYXRpb25zMSYw
# JAYDVQQLEx1UaGFsZXMgVFNTIEVTTjo0OUJDLUUzN0EtMjMzQzElMCMGA1UEAxMc
# TWljcm9zb2Z0IFRpbWUtU3RhbXAgU2VydmljZaIjCgEBMAcGBSsOAwIaAxUAP+Wx
# rucu9GSImwAdD52BRGupqHeggYMwgYCkfjB8MQswCQYDVQQGEwJVUzETMBEGA1UE
# CBMKV2FzaGluZ3RvbjEQMA4GA1UEBxMHUmVkbW9uZDEeMBwGA1UEChMVTWljcm9z
# b2Z0IENvcnBvcmF0aW9uMSYwJAYDVQQDEx1NaWNyb3NvZnQgVGltZS1TdGFtcCBQ
# Q0EgMjAxMDANBgkqhkiG9w0BAQUFAAIFAOT78cUwIhgPMjAyMTA5MjcxNTMxMTda
# GA8yMDIxMDkyODE1MzExN1owdzA9BgorBgEEAYRZCgQBMS8wLTAKAgUA5PvxxQIB
# ADAKAgEAAgILBwIB/zAHAgEAAgIRZzAKAgUA5P1DRQIBADA2BgorBgEEAYRZCgQC
# MSgwJjAMBgorBgEEAYRZCgMCoAowCAIBAAIDB6EgoQowCAIBAAIDAYagMA0GCSqG
# SIb3DQEBBQUAA4GBAAWsSi3GJRvCjuw2T7imUu/shNHko4Xsi4b4JHUGQB/W3UQU
# XuypOLujQ8riJI4F/sXHIckH3gMQgtk1B+ZfFnfahyzdKuSgt4xREpbAFqV3kpPD
# ALW2jitMwP6bA4nIIn6aMzxXxSXGPNRiXsBsDjoolle3JVzo+CdtUx6G5jWcMYID
# DTCCAwkCAQEwgZMwfDELMAkGA1UEBhMCVVMxEzARBgNVBAgTCldhc2hpbmd0b24x
# EDAOBgNVBAcTB1JlZG1vbmQxHjAcBgNVBAoTFU1pY3Jvc29mdCBDb3Jwb3JhdGlv
# bjEmMCQGA1UEAxMdTWljcm9zb2Z0IFRpbWUtU3RhbXAgUENBIDIwMTACEzMAAAFJ
# gAhKuwmgMwsAAAAAAUkwDQYJYIZIAWUDBAIBBQCgggFKMBoGCSqGSIb3DQEJAzEN
# BgsqhkiG9w0BCRABBDAvBgkqhkiG9w0BCQQxIgQgh349XKjErd8LIeNeXBRSV77/
# F+Okik1b4UAJFHVt6/MwgfoGCyqGSIb3DQEJEAIvMYHqMIHnMIHkMIG9BCAolfr8
# WH1478zdhngQdSqc7DQL0sZx0OXG9a0fueihsjCBmDCBgKR+MHwxCzAJBgNVBAYT
# AlVTMRMwEQYDVQQIEwpXYXNoaW5ndG9uMRAwDgYDVQQHEwdSZWRtb25kMR4wHAYD
# VQQKExVNaWNyb3NvZnQgQ29ycG9yYXRpb24xJjAkBgNVBAMTHU1pY3Jvc29mdCBU
# aW1lLVN0YW1wIFBDQSAyMDEwAhMzAAABSYAISrsJoDMLAAAAAAFJMCIEILNyjZso
# SlFqS+gDTmO6cnMxxoBkOn1/LQIIV2WB9EeNMA0GCSqGSIb3DQEBCwUABIIBAHd8
# FjVMDUVDKL2Hs+JTZQ3KJfKmupYUpfYmIjvbtMAfe28e+pBZr2B8bWeJsaAxjoI6
# fC8HdfzFcDbkGzWPrH2HB7/hsH3SFarpaljOwL3cslsVRnRd4+UFISNKoKprXP52
# +LBl533f96iVk2ODDufwNV+JWXiK8FTRnZzGvsl/CCRH/KDp8SL62AqJN9LzkL2l
# Up22I8AVuESzCOCTbRNQJKa/B7Kzo04Cudtt+d7cdMb2zy+EuVE/tnfHgrKRROSF
# HzdBCFKRoTn2BZCi+f72wy8RHgFH76e6tBAr/8qYeJrQh1wqazssVUC6yESVmsui
# qGObsWFcjKhqPCfTUtw=
# SIG # End signature block
