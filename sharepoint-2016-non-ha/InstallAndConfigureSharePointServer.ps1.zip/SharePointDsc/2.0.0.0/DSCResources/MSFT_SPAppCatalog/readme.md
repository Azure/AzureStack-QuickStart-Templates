# Description

This resource will ensure that a specific site collection is marked as the app
catalog for the web application that the site is in. The catalog site needs to
have been created using the correct template (APPCATALOG#0).

This resource should be run using the farm account, and not another specific
setup account. Running this with the setup account you have used in your
configuration may relate to access denied errors.
