# Description

This resource will ensure a specifc user profile sync connection
is in place and that it is configured accordingly to its definition

This resource currently supports AD only.
