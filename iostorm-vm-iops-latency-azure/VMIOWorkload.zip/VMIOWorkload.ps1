
Configuration ConfigureVMIO
{
	param (
		[Parameter(Mandatory)]
		[string]$ControllerVMName,
		[Parameter(Mandatory)]
		[string]$ControllerVMPrivateIP,
		[Parameter(Mandatory)]
		[string]$VMName,
		[Parameter(Mandatory)]
		[string]$VMAdminUserName,
		[Parameter(Mandatory)]
		[string]$VMAdminPassword,
		[int32]$VMIoBlockSize = 4096,
		[int32]$VMIoDuration = 300,
		[int32]$VMIoReadPercentage = 70,
		[int32]$VMIoMaxLatency = 100
	)

	# Turn off private firewall
	netsh advfirewall set privateprofile state off
	# Get full path and name of the script being run
	$PSPath = $PSCommandPath;
	
	# DSC Script Resource - VM iostorm
	Script VMIOAll
	{
		TestScript = { $false }

		GetScript = { return @{}}

		SetScript = {
			$controllerVMName = $using:ControllerVMName
			$controllerVMPrivateIP = $using:ControllerVMPrivateIP
			$vmName = $using:VMName
			$vmAdminUserName = $using:VMAdminUserName
			$vmAdminPassword = $using:VMAdminPassword
			$vmIoBlockSize = $using:VMIoBlockSize
			$vmIoDuration = $using:VMIoDuration
			$vmIoReadPercentage = $using:VMIoReadPercentage
			$vmIoMaxLatency = $using:VMIoMaxLatency
			$psPath = $using:PSPath;
			
			# AzureStack
			{
				# Ignore server certificate errors to avoid https://api.azurestack.local/ certificate error
				add-type @"
				using System.Net;
				using System.Security.Cryptography.X509Certificates;
				public class TrustAllCertsPolicy : ICertificatePolicy {
					public bool CheckValidationResult(
						ServicePoint srvPoint, X509Certificate certificate,
						WebRequest request, int certificateProblem) {
						return true;
					}
				}
"@
				[System.Net.ServicePointManager]::CertificatePolicy = New-Object TrustAllCertsPolicy
				Write-Warning -Message "CertificatePolicy set to ignore all server certificate errors"
			}

			# Import Azure Resource Manager PS module if already present
			try {
				Write-Host "Importing Azure RM";
				Import-AzureRM;
			}
			# Install Azure Resource Manager PS module
			catch {
				Write-Host "Cannot import Azure RM module, proceeding with installation";
	
				# Suppress prompts
				$ConfirmPreference = 'None';

				# Install AzureRM
				Get-PackageProvider -Name nuget -ForceBootstrap -Force;
				Install-Module Azure -repository PSGallery -Force -Confirm:0;
				Install-Module AzureRM -repository PSGallery -Force -Confirm:0;
				Install-AzureRm;
				try {
					Write-Host "Importing Azure RM";
					Import-AzureRM;
				} 
				catch {
					Write-Host "Cannot import Azure RM module after installation of AzureRM module";
				}
			}
			# To avoid warning before loading one or more built-in resources, explicitly import associated modules
			#Import-DscResource -ModuleName 'PSDesiredStateConfiguration';

			# Disable Azure Data Collection
			Disable-AzureDataCollection -ErrorAction Ignore;

			$psScriptDir = Split-Path -Parent -Path $psPath;
			$psScriptName = "VMIOWorkloadScript.ps1";
			$psScriptPath = "$psScriptDir\$psScriptName";
			$args = ' -NoProfile -WindowStyle Hidden -Command "& ' + "'" + $psScriptPath + "' '" + $controllerVMName + "' '" + $controllerVMPrivateIP + "' '" + $vmName + "' '" + $vmAdminUserName + "' '" + $vmAdminPassword + "' '" + $vmIoBlockSize + "' '" + $vmIoDuration + "' '" + $vmIoReadPercentage + "' '" + $vmIoMaxLatency + "'" + '"';
			$action = New-ScheduledTaskAction -Execute "Powershell.exe" -Argument $args;
			$trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2);
			$settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -RunOnlyIfNetworkAvailable -DontStopOnIdleEnd
			Unregister-ScheduledTask -TaskName "VMIOWorkload" -Confirm:0 -ErrorAction Ignore;
			Register-ScheduledTask -Action $action -Trigger $trigger -TaskName "VMIOWorkload" -Description "VM iostorm" -User $vmAdminUserName -Password $vmAdminPassword -RunLevel Highest;
		}
	}	
}