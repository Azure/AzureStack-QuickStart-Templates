#
# Copyright="?Microsoft Corporation. All rights reserved."
#

param (
	[Parameter(Mandatory)]
	[string]$ControllerVMName,
	[Parameter(Mandatory)]
	[string]$ControllerVMPrivateIP,
	[Parameter(Mandatory)]
	[string]$VMName,
	[Parameter(Mandatory)]
	[string]$VMUserName,
	[Parameter(Mandatory)]
	[string]$VMPassword
)

# Waits for a '$ioPreSyncStartSignalFile' (e.g. \\10.0.0.6\smbshare\iopresyncstart.txt) then starts io pre-sync 
# Creates pre-sync file '$ioPreSyncFileName' (e.g. IOPreSync-VM0.log) to indicate VM is up and waiting to start a workload
# Waits for a '$ioPreSyncSignalFile' file (e.g. \\10.0.0.6\smbshare\iopresyncsucceed.txt) then starts io workload
# Copy io result file '$ioResultFileName' (e.g. IOResult-VM0.log) in io result directory '$ioResultShare' (e.g. \\10.0.0.6\smbshare\ioresult\)
# All execution logs are written to a file  '$logFileName' (e.g. VMWorkload-VM0.log) and then copied to '$logShare' (e.g. \\10.0.0.6\smbshare\logs\)
function VMIOWorkload {
	# Turn off private firewall off
	netsh advfirewall set privateprofile state off

	# Local file storage location
	$localPath = "$env:SystemDrive"

	# Log file
	$logFileName = "VMWorkload-$VMName.log"
	$logFilePath = "$localPath\$logFileName"

	# Result SMB share
	$smbshare = "\\$ControllerVMPrivateIP\smbshare"

	# Create io workload pre-sync directory
	$ioPreSyncShare = "$smbshare\iopresync"
	$ioPreSyncFileName = "IOPreSync-$VMName.log"

	# Sync signal to start io pre-sync from controller vm
	$ioPreSyncStartSignalFile = "$smbshare\iopresyncstart.txt"

	# Sync signal from controller vm
	$ioPreSyncSignalFile = "$smbshare\iopresyncsucceed.txt"

	# Log directory
	$logShare = "$smbshare\logs"

	# Create io result directory
	$ioResultShare = "$smbshare\ioresult"
	$ioResultFileName = "IOResult-$VMName.xml"

	# Setup connection to smb share of a controller VM, if net use fails retry until timeout
	$startTime = Get-Date
	$elapsedTime = $(Get-Date) - $startTime
	$syncTimeoutInSeconds = 1800
	while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds)
	{
		net use $smbshare /user:$VMUserName $VMPassword
		if((Test-Path $smbshare) -eq $false)
		{
			Start-Sleep 3
		}
		else
		{
			Write-Host "SMB share $smbshare is accessible"
			break
		}
		$elapsedTime = $(Get-Date) - $startTime
	}

	if((Test-Path $smbshare) -eq $true) {
		##########################################
		### WAIT TO START IO WORKLOAD PRE-SYNC ###
		##########################################
		# Wait for 10800 seconds / 3 hours for VM boot storm to finish by the Controller VM
		$noOfRetries = 1080;
		while($noOfRetries -gt 0) {
			if((Test-Path $ioPreSyncStartSignalFile) -eq $true) {
				Write-Host "Wait to start pre-io synchronization is over"
				$noOfRetries = 0;
			}
			Start-Sleep -Seconds 10;
			if($noOfRetries -gt 0) {
				Write-Host "Waiting to start pre-io synchronization... $noOfRetries"
				$noOfRetries--;
			}
		}
	}

	# Create pre-sync file
	$dtTime = Get-Date
	echo "Creating pre-sync file at $dtTime" >> $logFilePath
	echo "$VMName" > $localPath\$ioPreSyncFileName

	# Setup connection to smb share of a controller VM, if net use fails retry until timeout
	$startTime = Get-Date
	$elapsedTime = $(Get-Date) - $startTime
	$syncTimeoutInSeconds = 600
	while($elapsedTime.TotalSeconds -lt $syncTimeoutInSeconds)
	{
		net use $smbshare /user:$VMUserName $VMPassword
		if((Test-Path $smbshare) -eq $false)
		{
			Start-Sleep 3
		}
		else
		{
			echo "SMB share $smbshare is accessible" >> $logFilePath
			break
		}
		$elapsedTime = $(Get-Date) - $startTime
	}

	if((Test-Path $smbshare) -eq $true) {
		############################
		### IO WORKLOAD PRE-SYNC ###
		############################
		# Copy pre-sync file
		copy $localPath\$ioPreSyncFileName $ioPreSyncShare\;
		echo "Coyping pre-sync file $ioPreSyncFileName to $ioPreSyncShare" >> $logFilePath

		# Wait for 1800 seconds
		$noOfRetries = 180;
		$ioPreSyncDidSucceed = $false;
		while($noOfRetries -gt 0) {
			if((Test-Path $ioPreSyncSignalFile) -eq $true) {
				$ioPreSyncDidSucceed = $true;
				Write-Host "Pre io-workload synchronization succeeded."
				echo "Pre io-workload synchronization succeeded (Sync signal $ioPreSyncSignalFile is present)" >> $logFilePath
				#break;
				$noOfRetries = 0;
			}
			Start-Sleep -Seconds 10;
			if($noOfRetries -gt 0) {
				Write-Host "Pre io-workload synchronization waiting... $noOfRetries"
				echo "Pre io-workload synchronization waiting... $noOfRetries" >> $logFilePath
				$noOfRetries--;
			}
		}
		if($ioPreSyncDidSucceed -eq $false){
			Write-Host "Pre io-workload synchronization failed."
			echo "Pre io-workload synchronization failed" >> $logFilePath
		}

		###################
		### IO WORKLOAD ###
		###################
		# Download diskspd tool
		echo "Downloading diskspd io load generating tool" >> $logFilePath
		$diskspdSource = "https://raw.githubusercontent.com/Azure/AzureStack-QuickStart-Templates/master/iostorm-vm-iops-latency/diskspd.exe"
		$diskspdFileName = [System.IO.Path]::GetFileName($diskspdSource)
		$diskspdDestination = "$localPath\$diskspdFileName"
		$webClient = New-Object System.Net.WebClient
		$_date = Get-Date -Format hh:mmtt
		echo "Downloading diskspd io load generating tool from $diskspdSource to $diskspdDestination at $_date" >> $logFilePath
		$webClient.DownloadFile($diskspdSource, $diskspdDestination)
		$_date = Get-Date -Format hh:mmtt
		if((Test-Path $diskspdDestination) -eq $true)
		{
			echo "Downloading diskspd io load generating tool succeeded at $_date" >> $logFilePath
		}
		else
		{
			echo "ERROR: Downloading diskspd io load generating tool failed at $_date" >> $logFilePath
		}

		# Run io workload
		echo "Starting io load generation" >> $logFilePath
		$workloadFileDrive = $env:SYSTEMDRIVE

		# Get all HDD (Drive Type 3)
		$allDrives = Get-WmiObject win32_logicaldisk -filter 'DriveType=3'
		if(($allDrives -eq $null) -or ($allDrives.Count -lt 2))
		{
			$workloadFileDrive = $env:SystemDrive
			Write-Host "Running workload on a system drive: $WorkloadFile"
			echo "Running workload on a system drive: $WorkloadFile" >> $logFilePath
		}
		else
		{
			$systemDrive = $env:SYSTEMDRIVE
			foreach($eachDr in $allDrives)
			{
				if($eachDr.DeviceID -ne $systemDrive)
				{
					$workloadFileDrive = $eachDr.DeviceID
					break
				}
			}
			Write-Host "Running workload on a non-system drive: $workloadFileDrive"
			echo "Running workload on a non-system drive: $workloadFileDrive" >> $logFilePath
		}

		$workloadFilePath = $workloadFileDrive + "\iobw.tst"
		# t - threads, b - block size, w - write ratio, r - random, d - duration, W - warmup period, C - cooldown period, o - queue depth, c - target file size
		$diskspdCmd = "$diskspdDestination -t4 -b4k -w30 -r -d300 -W300 -C120 -o32 -h -n -c2G -L -D -Rxml $workloadFilePath > $localPath\$ioResultFileName"

		cmd /c $diskspdCmd
		echo "IO workload has finished" >> $logFilePath

		# Copy result file
		copy $localPath\$ioResultFileName $ioResultShare\

		# Copy log file
		copy $logFilePath $logShare\
	}
	else {
		$dtTime = Get-Date
		Write-Host "SMB Share $smbshare is not accessible at $dtTime"
		echo "SMB share $smbshare is not accessible at $dtTime" >> $logFilePath
		echo "Cannot run IO test as SMB Share $smbshare is not accessible at $dtTime" >> $localPath\$ioResultFileName
	}
	echo "Script execution ended" >> $logFilePath
}

VMIOWorkload
